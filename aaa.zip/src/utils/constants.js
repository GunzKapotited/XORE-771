module.exports = {
      PORT: process.env.PORT || 3000,
  WS_PORT: process.env.WS_PORT || 3000,
  // WhatsApp bug types
  BUGS: [
    { bug_id: "delay", bug_name: "𝐗𝐎𝐑𝐄 𝐗 𝐃𝐄𝐋𝐀𝐘" },
 //   { bug_id: "delay2", bug_name: " DELAY ONE HITS" },
    { bug_id: "spam", bug_name: "𝐗𝐎𝐑𝐄 𝐗 𝐂𝐎𝐌𝐁𝐎" },
    { bug_id: "crash", bug_name: "𝐗𝐎𝐑𝐄 𝐗 𝐒𝐏𝐎𝐍𝐆𝐄" },
  //  { bug_id: "uix", bug_name: "CRASH X UI" },
 //   { bug_id: "bokep", bug_name: "FC NO CLICK COBA²"},
    { bug_id: "ios", bug_name: "𝐗𝐎𝐑𝐄 𝐗 𝐈𝐎𝐒" },
  //  { bug_id: "fcinvis", bug_name: "FORCE CLOSE" },
    { bug_id: "fcnoinvis", bug_name: "𝐗𝐎𝐑𝐄 𝐗 𝐅𝐎𝐑𝐂𝐄" }, 
        { bug_id: "uix", bug_name: "𝐗𝐎𝐑𝐄 𝐗 𝐁𝐔𝐋𝐃𝐎" },
    { bug_id: "delay2", bug_name: "𝐗𝐎𝐑𝐄 𝐗 𝐒𝐏𝐎𝐍𝐆𝐄 𝐕𝟐" },
  //  { bug_id: "uix", bug_name: "CRASH X UI" },
 //   { bug_id: "bokep", bug_name: "FC NO CLICK COBA²"},
    { bug_id: "bokep", bug_name: "𝐗𝐎𝐑𝐄 𝐗 𝐂𝐑𝐀𝐒𝐇" },
  //  { bug_id: "fcinvis", bug_name: "FORCE CLOSE" },
    { bug_id: "fcinvis", bug_name: "𝐗𝐎𝐑𝐄 𝐗 𝐃𝐄𝐋𝐀𝐘 𝐕𝟐" }
  ],
    
  payload: [
    { bug_id: "invisibleSpam", bug_name: "𝐗𝐎𝐑𝐄 𝐗 𝐈𝐍𝐅𝐈𝐒" },
    { bug_id: "forceCloseMentalVVIP", bug_name: "𝐗𝐎𝐑𝐄 𝐗 𝐅𝐂" },
    { bug_id: "stealthCrashVVIP", bug_name: "𝐗𝐎𝐑𝐄 𝐗 𝐂𝐑𝐀𝐒𝐇" },
    { bug_id: "crashNotificationVVIP", bug_name: "𝐗𝐎𝐑𝐄 𝐗 𝐍𝐎𝐓𝐈𝐅" },
    { bug_id: "permenCall", bug_name: "𝐗𝐎𝐑𝐄 𝐗 𝐂𝐀𝐋𝐋" }
  ],
    
  DDOS: [
    { ddos_id: "s-gbps", ddos_name: "𝐒𝐘𝐍 𝐇𝐢𝐠𝐡 𝐆𝐁𝐏𝐒 𝐈𝐂𝐆" },
    { ddos_id: "s-pps", ddos_name: "𝐒𝐘𝐍 𝐓𝐫𝐚𝐟𝐟𝐢𝐜 𝐅𝐥𝐨𝐨𝐝 𝐈𝐂𝐂" },
    { ddos_id: "a-gbps", ddos_name: "𝐀𝐂𝐊 𝐇𝐢𝐠𝐡 𝐆𝐁𝐏𝐒 𝐀𝐒𝐒" },
    { ddos_id: "a-pps", ddos_name: "𝐀𝐂𝐊 𝐓𝐫𝐚𝐟𝐟𝐢𝐜 𝐅𝐥𝐨𝐨𝐝 𝐅𝐅𝐋" },
    { ddos_id: "icmp", ddos_name: "𝐈𝐂𝐌𝐏 𝐅𝐥𝐨𝐨𝐝 𝐅𝐅𝐋𝐃" },
    { ddos_id: "udp", ddos_name: "𝐆𝐔𝐃𝐏 ( 𝐇𝐈𝐆𝐇 𝐑𝐈𝐒𝐊 ) 𝐒𝐒𝐇" }

  ],
  // Role cooldowns (in seconds)
  ROLE_COOLDOWNS: {
    member: 300,
    reseller: 240,
    reseller1: 60,
    owner: 0,
    vip: 60,
  },
  // Max quantities by role
  MAX_QUANTITIES: {
    member: 5,
    reseller: 5,
    reseller1: 5,
    owner: 10,
    vip: 10,
  }
};