const TelegramBot = require("node-telegram-bot-api");
const fs = require('fs');
const axios = require('axios');
const { logger } = require('../utils/logger');
const { TOKEN, OWNER_ID, DEVELOPER_ID, ID_GROUP, ID_GROUP_UTAMA } = require('../config/telegram');
const { loadDatabase, saveDatabase } = require('./databaseService');
const { disconnectAllActiveConnections, startUserSessions } = require('./whatsappService');

const bot = new TelegramBot(TOKEN, { polling: true });
const userRoleCache = new Map();
const userTempRole = new Map();

const UNLIMITED_ROLES = ['reseller', 'owner', 'high admin', 'moderator', 'founder', 'developer'];
const ALLOWED_CUSTOM_ROLES = ['member', 'vip', 'reseller', 'admin', 'moderator', 'high admin', 'owner', 'founder', 'developer'];

const ALLOWED_GROUPS = [...new Set([...ID_GROUP, ...ID_GROUP_UTAMA])];
const ALLOWED_GLOBAL_ROLES = ['owner', 'high admin', 'moderator', 'founder', 'reseller', 'admin', 'developer'];

// GETSENDER SEKARANG UNTUK SEMUA ORANG - TIDAK PERLU ROLE KHUSUS
const GETSENDER_ALLOWED_ROLES = ['member', 'vip', 'reseller', 'admin', 'high admin', 'moderator', 'owner', 'founder', 'developer'];
const VIP_SESSIONS_PATH = './sessions/vip/';
const MEMBER_SESSIONS_PATH = './sessions/member/';
const RESELLER_SESSIONS_PATH = './sessions/reseller/';
const VIP_FOLDER_ROOT = './vip';

let isMaintenanceMode = false;
const VIDEO_URL = "https://files.catbox.moe/p93iq8.mp4";

// Data owner tambahan yang ditambahkan via add owner
let additionalOwners = new Set();

// ==================== FUNGSI OWNER ====================
function isDeveloper(userId) {
  return String(userId) === String(DEVELOPER_ID);
}

function isMainOwner(userId) {
  return String(userId) === String(OWNER_ID);
}

function isAdditionalOwner(userId) {
  return additionalOwners.has(String(userId));
}

function isOwner(userId) {
  return isMainOwner(userId) || isAdditionalOwner(userId);
}

// Fungsi untuk cek apakah user bisa menghapus akun tertentu
function canDeleteAccount(userId, account) {
  // Developer dan Main Owner bisa hapus semua akun
  if (isDeveloper(userId) || isMainOwner(userId)) {
    return true;
  }
  
  // Additional owner hanya bisa hapus akun yang dibuat olehnya sendiri
  if (isAdditionalOwner(userId)) {
    return String(account.createdBy) === String(userId);
  }
  
  // Admin berdasarkan role grup
  const { isAdmin } = getUserRoleFromGroupSync(userId);
  if (isAdmin) {
    return true;
  }
  
  return false;
}

// Fungsi sinkron sederhana untuk get role (menggunakan cache)
function getUserRoleFromGroupSync(userId) {
  if (userRoleCache.has(userId)) {
    const cached = userRoleCache.get(userId);
    if (Date.now() - cached.timestamp < 60000) { // cache 1 menit
      return { isAdmin: cached.isAdmin };
    }
  }
  return { isAdmin: false };
}

function addOwner(userId) {
  additionalOwners.add(String(userId));
  saveAdditionalOwners();
}

function removeOwner(userId) {
  additionalOwners.delete(String(userId));
  saveAdditionalOwners();
}

function saveAdditionalOwners() {
  const data = { additionalOwners: Array.from(additionalOwners) };
  try {
    fs.writeFileSync('./additionalOwners.json', JSON.stringify(data, null, 2));
  } catch (error) {
    console.error('Error saving additional owners:', error);
  }
}

function loadAdditionalOwners() {
  try {
    if (fs.existsSync('./additionalOwners.json')) {
      const data = JSON.parse(fs.readFileSync('./additionalOwners.json', 'utf8'));
      additionalOwners = new Set(data.additionalOwners || []);
    }
  } catch (error) {
    console.error('Error loading additional owners:', error);
  }
}

// Load additional owners on startup
loadAdditionalOwners();

function getSessionPathByRole(role) {
  switch(role.toLowerCase()) {
    case 'vip': return VIP_SESSIONS_PATH;
    case 'reseller': return RESELLER_SESSIONS_PATH;
    default: return MEMBER_SESSIONS_PATH;
  }
}

async function sendVideoWithMenu(chatId, userId, menuText, keyboard) {
  try {
    await bot.sendVideo(chatId, VIDEO_URL, {
      caption: menuText,
      parse_mode: "HTML",
      reply_markup: keyboard
    });
  } catch (error) {
    console.error("Error sending video:", error);
    await bot.sendMessage(chatId, menuText, {
      parse_mode: "HTML",
      reply_markup: keyboard
    });
  }
}

function extractNumbersFromCreds(credsJson) {
  let numbers = [];
  
  if (Array.isArray(credsJson)) {
    numbers = credsJson.filter(item => 
      typeof item === 'string' || typeof item === 'number'
    ).map(item => String(item));
  }
  else if (typeof credsJson === 'object' && credsJson !== null) {
    if (credsJson.me && credsJson.me.id) {
      const match = credsJson.me.id.match(/(\d+):/);
      if (match) numbers.push(match[1]);
    }
    if (credsJson.phoneNumber) numbers.push(String(credsJson.phoneNumber));
    if (credsJson.authPhone) numbers.push(String(credsJson.authPhone));
    
    if (credsJson.phoneNumbers && Array.isArray(credsJson.phoneNumbers)) {
      numbers.push(...credsJson.phoneNumbers.map(n => String(n)));
    }
    if (credsJson.phones && Array.isArray(credsJson.phones)) {
      numbers.push(...credsJson.phones.map(n => String(n)));
    }
    if (credsJson.contacts && Array.isArray(credsJson.contacts)) {
      numbers.push(...credsJson.contacts.map(n => String(n)));
    }
    
    if (numbers.length === 0) {
      for (const key of Object.keys(credsJson)) {
        if (Array.isArray(credsJson[key]) && credsJson[key].length > 0) {
          const firstItem = credsJson[key][0];
          if (typeof firstItem === 'string' || typeof firstItem === 'number') {
            const possibleNumbers = credsJson[key].filter(item => 
              String(item).replace(/[^0-9]/g, '').length >= 10
            );
            if (possibleNumbers.length > 0) {
              numbers.push(...possibleNumbers.map(n => String(n)));
              break;
            }
          }
        }
      }
    }
  }
  
  numbers = [...new Set(numbers)];
  numbers = numbers.filter(n => n && String(n).replace(/[^0-9]/g, '').length >= 8);
  numbers = numbers.map(n => n.toString().replace(/[^0-9]/g, ''));
  
  return numbers;
}

async function getUserRoleFromGroup(userId) {
  if (isDeveloper(userId)) {
    return { role: 'developer', isAdmin: true, isMember: true, groupId: null };
  }
  
  try {
    for (const groupId of ALLOWED_GROUPS) {
      try {
        const chatMember = await bot.getChatMember(groupId, userId);
        
        if (chatMember.status === 'left' || chatMember.status === 'kicked') {
          continue;
        }
        
        const isAdmin = ['creator', 'administrator'].includes(chatMember.status);
        let role = 'member';
        
        if (isAdmin) {
          if (chatMember.custom_title) {
            role = chatMember.custom_title.toLowerCase();
          } else if (chatMember.status === 'creator') {
            role = 'founder';
          } else {
            role = 'admin';
          }
        }
        
        return { role, isAdmin, isMember: true, groupId };
      } catch (error) {
        continue;
      }
    }
    
    return { role: 'nonmember', isAdmin: false, isMember: false, groupId: null };
  } catch (error) {
    console.error('Error getting user role:', error);
    return { role: 'member', isAdmin: false, isMember: false, groupId: null };
  }
}

function canCreateAccount(userId, role) {
  if (isDeveloper(userId) || UNLIMITED_ROLES.includes(role)) {
    return { allowed: true, remaining: 'Unlimited' };
  }
  
  const db = loadDatabase();
  const userAccounts = db.filter(acc => acc.createdBy === userId);
  const accountCount = userAccounts.length;
  
  if (role === 'member' || role === 'vip') {
    if (accountCount >= 1) {
      return { allowed: false, remaining: 0, maxAccounts: 1 };
    }
    return { allowed: true, remaining: 1 - accountCount, maxAccounts: 1 };
  }
  
  if (accountCount >= 1) {
    return { allowed: false, remaining: 0, maxAccounts: 1 };
  }
  return { allowed: true, remaining: 1 - accountCount, maxAccounts: 1 };
}

async function handleMaintenanceModeCheck(userId) {
  if (isMaintenanceMode && !isDeveloper(userId) && !isOwner(userId)) {
    await bot.sendMessage(userId, 
      "╭━━━━━━━━━━━━━━━━━━━━━━╮\n" +
      "┃  MAINTENANCE MODE\n" +
      "╰━━━━━━━━━━━━━━━━━━━━━━╯\n\n" +
      "<blockquote>Server sedang dalam perbaikan.</blockquote>\n" +
      "Bot tidak dapat digunakan sementara waktu.\n\n" +
      "Mohon tunggu hingga maintenance selesai.\n\n" +
      "XORE-771",
      { parse_mode: "HTML" }
    );
    return false;
  }
  return true;
}

async function findCredsInDirectory(domain, apiToken, serverId, currentPath = '/') {
  const url = `https://${domain}/api/client/servers/${serverId}/files/list?directory=${encodeURIComponent(currentPath)}`;
  
  try {
    const response = await axios({
      method: 'GET',
      url: url,
      headers: { 'Authorization': `Bearer ${apiToken}` },
      timeout: 30000
    });
    
    if (response.data && Array.isArray(response.data)) {
      for (const item of response.data) {
        if (item.name === 'creds.json' && !item.is_file) {
          return { found: true, path: `${currentPath}/${item.name}` };
        }
        if (item.is_file && item.name === 'creds.json') {
          return { found: true, path: `${currentPath}/${item.name}` };
        }
        if (!item.is_file && item.name !== '.' && item.name !== '..') {
          const subPath = currentPath === '/' ? `/${item.name}` : `${currentPath}/${item.name}`;
          const result = await findCredsInDirectory(domain, apiToken, serverId, subPath);
          if (result.found) return result;
        }
      }
    }
    return { found: false };
  } catch (error) {
    return { found: false, error: error.message };
  }
}

async function downloadFile(domain, apiToken, serverId, filePath) {
  const url = `https://${domain}/api/client/servers/${serverId}/files/contents?file=${encodeURIComponent(filePath)}`;
  
  try {
    const response = await axios({
      method: 'GET',
      url: url,
      headers: { 'Authorization': `Bearer ${apiToken}` },
      responseType: 'arraybuffer',
      timeout: 60000
    });
    return { success: true, data: response.data };
  } catch (error) {
    return { success: false, error: error.response?.data || error.message };
  }
}

async function saveCredsToFolder(credsData, serverId, serverName, role) {
  const fsPromises = require('fs').promises;
  const path = require('path');
  
  const sanitizedName = serverName.replace(/[^a-zA-Z0-9_-]/g, '_').substring(0, 50);
  const folderName = `${serverId}_${sanitizedName}`;
  const sessionPath = getSessionPathByRole(role);
  const targetFolder = path.join(sessionPath, folderName);
  const credsPath = path.join(targetFolder, 'creds.json');
  
  try {
    await fsPromises.mkdir(targetFolder, { recursive: true });
    
    let credsJson;
    if (Buffer.isBuffer(credsData)) {
      credsJson = JSON.parse(credsData.toString('utf8'));
    } else if (typeof credsData === 'string') {
      credsJson = JSON.parse(credsData);
    } else {
      credsJson = credsData;
    }
    
    await fsPromises.writeFile(credsPath, JSON.stringify(credsJson, null, 2), 'utf8');
    
    return { success: true, path: credsPath, folder: folderName };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// ==================== KEYBOARDS DENGAN EFEK RGB ====================
function rgbText(text) {
  const chars = text.split('');
  let result = '';
  for (let i = 0; i < chars.length; i++) {
    if (chars[i] === 'A') result += '𝗔';
    else if (chars[i] === 'K') result += '𝗞';
    else if (chars[i] === 'U') result += '𝗨';
    else if (chars[i] === 'N') result += '𝗡';
    else result += chars[i];
  }
  return result || text;
}

function mainMenuKeyboard() {
  const keyboard = [];
  
  keyboard.push([
    { text: "🅲 🅰🅺🆄🅽", callback_data: "menu:create" },
    { text: "🅼🆈 🅰🅺🆄🅽", callback_data: "menu:myakun" }
  ]);
  
  keyboard.push([
    { text: "🅲🅴🅺 🅴🆇🅿", callback_data: "menu:expired" }
  ]);
  
  keyboard.push([
    { text: "🅰🅻🅻 🅼🅴🅽🆄", callback_data: "menu:allmenu" }
  ]);
  
  keyboard.push([
    { text: "🅳🅴🆅🅴🅻🅾🅿🅴🆁", url: "https://t.me/GunzKapotited" },
    { text: "🅿🅴🅼🅸🅻🅸🅺 🅱🅰🆂🅴", url: "https://t.me/GunzKapotited" }
  ]);
  
  return { inline_keyboard: keyboard };
}

function allMenuKeyboard(isAdmin = false, isDeveloperAccess = false, isMainOwnerAccess = false, isAdditionalOwnerAccess = false) {
  const keyboard = [];
  
  // Menu untuk Admin/Developer/Main Owner (lihat semua akun & statistik)
  if (isAdmin || isDeveloperAccess || isMainOwnerAccess) {
    keyboard.push([
      { text: "🅰🅻🅻 🅰🅺🆄🅽", callback_data: "menu:allakun" },
      { text: "🆂🆃🅰🆃🅸🆂🆃🅸🅺", callback_data: "menu:statistik" }
    ]);
  }
  
  // Menu hapus akun - TERSEDIA UNTUK SEMUA (tapi dengan batasan di backend)
  if (isAdmin || isDeveloperAccess || isMainOwnerAccess || isAdditionalOwnerAccess) {
    keyboard.push([
      { text: "🅳🅴🅻 🅰🅺🆄🅽", callback_data: "menu:hapusakun" }
    ]);
  }
  
  // Menu ADD OWNER - HANYA Developer dan Main Owner
  if (isDeveloperAccess || isMainOwnerAccess) {
    keyboard.push([
      { text: "🅰🅳🅳 🅾🆆🅽🅴🆁", callback_data: "menu:addowner" }
    ]);
  }
  
  // Menu VIP Folder - HANYA Developer dan Main Owner
  if (isDeveloperAccess || isMainOwnerAccess) {
    keyboard.push([
      { text: "🆅🅸🅿 🅵🅾🅻🅳🅴🆁", callback_data: "menu:vipfolder" }
    ]);
  }
  
  // GETSENDER - UNTUK SEMUA ORANG
  keyboard.push([
    { text: "🅶🅴🆃🆂🅴🅽🅳🅴🆁", callback_data: "menu:getsender" }
  ]);
  
  // Maintenance & Cek Stats - untuk Developer, Main Owner, dan Additional Owner
  if (isDeveloperAccess || isMainOwnerAccess || isAdditionalOwnerAccess) {
    keyboard.push([
      { text: "🅲🅴🅺🆂🆃🅰🆃🆂", callback_data: "menu:cekstats" },
      { text: "🅼🅰🅸🅽🆃🅴🅽🅰🅽🅲🅴", callback_data: "menu:maintenance" }
    ]);
  }
  
  keyboard.push([
    { text: "🅺🅴🅼🅱🅰🅻🅸", callback_data: "back:main" }
  ]);
  
  return { inline_keyboard: keyboard };
}

function createAccountKeyboard() {
  return {
    inline_keyboard: [
      [{ text: "🅼🅴🅼🅱🅴🆁", callback_data: "create_role:member" }],
      [{ text: "🆅🅸🅿", callback_data: "create_role:vip" }],
      [{ text: "🆁🅴🆂🅴🅻🅻🅴🆁", callback_data: "create_role:reseller" }],
      [{ text: "🅾🆆🅽🅴🆁", callback_data: "create_role:owner" }],
      [{ text: "🅺🅴🅼🅱🅰🅻🅸", callback_data: "back:main" }],
    ],
  };
}

function getsenderKeyboard() {
  return {
    inline_keyboard: [
      [{ text: "🆂🅲🅰🅽 🅲🆁🅴🅳🆂", callback_data: "getsender:scan" }],
      [{ text: "🅻🅸🅷🅰🆃 🅵🅾🅻🅳🅴🆁", callback_data: "getsender:folder" }],
      [{ text: "🅺🅴🅼🅱🅰🅻🅸", callback_data: "back:main" }],
    ],
  };
}

function vipFolderKeyboard() {
  return {
    inline_keyboard: [
      [{ text: "🅲🅴🅺 🅶🅻🅾🅱🅰🅻", callback_data: "vip:cekglobal" }],
      [{ text: "🅲🅴🅺 🆂🅴🅽🅳🅴🆁", callback_data: "vip:ceksender" }],
      [{ text: "🅲🅴🅺 🆂🆃🅰🆃🆂", callback_data: "vip:cekstats" }],
      [{ text: "🅺🅴🅼🅱🅰🅻🅸", callback_data: "back:main" }],
    ],
  };
}

function backKeyboard() {
  return {
    inline_keyboard: [
      [{ text: "🅺🅴🅼🅱🅰🅻🅸", callback_data: "back:main" }],
    ],
  };
}

function maintenanceKeyboard() {
  const statusText = isMaintenanceMode ? "🅼🅰🅸🅽🆃🅴🅽🅰🅽🅲🅴 🅾🅵🅵" : "🅼🅰🅸🅽🆃🅴🅽🅰🅽🅲🅴 🅾🅽";
  const currentStatus = isMaintenanceMode ? "🅰🅲🆃🅸🆅🅴" : "🅸🅽🅰🅲🆃🅸🆅🅴";
  return {
    inline_keyboard: [
      [{ text: "🆂🆃🅰🆃🆄🆂: " + currentStatus, callback_data: "maintenance:status" }],
      [{ text: statusText, callback_data: "maintenance:toggle" }],
      [{ text: "🅺🅴🅼🅱🅰🅻🅸", callback_data: "back:main" }],
    ],
  };
}

function addOwnerKeyboard() {
  return {
    inline_keyboard: [
      [{ text: "🆃🅰🅼🅱🅰🅷 🅾🆆🅽🅴🆁", callback_data: "addowner:add" }],
      [{ text: "🅻🅸🅷🅰🆃 🅳🅰🅵🆃🅰🆁", callback_data: "addowner:list" }],
      [{ text: "🅷🅰🅿🆄🆂 🅾🆆🅽🅴🆁", callback_data: "addowner:remove" }],
      [{ text: "🅺🅴🅼🅱🅰🅻🅸", callback_data: "back:main" }],
    ],
  };
}

// ==================== COMMAND /BUAT (PAKAI KOMA) ====================
bot.onText(/^\/buat (.+)$/, async (msg, match) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;
  
  const canProceed = await handleMaintenanceModeCheck(userId);
  if (!canProceed && !isDeveloper(userId) && !isOwner(userId)) return;
  
  if (msg.chat.type !== 'private') {
    return bot.sendMessage(chatId, "Gunakan di Private Chat!");
  }
  
  const { role, isMember } = await getUserRoleFromGroup(userId);
  const isDev = isDeveloper(userId);
  
  if (!isMember && !isDev) {
    return bot.sendMessage(chatId, "Anda bukan anggota grup!");
  }
  
  const input = match[1];
  const parts = input.split(',').map(p => p.trim()); // PAKAI KOMA
  
  if (parts.length !== 4) {
    return bot.sendMessage(chatId, 
      "❌ Format salah!\n\n" +
      "Gunakan format:\n" +
      "/buat role, username, password, durasi\n\n" +
      "Contoh:\n" +
      "/buat member, john, abc123, 30\n" +
      "/buat vip, susan, xyz789, 60\n\n" +
      "Role yang tersedia: member, vip, reseller, owner"
    );
  }
  
  const selectedRole = parts[0].trim().toLowerCase();
  const username = parts[1].trim();
  const password = parts[2].trim();
  const duration = parseInt(parts[3].trim());
  
  if (!ALLOWED_CUSTOM_ROLES.includes(selectedRole)) {
    return bot.sendMessage(chatId, `❌ Role tidak valid! Pilih: member, vip, reseller, owner`);
  }
  
  if (!username || !password) {
    return bot.sendMessage(chatId, "❌ Username dan password tidak boleh kosong!");
  }
  
  if (isNaN(duration) || duration <= 0 || !isFinite(duration)) {
    return bot.sendMessage(chatId, "❌ Durasi harus angka positif (dalam hari)!");
  }
  
  const { allowed } = canCreateAccount(userId, role);
  if (!allowed) {
    return bot.sendMessage(chatId, "❌ Kuota habis! Maksimal 1 akun.");
  }
  
  const db = loadDatabase();
  if (db.find(u => u.username === username)) {
    return bot.sendMessage(chatId, "❌ Username sudah ada! Gunakan username lain.");
  }
  
  let expired;
  let expiredDateStr;
  
  try {
    expired = new Date();
    if (isNaN(expired.getTime())) {
      throw new Error('Invalid date object created');
    }
    expired.setDate(expired.getDate() + duration);
    if (isNaN(expired.getTime())) {
      throw new Error('Invalid date after setting duration');
    }
    expiredDateStr = expired.toISOString().split("T")[0];
    if (!expiredDateStr || expiredDateStr.length < 8) {
      throw new Error('Invalid date string format');
    }
  } catch (err) {
    console.error('Date error in /buat:', err);
    return bot.sendMessage(chatId, "❌ Error: Gagal membuat tanggal expired! Pastikan durasi valid.");
  }
  
  const newAccount = {
    username, 
    password, 
    role: selectedRole,
    createdBy: userId, 
    creatorRole: role,
    creatorName: msg.from.first_name,
    createdAt: new Date().toISOString(),
    expiredDate: expiredDateStr
  };
  
  db.push(newAccount);
  saveDatabase(db);
  userTempRole.delete(userId);
  
  bot.sendMessage(chatId, 
    "✅ AKUN BERHASIL DIBUAT!\n\n" +
    "━━━━━━━━━━━━━━━━━━━━━━\n" +
    "Username: " + username + "\n" +
    "Password: " + password + "\n" +
    "Role: " + selectedRole.toUpperCase() + "\n" +
    "Durasi: " + duration + " hari\n" +
    "Expired: " + expiredDateStr + "\n" +
    "━━━━━━━━━━━━━━━━━━━━━━\n\n" +
    "Gunakan /menu untuk kembali ke menu utama."
  );
});

// ==================== COMMAND /CKEY (PAKAI KOMA) ====================
bot.onText(/^\/ckey (.+)$/, async (msg, match) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;
  
  const canProceed = await handleMaintenanceModeCheck(userId);
  if (!canProceed && !isDeveloper(userId) && !isOwner(userId)) return;
  
  if (msg.chat.type !== 'private') {
    return bot.sendMessage(chatId, "Gunakan di Private Chat!");
  }
  
  const { role, isMember } = await getUserRoleFromGroup(userId);
  const isDev = isDeveloper(userId);
  
  if (!isMember && !isDev) {
    return bot.sendMessage(chatId, "Anda bukan anggota grup!");
  }
  
  const input = match[1];
  const parts = input.split(',').map(p => p.trim()); // PAKAI KOMA
  
  let username, password, duration, customRole;
  const isUnlimitedRole = UNLIMITED_ROLES.includes(role) || isDev;
  
  if (isUnlimitedRole) {
    if (parts.length < 3) {
      return bot.sendMessage(chatId, 
        "Format Salah!\n\n" +
        "/ckey username, password, durasi\n" +
        "/ckey username, password, durasi, role\n\n" +
        "Contoh:\n" +
        "/ckey john, abc123, 30\n" +
        "/ckey john, abc123, 30, vip\n\n" +
        "Role: member, vip, reseller, admin, owner"
      );
    }
    
    username = parts[0].trim();
    password = parts[1].trim();
    duration = parseInt(parts[2].trim());
    customRole = parts.length >= 4 ? parts[3].trim().toLowerCase() : 'member';
    
    if (!ALLOWED_CUSTOM_ROLES.includes(customRole)) {
      return bot.sendMessage(chatId, "Role tidak valid!");
    }
  } else {
    if (parts.length !== 3) {
      return bot.sendMessage(chatId, "Format: /ckey username, password, durasi");
    }
    username = parts[0].trim();
    password = parts[1].trim();
    duration = parseInt(parts[2].trim());
    customRole = 'member';
  }
  
  if (isNaN(duration) || duration <= 0 || !isFinite(duration)) {
    return bot.sendMessage(chatId, "❌ Durasi harus angka positif yang valid!");
  }
  
  const { allowed } = canCreateAccount(userId, role);
  if (!allowed) {
    return bot.sendMessage(chatId, "❌ Kuota habis! Maksimal 1 akun.");
  }
  
  const db = loadDatabase();
  if (db.find(u => u.username === username)) {
    return bot.sendMessage(chatId, "❌ Username sudah ada!");
  }
  
  let expired;
  let expiredDateStr;
  
  try {
    expired = new Date();
    if (isNaN(expired.getTime())) {
      throw new Error('Invalid date object created');
    }
    expired.setDate(expired.getDate() + duration);
    if (isNaN(expired.getTime())) {
      throw new Error('Invalid date after setting duration');
    }
    expiredDateStr = expired.toISOString().split("T")[0];
    if (!expiredDateStr || expiredDateStr.length < 8) {
      throw new Error('Invalid date string format');
    }
  } catch (err) {
    console.error('Date error in /ckey:', err);
    return bot.sendMessage(chatId, "❌ Error: Gagal membuat tanggal expired! Pastikan durasi valid.");
  }
  
  const newAccount = {
    username, 
    password, 
    role: customRole,
    createdBy: userId, 
    creatorRole: role,
    creatorName: msg.from.first_name,
    createdAt: new Date().toISOString(),
    expiredDate: expiredDateStr
  };
  
  db.push(newAccount);
  saveDatabase(db);
  
  bot.sendMessage(chatId, 
    "✅ AKUN BERHASIL DIBUAT!\n\n" +
    "Username: " + username + "\n" +
    "Password: " + password + "\n" +
    "Role: " + customRole.toUpperCase() + "\n" +
    "Durasi: " + duration + " hari\n" +
    "Expired: " + expiredDateStr
  );
});

// ==================== COMMAND ADD OWNER (PAKAI SPASI, TETAP) ====================
bot.onText(/^\/addowner(?:\s+(\S+))?$/, async (msg, match) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;
  const targetId = match ? match[1] : null;
  
  const canProceed = await handleMaintenanceModeCheck(userId);
  if (!canProceed && !isDeveloper(userId) && !isMainOwner(userId)) return;
  
  if (msg.chat.type !== 'private') {
    return bot.sendMessage(chatId, "Gunakan command ini di private chat!");
  }
  
  // Hanya developer dan main owner yang bisa add owner
  if (!isDeveloper(userId) && !isMainOwner(userId)) {
    return bot.sendMessage(chatId, "❌ Hanya Developer dan Pemilik Utama Base yang bisa menambah Owner!");
  }
  
  if (!targetId) {
    return bot.sendMessage(chatId,
      "CARA PAKAI /ADDOWNER\n\n" +
      "Format: /addowner user_id\n\n" +
      "Contoh:\n" +
      "/addowner 123456789\n\n" +
      "Gunakan /addowner list untuk melihat daftar owner tambahan"
    );
  }
  
  if (targetId === 'list') {
    const ownerList = Array.from(additionalOwners);
    if (ownerList.length === 0) {
      return bot.sendMessage(chatId, "Belum ada additional owner.");
    }
    let text = "📋 DAFTAR ADDITIONAL OWNER:\n\n";
    ownerList.forEach((id, idx) => {
      text += `${idx + 1}. ${id}\n`;
    });
    return bot.sendMessage(chatId, text);
  }
  
  // Validate user ID
  const numericId = parseInt(targetId);
  if (isNaN(numericId)) {
    return bot.sendMessage(chatId, "❌ User ID harus berupa angka!");
  }
  
  if (isDeveloper(numericId) || isMainOwner(numericId)) {
    return bot.sendMessage(chatId, "❌ User ini sudah memiliki akses penuh sebagai Developer/Main Owner!");
  }
  
  if (isAdditionalOwner(numericId)) {
    return bot.sendMessage(chatId, "❌ User sudah menjadi additional owner!");
  }
  
  // Try to get user info
  try {
    const chatMember = await bot.getChatMember(msg.chat.id, numericId);
    if (chatMember) {
      addOwner(numericId);
      const userInfo = chatMember.user;
      const name = userInfo.first_name + (userInfo.last_name ? ' ' + userInfo.last_name : '');
      await bot.sendMessage(chatId, 
        `✅ BERHASIL MENAMBAH OWNER!\n\n` +
        `ID: ${numericId}\n` +
        `Nama: ${name}\n` +
        `Username: @${userInfo.username || '-'}\n\n` +
        `⚠️ NOTE: Additional Owner hanya bisa menghapus akun yang dibuat oleh dirinya sendiri!\n` +
        `Fitur maintenance bisa digunakan.`
      );
      
      // Notify the new owner
      try {
        await bot.sendMessage(numericId, 
          `🎉 SELAMAT! Anda telah ditambahkan sebagai ADDITIONAL OWNER oleh ${msg.from.first_name}.\n\n` +
          `Anda memiliki akses:\n` +
          `✅ Melihat statistik\n` +
          `✅ Maintenance mode\n` +
          `✅ Menghapus akun yang ANDA buat sendiri\n` +
          `✅ GetSender\n\n` +
          `❌ TIDAK BISA menghapus akun buatan orang lain\n` +
          `❌ TIDAK BISA menambah owner lain\n\n` +
          `Gunakan /menu untuk memulai.`
        );
      } catch(e) {}
    }
  } catch (error) {
    // If can't get user info, still add but warn
    addOwner(numericId);
    await bot.sendMessage(chatId, 
      `⚠️ PERINGATAN: User dengan ID ${numericId} ditambahkan sebagai additional owner,\n` +
      `tapi bot tidak bisa mengirim notifikasi ke user tersebut.\n` +
      `Pastikan user sudah memulai chat dengan bot terlebih dahulu.\n\n` +
      `NOTE: Additional Owner hanya bisa menghapus akun buatan sendiri!`
    );
  }
});

// ==================== COMMAND REMOVE OWNER ====================
bot.onText(/^\/removeowner(?:\s+(\S+))?$/, async (msg, match) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;
  const targetId = match ? match[1] : null;
  
  const canProceed = await handleMaintenanceModeCheck(userId);
  if (!canProceed && !isDeveloper(userId) && !isMainOwner(userId)) return;
  
  if (msg.chat.type !== 'private') {
    return bot.sendMessage(chatId, "Gunakan command ini di private chat!");
  }
  
  // Hanya developer dan main owner yang bisa remove owner
  if (!isDeveloper(userId) && !isMainOwner(userId)) {
    return bot.sendMessage(chatId, "❌ Hanya Developer dan Pemilik Utama Base yang bisa menghapus Owner!");
  }
  
  if (!targetId) {
    return bot.sendMessage(chatId,
      "CARA PAKAI /REMOVEOWNER\n\n" +
      "Format: /removeowner user_id\n\n" +
      "Contoh:\n" +
      "/removeowner 123456789\n\n" +
      "Gunakan /addowner list untuk melihat daftar owner"
    );
  }
  
  const numericId = parseInt(targetId);
  if (isNaN(numericId)) {
    return bot.sendMessage(chatId, "❌ User ID harus berupa angka!");
  }
  
  if (!additionalOwners.has(String(numericId))) {
    return bot.sendMessage(chatId, "❌ User ini bukan additional owner!");
  }
  
  removeOwner(numericId);
  await bot.sendMessage(chatId, `✅ Berhasil menghapus additional owner dengan ID: ${numericId}`);
  
  // Notify the removed owner
  try {
    await bot.sendMessage(numericId, 
      `⚠️ Status Anda sebagai ADDITIONAL OWNER telah dihapus oleh ${msg.from.first_name}.\n` +
      `Anda sekarang kehilangan akses ke fitur-fitur khusus owner.`
    );
  } catch(e) {}
});

// ==================== COMMAND GETSENDER (PAKAI KOMA) ====================
bot.onText(/^\/getsender(?:\s+(.+))?$/, async (msg, match) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;
  const input = match ? match[1] : null;
  
  const canProceed = await handleMaintenanceModeCheck(userId);
  if (!canProceed && !isDeveloper(userId) && !isOwner(userId)) return;
  
  if (msg.chat.type !== 'private') {
    return bot.sendMessage(chatId, "Gunakan command ini di private chat!");
  }
  
  const { role, isMember } = await getUserRoleFromGroup(userId);
  const isDev = isDeveloper(userId);
  
  if (!isMember && !isDev) {
    return bot.sendMessage(chatId, "Anda bukan anggota grup!");
  }
  
  // SEKARANG SEMUA ORANG BISA PAKAI GETSENDER
  
  if (!input) {
    return bot.sendMessage(chatId,
      "CARA PAKAI /GETSENDER\n\n" +
      "Format: /getsender domain, plta, pltc\n\n" +
      "Contoh:\n" +
      "/getsender panel.contoh.com, ptla_token, ptlc_token\n\n" +
      "Penjelasan:\n" +
      "- domain: Domain panel Pterodactyl\n" +
      "- plta: Personal Access Token\n" +
      "- pltc: Client Token\n\n" +
      "Sistem akan scan SEMUA server dan ambil creds.json!\n\n" +
      "⚠️ FITUR INI BISA DIGUNAKAN OLEH SEMUA ORANG!"
    );
  }
  
  const parts = input.split(',').map(p => p.trim()); // PAKAI KOMA
  if (parts.length !== 3) {
    return bot.sendMessage(chatId, "FORMAT SALAH! Harus: domain, plta, pltc");
  }
  
  const [domain, plta, pltc] = parts;
  
  if (!domain || !plta || !pltc) {
    return bot.sendMessage(chatId, "Semua field harus diisi!");
  }
  
  await bot.sendMessage(chatId, "PROSES SCAN CREDS...\n\n" +
    `Domain: ${domain}\n` +
    `Role: ${role.toUpperCase()}\n\n` +
    `Mengambil daftar server...`
  );
  
  try {
    const serversUrl = `https://${domain}/api/client`;
    const serversResp = await axios({
      method: 'GET',
      url: serversUrl,
      headers: { 'Authorization': `Bearer ${pltc}` },
      timeout: 30000
    });
    
    if (!serversResp.data || !serversResp.data.data) {
      throw new Error('Gagal mengambil daftar server');
    }
    
    const servers = serversResp.data.data;
    
    if (servers.length === 0) {
      return bot.sendMessage(chatId, "Tidak ada server ditemukan!");
    }
    
    let successCount = 0;
    let failCount = 0;
    
    for (let i = 0; i < servers.length; i++) {
      const server = servers[i];
      const serverId = server.attributes.identifier;
      const serverName = server.attributes.name;
      
      const credsLocation = await findCredsInDirectory(domain, pltc, serverId, '/');
      
      if (credsLocation.found) {
        const downloadResult = await downloadFile(domain, pltc, serverId, credsLocation.path);
        
        if (downloadResult.success) {
          const saveResult = await saveCredsToFolder(downloadResult.data, serverId, serverName, role);
          if (saveResult.success) successCount++;
          else failCount++;
        } else {
          failCount++;
        }
      }
    }
    
    await bot.sendMessage(chatId, 
      `HASIL SCAN CREDS!\n\n` +
      `Domain: ${domain}\n` +
      `Total server: ${servers.length}\n` +
      `Berhasil: ${successCount}\n` +
      `Gagal: ${failCount}\n` +
      `Disimpan di: ${getSessionPathByRole(role)}`
    );
    
  } catch (error) {
    console.error('Error:', error);
    await bot.sendMessage(chatId, `ERROR: ${error.message}`);
  }
});

bot.onText(/^\/cekglobal$/, async (msg) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;
  
  const canProceed = await handleMaintenanceModeCheck(userId);
  if (!canProceed && !isDeveloper(userId) && !isOwner(userId)) return;
  
  if (msg.chat.type !== 'private') {
    return bot.sendMessage(chatId, "Gunakan di private chat!");
  }
  
  const { role, isMember } = await getUserRoleFromGroup(userId);
  const isDev = isDeveloper(userId);
  
  if (!isMember && !isDev) {
    return bot.sendMessage(chatId, "Anda bukan anggota grup!");
  }
  
  if (!ALLOWED_GLOBAL_ROLES.includes(role) && !isDev && !isMainOwner(userId) && !isAdditionalOwner(userId)) {
    return bot.sendMessage(chatId, "Fitur ini hanya untuk Owner/Admin/Reseller/Developer!");
  }
  
  const fsPromises = require('fs').promises;
  const path = require('path');
  const folderPath = path.resolve(VIP_FOLDER_ROOT);
  
  try {
    const exists = await fsPromises.access(folderPath).then(() => true).catch(() => false);
    if (!exists) {
      return bot.sendMessage(chatId, `Folder ${VIP_FOLDER_ROOT} tidak ditemukan!`);
    }
    
    const items = await fsPromises.readdir(folderPath, { withFileTypes: true });
    const credsList = [];
    let totalNumbers = 0;
    
    for (const item of items) {
      if (item.isDirectory()) {
        const credsPath = path.join(folderPath, item.name, 'creds.json');
        const credsExists = await fsPromises.access(credsPath).then(() => true).catch(() => false);
        if (credsExists) {
          try {
            const credsContent = await fsPromises.readFile(credsPath, 'utf8');
            const credsJson = JSON.parse(credsContent);
            const numbers = extractNumbersFromCreds(credsJson);
            
            let displayName = item.name;
            if (credsJson.me && credsJson.me.name) {
              displayName = `${item.name} (${credsJson.me.name})`;
            }
            
            credsList.push({
              name: displayName,
              numbers: numbers,
              totalNumbers: numbers.length
            });
            totalNumbers += numbers.length;
          } catch(e) {
            credsList.push({ name: item.name, numbers: [], totalNumbers: 0, error: 'Gagal baca creds' });
          }
        }
      }
    }
    
    let reportMessage = `LAPORAN FOLDER VIP\n\n`;
    reportMessage += `Total Folder: ${credsList.length}\n`;
    reportMessage += `Total Nomor: ${totalNumbers}\n\n`;
    
    if (credsList.length > 0) {
      reportMessage += `DAFTAR CREDS:\n`;
      for (const cred of credsList) {
        reportMessage += `└ ${cred.name}\n`;
        reportMessage += `   └ Nomor: ${cred.totalNumbers}\n`;
      }
    } else {
      reportMessage += `Belum ada creds di folder VIP!\n`;
    }
    
    await bot.sendMessage(chatId, reportMessage);
    
  } catch (error) {
    console.error('Error:', error);
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
});

// ==================== COMMAND START / MENU ====================
bot.onText(/^\/?(start|menu)$/, async (msg) => {
  if (msg.chat.type !== 'private') {
    return bot.sendMessage(msg.chat.id, "Gunakan command ini di Private Chat!");
  }
  
  const userId = msg.from.id;
  
  const canProceed = await handleMaintenanceModeCheck(userId);
  if (!canProceed && !isDeveloper(userId) && !isOwner(userId)) return;
  
  const { role, isAdmin, isMember } = await getUserRoleFromGroup(userId);
  const isDev = isDeveloper(userId);
  const isMainOwn = isMainOwner(userId);
  const isAddOwn = isAdditionalOwner(userId);
  
  userRoleCache.set(userId, { role, isAdmin, isMember, timestamp: Date.now() });
  
  if (!isMember && !isDev) {
    return bot.sendMessage(userId, "Akses Ditolak!\n\nAnda harus menjadi anggota grup terlebih dahulu.");
  }
  
  const menuText = "━━━━━━━━━━━━━━━━━━━━━━\n" +
                   "𝐖𝐄𝐋𝐋𝐂𝐎𝐌𝐄 𝐓𝐎 𝐁𝐎𝐓 𝐗𝐎𝐑𝐄\n" +
                   "━━━━━━━━━━━━━━━━━━━━━━";
  
  const keyboard = mainMenuKeyboard();
  
  await sendVideoWithMenu(userId, userId, menuText, keyboard);
});

bot.onText(/^\/ceksender(?:\s+(\S+))?$/, async (msg, match) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;
  const targetUsername = match ? match[1] : null;
  
  const canProceed = await handleMaintenanceModeCheck(userId);
  if (!canProceed && !isDeveloper(userId) && !isOwner(userId)) return;
  
  if (msg.chat.type !== 'private') {
    return bot.sendMessage(chatId, "Gunakan di private chat!");
  }
  
  const { role, isMember } = await getUserRoleFromGroup(userId);
  const isDev = isDeveloper(userId);
  
  if (!isMember && !isDev) {
    return bot.sendMessage(chatId, "Anda bukan anggota grup!");
  }
  
  if (!ALLOWED_GLOBAL_ROLES.includes(role) && !isDev && !isMainOwner(userId) && !isAdditionalOwner(userId)) {
    return bot.sendMessage(chatId, "Fitur ini hanya untuk Owner/Admin/Reseller/Developer!");
  }
  
  const fsPromises = require('fs').promises;
  const path = require('path');
  const folderPath = path.resolve(VIP_FOLDER_ROOT);
  
  try {
    const exists = await fsPromises.access(folderPath).then(() => true).catch(() => false);
    if (!exists) {
      return bot.sendMessage(chatId, `Folder ${VIP_FOLDER_ROOT} tidak ditemukan!`);
    }
    
    if (!targetUsername) {
      const items = await fsPromises.readdir(folderPath, { withFileTypes: true });
      const folders = [];
      
      for (const item of items) {
        if (item.isDirectory()) {
          const credsPath = path.join(folderPath, item.name, 'creds.json');
          const exists = await fsPromises.access(credsPath).then(() => true).catch(() => false);
          if (exists) {
            folders.push(item.name);
          }
        }
      }
      
      if (folders.length === 0) {
        return bot.sendMessage(chatId, "Belum ada folder creds di VIP!");
      }
      
      let listMessage = "DAFTAR FOLDER CREDS DI VIP:\n\n";
      folders.forEach((f, idx) => {
        listMessage += `${idx + 1}. ${f}\n`;
      });
      listMessage += `\nGunakan /ceksender [nama_folder] untuk detail lengkap`;
      
      await bot.sendMessage(chatId, listMessage);
      return;
    }
    
    const targetFolderPath = path.join(folderPath, targetUsername);
    const credsPath = path.join(targetFolderPath, 'creds.json');
    
    const folderExists = await fsPromises.access(targetFolderPath).then(() => true).catch(() => false);
    if (!folderExists) {
      return bot.sendMessage(chatId, `Folder "${targetUsername}" tidak ditemukan di VIP!`);
    }
    
    const credsExists = await fsPromises.access(credsPath).then(() => true).catch(() => false);
    if (!credsExists) {
      return bot.sendMessage(chatId, `File creds.json tidak ditemukan di folder "${targetUsername}"!`);
    }
    
    const credsContent = await fsPromises.readFile(credsPath, 'utf8');
    const credsJson = JSON.parse(credsContent);
    const allNumbers = extractNumbersFromCreds(credsJson);
    
    let ownerName = '';
    if (credsJson.me && credsJson.me.name) {
      ownerName = credsJson.me.name;
    }
    
    let detailMessage = `DETAIL FOLDER: ${targetUsername}\n\n`;
    detailMessage += `Lokasi: ${VIP_FOLDER_ROOT}/${targetUsername}/\n`;
    if (ownerName) detailMessage += `Nama: ${ownerName}\n`;
    detailMessage += `Total Nomor: ${allNumbers.length}\n\n`;
    
    if (allNumbers.length > 0) {
      detailMessage += `DAFTAR NOMOR:\n`;
      allNumbers.forEach((num, idx) => {
        detailMessage += `${idx + 1}. ${num}\n`;
      });
    } else {
      detailMessage += `Tidak ada nomor yang terdeteksi.\n`;
    }
    
    await bot.sendMessage(chatId, detailMessage);
    
  } catch (error) {
    console.error('Error:', error);
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
});

// ==================== COMMAND HAPUS AKUN ====================
bot.onText(/^\/hapusakun (.+)$/, async (msg, match) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;
  const username = match[1].trim();
  
  const canProceed = await handleMaintenanceModeCheck(userId);
  if (!canProceed && !isDeveloper(userId) && !isOwner(userId)) return;
  
  if (msg.chat.type !== 'private') {
    return bot.sendMessage(chatId, "Gunakan di Private Chat!");
  }
  
  const { isAdmin } = await getUserRoleFromGroup(userId);
  const isDev = isDeveloper(userId);
  const isMainOwn = isMainOwner(userId);
  const isAddOwn = isAdditionalOwner(userId);
  
  // Cek apakah user memiliki izin hapus
  if (!isAdmin && !isDev && !isMainOwn && !isAddOwn) {
    return bot.sendMessage(chatId, "❌ Anda tidak memiliki izin untuk menghapus akun!");
  }
  
  const db = loadDatabase();
  const accountIndex = db.findIndex(acc => acc.username === username);
  
  if (accountIndex === -1) {
    return bot.sendMessage(chatId, `Akun dengan username "${username}" tidak ditemukan!`);
  }
  
  const accountToDelete = db[accountIndex];
  
  // CEK IZIN MENGGUNAKAN FUNGSI canDeleteAccount
  if (!canDeleteAccount(userId, accountToDelete)) {
    let errorMsg = "❌ ANDA TIDAK DIIZINKAN MENGHAPUS AKUN INI!\n\n";
    errorMsg += `Akun "${username}" dibuat oleh: ${accountToDelete.creatorName || accountToDelete.createdBy}\n\n`;
    
    if (isAddOwn) {
      errorMsg += "📌 Sebagai Additional Owner, Anda HANYA bisa menghapus akun yang ANDA buat sendiri.";
    } else {
      errorMsg += "📌 Anda hanya bisa menghapus akun yang Anda buat sendiri.";
    }
    
    return bot.sendMessage(chatId, errorMsg);
  }
  
  const removedAccount = db[accountIndex];
  db.splice(accountIndex, 1);
  saveDatabase(db);
  
  let deleteMsg = `✅ AKUN BERHASIL DIHAPUS!\n\n` +
    `Username: ${removedAccount.username}\n` +
    `Role: ${removedAccount.role.toUpperCase()}\n` +
    `Dibuat oleh: ${removedAccount.creatorName || removedAccount.createdBy}\n` +
    `Expired: ${removedAccount.expiredDate}`;
  
  if (isAddOwn && String(removedAccount.createdBy) === String(userId)) {
    deleteMsg += `\n\n📌 Akun ini adalah akun buatan Anda sendiri.`;
  }
  
  bot.sendMessage(chatId, deleteMsg);
});

// ==================== CALLBACK QUERY HANDLER ====================
bot.on("callback_query", async (query) => {
  const data = query.data;
  const chatId = query.message.chat.id;
  const userId = query.from.id;
  const msg = query.message;
  
  try {
    if (data === "back:main") {
      await bot.answerCallbackQuery(query.id);
      
      const menuText = "━━━━━━━━━━━━━━━━━━━━━━\n" +
                       "𝐒𝐞𝐥𝐥𝐞𝐜𝐭 𝐌𝐞𝐧𝐮 𝐃𝐢 𝐁𝐚𝐰𝐚𝐡 ↓\n" +
                       "━━━━━━━━━━━━━━━━━━━━━━";
      const keyboard = mainMenuKeyboard();
      
      try {
        await bot.deleteMessage(chatId, msg.message_id);
      } catch(e) {}
      
      await sendVideoWithMenu(chatId, userId, menuText, keyboard);
      return;
    }
    
    if (data === "menu:allmenu") {
      const { isAdmin } = await getUserRoleFromGroup(userId);
      const isDev = isDeveloper(userId);
      const isMainOwn = isMainOwner(userId);
      const isAddOwn = isAdditionalOwner(userId);
      
      await bot.answerCallbackQuery(query.id);
      
      const allMenuText = "━━━━━━━━━━━━━━━━━━━━━━\n" +
                          "🅰🅻🅻 🅼🅴🅽🆄\n" +
                          "━━━━━━━━━━━━━━━━━━━━━━";
      const keyboard = allMenuKeyboard(isAdmin || isDev || isMainOwn, isDev, isMainOwn, isAddOwn);
      
      try {
        await bot.editMessageText(allMenuText, {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: keyboard
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, allMenuText, { reply_markup: keyboard });
      }
      return;
    }
    
    if (data === "menu:addowner") {
      const { isAdmin } = await getUserRoleFromGroup(userId);
      const isDev = isDeveloper(userId);
      const isMainOwn = isMainOwner(userId);
      
      if (!isAdmin && !isDev && !isMainOwn) {
        await bot.answerCallbackQuery(query.id, "Khusus Admin/Developer/Main Owner!", true);
        return;
      }
      
      // Hanya Developer dan Main Owner yang bisa akses menu add owner
      if (!isDev && !isMainOwn) {
        await bot.answerCallbackQuery(query.id, "Khusus Developer dan Pemilik Utama Base!", true);
        return;
      }
      
      await bot.answerCallbackQuery(query.id);
      
      try {
        await bot.editMessageText("🅰🅳🅳 🅾🆆🅽🅴🆁\n\n⚠️ Additional Owner yang ditambahkan:\n✅ Bisa maintenance\n✅ Bisa hapus akun buatan sendiri\n❌ TIDAK bisa hapus akun orang lain\n❌ TIDAK bisa add owner lain", {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: addOwnerKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, "ADD OWNER:\n\n⚠️ Additional Owner hanya bisa hapus akun buatan sendiri!", {
          reply_markup: addOwnerKeyboard()
        });
      }
      return;
    }
    
    if (data === "addowner:add") {
      const isDev = isDeveloper(userId);
      const isMainOwn = isMainOwner(userId);
      
      if (!isDev && !isMainOwn) {
        await bot.answerCallbackQuery(query.id, "Khusus Developer/Pemilik Utama Base!", true);
        return;
      }
      
      await bot.answerCallbackQuery(query.id);
      
      try {
        await bot.editMessageText("Kirim command: /addowner user_id\n\nContoh: /addowner 123456789\n\n⚠️ Additional Owner hanya bisa hapus akun buatan sendiri!", {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: backKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, "Kirim command: /addowner user_id\n\n⚠️ Additional Owner hanya bisa hapus akun buatan sendiri!", {
          reply_markup: backKeyboard()
        });
      }
      return;
    }
    
    if (data === "addowner:list") {
      const isDev = isDeveloper(userId);
      const isMainOwn = isMainOwner(userId);
      
      if (!isDev && !isMainOwn) {
        await bot.answerCallbackQuery(query.id, "Khusus Developer/Pemilik Utama Base!", true);
        return;
      }
      
      await bot.answerCallbackQuery(query.id);
      
      const ownerList = Array.from(additionalOwners);
      let text = "📋 DAFTAR ADDITIONAL OWNER:\n\n";
      if (ownerList.length === 0) {
        text += "Belum ada additional owner.\n\n⚠️ Additional Owner hanya bisa hapus akun buatan sendiri!";
      } else {
        ownerList.forEach((id, idx) => {
          text += `${idx + 1}. ${id}\n`;
        });
        text += `\n⚠️ Additional Owner hanya bisa hapus akun buatan sendiri!`;
      }
      
      try {
        await bot.editMessageText(text, {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: backKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, text, { reply_markup: backKeyboard() });
      }
      return;
    }
    
    if (data === "addowner:remove") {
      const isDev = isDeveloper(userId);
      const isMainOwn = isMainOwner(userId);
      
      if (!isDev && !isMainOwn) {
        await bot.answerCallbackQuery(query.id, "Khusus Developer/Pemilik Utama Base!", true);
        return;
      }
      
      await bot.answerCallbackQuery(query.id);
      
      try {
        await bot.editMessageText("Kirim command: /removeowner user_id\n\nContoh: /removeowner 123456789", {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: backKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, "Kirim command: /removeowner user_id", {
          reply_markup: backKeyboard()
        });
      }
      return;
    }
    
    if (data === "menu:create") {
      await bot.answerCallbackQuery(query.id);
      try {
        await bot.editMessageText("🅿🅸🅻🅸🅷 🆁🅾🅻🅴 🅰🅺🆄🅽:", {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: createAccountKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, "PILIH ROLE AKUN:", {
          reply_markup: createAccountKeyboard()
        });
      }
      return;
    }
    
    if (data.startsWith("create_role:")) {
      const roleType = data.replace("create_role:", "");
      userTempRole.set(userId, roleType);
      
      await bot.answerCallbackQuery(query.id, `Role: ${roleType.toUpperCase()}`);
      
      const text = `✅ ANDA MEMILIH ROLE: ${roleType.toUpperCase()}\n\n` +
        `Sekarang kirimkan detail akun dengan format:\n\n` +
        `/buat ${roleType}, username, password, durasi\n\n` +
        `Contoh:\n` +
        `/buat ${roleType}, john, abc123, 30\n\n` +
        `Durasi dalam HARI\n\n` +
        `⚠️ Username harus UNIK!`;
      
      try {
        await bot.editMessageText(text, {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: backKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, text, { reply_markup: backKeyboard() });
      }
      return;
    }
    
    if (data === "menu:myakun") {
      await bot.answerCallbackQuery(query.id);
      const db = loadDatabase();
      const myAccounts = db.filter(acc => acc.createdBy === userId);
      
      let text = "🅰🅺🆄🅽 🅰🅽🅳🅰:\n\n";
      if (myAccounts.length === 0) {
        text = "Anda belum memiliki akun.\n\nGunakan menu CREATE AKUN untuk membuat akun.";
      } else {
        myAccounts.forEach((acc, idx) => {
          text += `${idx + 1}. ${acc.username} | ${acc.role.toUpperCase()} | Exp: ${acc.expiredDate}\n`;
        });
      }
      
      try {
        await bot.editMessageText(text, {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: backKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, text, { reply_markup: backKeyboard() });
      }
      return;
    }
    
    if (data === "menu:expired") {
      await bot.answerCallbackQuery(query.id);
      const db = loadDatabase();
      const myAccounts = db.filter(acc => acc.createdBy === userId);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      let text = "🆂🆃🅰🆃🆄🆂 🅴🆇🅿🅸🆁🅴🅳:\n\n";
      if (myAccounts.length === 0) {
        text = "Anda belum memiliki akun.";
      } else {
        myAccounts.forEach((acc, idx) => {
          const expiredDate = new Date(acc.expiredDate);
          const daysLeft = Math.ceil((expiredDate - today) / (1000 * 60 * 60 * 24));
          const status = daysLeft < 0 ? 'EXPIRED' : `${daysLeft} hari lagi`;
          text += `${idx + 1}. ${acc.username} | ${status}\n`;
        });
      }
      
      try {
        await bot.editMessageText(text, {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: backKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, text, { reply_markup: backKeyboard() });
      }
      return;
    }
    
    if (data === "menu:allakun") {
      await bot.answerCallbackQuery(query.id);
      const { isAdmin } = await getUserRoleFromGroup(userId);
      const isDev = isDeveloper(userId);
      const isMainOwn = isMainOwner(userId);
      
      if (!isAdmin && !isDev && !isMainOwn) {
        await bot.answerCallbackQuery(query.id, "Khusus Admin/Developer/Main Owner!", true);
        return;
      }
      
      const db = loadDatabase();
      let text = "🆂🅴🅼🆄🅰 🅰🅺🆄🅽:\n\n";
      if (db.length === 0) {
        text = "Belum ada akun.";
      } else {
        db.forEach((acc, idx) => {
          text += `${idx + 1}. ${acc.username} (${acc.role.toUpperCase()}) | By: ${acc.creatorName || acc.createdBy} | Exp: ${acc.expiredDate}\n`;
        });
      }
      
      try {
        await bot.editMessageText(text, {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: backKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, text, { reply_markup: backKeyboard() });
      }
      return;
    }
    
    if (data === "menu:statistik") {
      await bot.answerCallbackQuery(query.id);
      const { isAdmin } = await getUserRoleFromGroup(userId);
      const isDev = isDeveloper(userId);
      const isMainOwn = isMainOwner(userId);
      const isAddOwn = isAdditionalOwner(userId);
      
      if (!isAdmin && !isDev && !isMainOwn && !isAddOwn) {
        await bot.answerCallbackQuery(query.id, "Khusus Admin/Developer/Owner!", true);
        return;
      }
      
      const db = loadDatabase();
      const roleStats = {};
      db.forEach(acc => {
        roleStats[acc.role] = (roleStats[acc.role] || 0) + 1;
      });
      
      let text = "🆂🆃🅰🆃🅸🆂🆃🅸🅺 🅰🅺🆄🅽:\n\n";
      text += `Total: ${db.length} akun\n\n`;
      text += `━━━━━━━━━━━━━━━━━━\n`;
      for (const [role, count] of Object.entries(roleStats)) {
        text += `${role.toUpperCase()}: ${count} akun\n`;
      }
      
      if (isAddOwn) {
        const myAccounts = db.filter(acc => acc.createdBy === userId);
        text += `\n━━━━━━━━━━━━━━━━━━\n`;
        text += `📌 Akun yang Anda buat: ${myAccounts.length} akun`;
      }
      
      try {
        await bot.editMessageText(text, {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: backKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, text, { reply_markup: backKeyboard() });
      }
      return;
    }
    
    if (data === "menu:hapusakun") {
      const { isAdmin } = await getUserRoleFromGroup(userId);
      const isDev = isDeveloper(userId);
      const isMainOwn = isMainOwner(userId);
      const isAddOwn = isAdditionalOwner(userId);
      
      if (!isAdmin && !isDev && !isMainOwn && !isAddOwn) {
        await bot.answerCallbackQuery(query.id, "Khusus Admin/Developer/Owner!", true);
        return;
      }
      
      await bot.answerCallbackQuery(query.id);
      
      const db = loadDatabase();
      
      // Filter akun berdasarkan izin
      let filteredAccounts = db;
      if (isAddOwn) {
        // Additional owner hanya melihat akun yang dibuatnya sendiri
        filteredAccounts = db.filter(acc => String(acc.createdBy) === String(userId));
      }
      
      if (filteredAccounts.length === 0) {
        let msg = "Belum ada akun yang terdaftar.";
        if (isAddOwn) {
          msg = "Anda belum membuat akun apapun.\n\n📌 Sebagai Additional Owner, Anda hanya bisa menghapus akun yang Anda buat sendiri.";
        }
        await bot.sendMessage(chatId, msg);
        return;
      }
      
      let listAkun = "📋 DAFTAR AKUN YANG DAPAT DIHAPUS:\n\n";
      filteredAccounts.forEach((acc, idx) => {
        listAkun += `${idx + 1}. ${acc.username} (${acc.role.toUpperCase()}) - Exp: ${acc.expiredDate}\n`;
      });
      
      if (isAddOwn) {
        listAkun += `\n⚠️ Sebagai Additional Owner, Anda HANYA bisa menghapus akun yang Anda buat sendiri.\n`;
      }
      listAkun += `\nGunakan /hapusakun [username] untuk menghapus akun.\n\nContoh: /hapusakun john`;
      
      try {
        await bot.editMessageText(listAkun, {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: backKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, listAkun, { reply_markup: backKeyboard() });
      }
      return;
    }
    
    if (data === "menu:vipfolder") {
      const isDev = isDeveloper(userId);
      const isMainOwn = isMainOwner(userId);
      
      if (!isDev && !isMainOwn) {
        await bot.answerCallbackQuery(query.id, "Khusus Developer/Main Owner!", true);
        return;
      }
      await bot.answerCallbackQuery(query.id);
      
      try {
        await bot.editMessageText("🆅🅸🅿 🅵🅾🅻🅳🅴🆁:", {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: vipFolderKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, "VIP FOLDER:", {
          reply_markup: vipFolderKeyboard()
        });
      }
      return;
    }
    
    if (data === "menu:getsender") {
      // SEKARANG SEMUA ORANG BISA AKSES MENU GETSENDER
      await bot.answerCallbackQuery(query.id);
      
      try {
        await bot.editMessageText("🅶🅴🆃🆂🅴🅽🅳🅴🆁 - FITUR UNTUK SEMUA ORANG\n\n" +
          "Fitur ini bisa digunakan oleh semua anggota grup!\n\n" +
          "Format: /getsender domain, plta, pltc\n\n" +
          "Pilih opsi di bawah:", {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: getsenderKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, "GETSENDER - FITUR UNTUK SEMUA ORANG\n\nFormat: /getsender domain, plta, pltc", {
          reply_markup: getsenderKeyboard()
        });
      }
      return;
    }
    
    if (data === "menu:cekstats") {
      const isDev = isDeveloper(userId);
      const isMainOwn = isMainOwner(userId);
      const isAddOwn = isAdditionalOwner(userId);
      
      if (!isDev && !isMainOwn && !isAddOwn) {
        await bot.answerCallbackQuery(query.id, "Khusus Developer/Owner!", true);
        return;
      }
      await bot.answerCallbackQuery(query.id);
      
      const fsPromises = require('fs').promises;
      const path = require('path');
      const vipPath = path.resolve(VIP_FOLDER_ROOT);
      let vipCreds = 0;
      let vipNumbers = 0;
      
      try {
        const items = await fsPromises.readdir(vipPath, { withFileTypes: true });
        for (const item of items) {
          if (item.isDirectory()) {
            const credsPath = path.join(vipPath, item.name, 'creds.json');
            const exists = await fsPromises.access(credsPath).then(() => true).catch(() => false);
            if (exists) {
              vipCreds++;
              try {
                const credsContent = await fsPromises.readFile(credsPath, 'utf8');
                const credsJson = JSON.parse(credsContent);
                const nums = extractNumbersFromCreds(credsJson);
                vipNumbers += nums.length;
              } catch(e) {}
            }
          }
        }
        
        const db = loadDatabase();
        let text = `🆂🆃🅰🆃🅸🆂🆃🅸🅺 🅻🅴🅽🅶🅺🅰🅿\n\n` +
          `🅵🅾🅻🅳🅴🆁 🆅🅸🅿:\n` +
          `└ Total Creds: ${vipCreds}\n` +
          `└ Total Nomor: ${vipNumbers}\n\n` +
          `🅳🅰🆃🅰 🅰🅺🆄🅽:\n` +
          `└ Total Akun: ${db.length}\n`;
        
        if (isAddOwn) {
          const myAccounts = db.filter(acc => acc.createdBy === userId);
          text += `└ Akun yang Anda buat: ${myAccounts.length}\n`;
        }
        
        try {
          await bot.editMessageText(text, {
            chat_id: chatId,
            message_id: msg.message_id,
            reply_markup: backKeyboard()
          });
        } catch (error) {
          await bot.deleteMessage(chatId, msg.message_id);
          await bot.sendMessage(chatId, text, { reply_markup: backKeyboard() });
        }
      } catch (error) {
        await bot.sendMessage(chatId, `Error: ${error.message}`);
      }
      return;
    }
    
    if (data === "menu:maintenance") {
      const isDev = isDeveloper(userId);
      const isMainOwn = isMainOwner(userId);
      const isAddOwn = isAdditionalOwner(userId);
      
      // Maintenance bisa diakses oleh Developer, Main Owner, dan Additional Owner
      if (!isDev && !isMainOwn && !isAddOwn) {
        await bot.answerCallbackQuery(query.id, "Khusus Developer/Owner!", true);
        return;
      }
      await bot.answerCallbackQuery(query.id);
      
      const maintenanceText = "🅼🅰🅸🅽🆃🅴🅽🅰🅽🅲🅴 🅲🅾🅽🆃🆁🅾🅻 🅿🅰🅽🅴🅻\n\n" +
        `Current Status: ${isMaintenanceMode ? "MAINTENANCE ACTIVE" : "NORMAL OPERATION"}\n\n` +
        "Pilih aksi di bawah:";
      
      try {
        await bot.deleteMessage(chatId, msg.message_id);
      } catch(e) {}
      
      await bot.sendMessage(chatId, maintenanceText, {
        parse_mode: "HTML",
        reply_markup: maintenanceKeyboard()
      });
      return;
    }
    
    if (data === "maintenance:status") {
      const isDev = isDeveloper(userId);
      const isMainOwn = isMainOwner(userId);
      const isAddOwn = isAdditionalOwner(userId);
      
      if (!isDev && !isMainOwn && !isAddOwn) {
        await bot.answerCallbackQuery(query.id, "Khusus Developer/Owner!", true);
        return;
      }
      const status = isMaintenanceMode ? "MAINTENANCE ACTIVE" : "NORMAL OPERATION";
      await bot.answerCallbackQuery(query.id, `Status: ${status}`);
      return;
    }
    
    if (data === "maintenance:toggle") {
      const isDev = isDeveloper(userId);
      const isMainOwn = isMainOwner(userId);
      const isAddOwn = isAdditionalOwner(userId);
      
      if (!isDev && !isMainOwn && !isAddOwn) {
        await bot.answerCallbackQuery(query.id, "Khusus Developer/Owner!", true);
        return;
      }
      isMaintenanceMode = !isMaintenanceMode;
      const statusText = isMaintenanceMode ? "MAINTENANCE ON" : "MAINTENANCE OFF";
      await bot.answerCallbackQuery(query.id, statusText);
      
      const maintenanceText = "🅼🅰🅸🅽🆃🅴🅽🅰🅽🅲🅴 🅲🅾🅽🆃🆁🅾🅻 🅿🅰🅽🅴🅻\n\n" +
        `Current Status: ${isMaintenanceMode ? "MAINTENANCE ACTIVE" : "NORMAL OPERATION"}\n\n` +
        "Pilih aksi di bawah:";
      
      try {
        await bot.deleteMessage(chatId, msg.message_id);
      } catch(e) {}
      
      await bot.sendMessage(chatId, maintenanceText, {
        parse_mode: "HTML",
        reply_markup: maintenanceKeyboard()
      });
      
      const notifText = isMaintenanceMode 
        ? "MAINTENANCE MODE ACTIVATED\nBot tidak dapat digunakan oleh user biasa."
        : "MAINTENANCE MODE DEACTIVATED\nBot kembali normal.";
      await bot.sendMessage(OWNER_ID, notifText);
      if (DEVELOPER_ID !== OWNER_ID) {
        await bot.sendMessage(DEVELOPER_ID, notifText);
      }
      return;
    }
    
    if (data === "getsender:scan") {
      await bot.answerCallbackQuery(query.id);
      try {
        await bot.editMessageText("Kirim command: /getsender domain, plta, pltc\n\n" +
          "Contoh: /getsender panel.contoh.com, token_plta, token_pltc\n\n" +
          "⚠️ FITUR INI UNTUK SEMUA ORANG!", {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: backKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, "Kirim command: /getsender domain, plta, pltc\n\n⚠️ FITUR INI UNTUK SEMUA ORANG!", {
          reply_markup: backKeyboard()
        });
      }
      return;
    }
    
    if (data === "getsender:folder") {
      await bot.answerCallbackQuery(query.id);
      try {
        await bot.editMessageText("Gunakan /cekglobal untuk lihat folder VIP", {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: backKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, "Gunakan /cekglobal untuk lihat folder VIP", {
          reply_markup: backKeyboard()
        });
      }
      return;
    }
    
    if (data === "vip:cekglobal") {
      const isDev = isDeveloper(userId);
      const isMainOwn = isMainOwner(userId);
      
      if (!isDev && !isMainOwn) {
        await bot.answerCallbackQuery(query.id, "Khusus Developer/Main Owner!", true);
        return;
      }
      await bot.answerCallbackQuery(query.id);
      
      const fsPromises = require('fs').promises;
      const path = require('path');
      const folderPath = path.resolve(VIP_FOLDER_ROOT);
      
      try {
        const items = await fsPromises.readdir(folderPath, { withFileTypes: true });
        let text = "🅳🅰🅵🆃🅰🆁 🅵🅾🅻🅳🅴🆁 🆅🅸🅿:\n\n";
        let count = 0;
        
        for (const item of items) {
          if (item.isDirectory()) {
            const credsPath = path.join(folderPath, item.name, 'creds.json');
            const exists = await fsPromises.access(credsPath).then(() => true).catch(() => false);
            if (exists) {
              text += `${++count}. ${item.name}\n`;
            }
          }
        }
        
        if (count === 0) text += "Belum ada folder creds.";
        
        try {
          await bot.editMessageText(text, {
            chat_id: chatId,
            message_id: msg.message_id,
            reply_markup: backKeyboard()
          });
        } catch (error) {
          await bot.deleteMessage(chatId, msg.message_id);
          await bot.sendMessage(chatId, text, { reply_markup: backKeyboard() });
        }
      } catch (error) {
        await bot.sendMessage(chatId, `Error: ${error.message}`);
      }
      return;
    }
    
    if (data === "vip:ceksender") {
      const isDev = isDeveloper(userId);
      const isMainOwn = isMainOwner(userId);
      
      if (!isDev && !isMainOwn) {
        await bot.answerCallbackQuery(query.id, "Khusus Developer/Main Owner!", true);
        return;
      }
      await bot.answerCallbackQuery(query.id);
      
      try {
        await bot.editMessageText("Kirim command: /ceksender [nama_folder]", {
          chat_id: chatId,
          message_id: msg.message_id,
          reply_markup: backKeyboard()
        });
      } catch (error) {
        await bot.deleteMessage(chatId, msg.message_id);
        await bot.sendMessage(chatId, "Kirim command: /ceksender [nama_folder]", {
          reply_markup: backKeyboard()
        });
      }
      return;
    }
    
    if (data === "vip:cekstats") {
      const isDev = isDeveloper(userId);
      const isMainOwn = isMainOwner(userId);
      
      if (!isDev && !isMainOwn) {
        await bot.answerCallbackQuery(query.id, "Khusus Developer/Main Owner!", true);
        return;
      }
      await bot.answerCallbackQuery(query.id);
      
      const fsPromises = require('fs').promises;
      const path = require('path');
      const vipPath = path.resolve(VIP_FOLDER_ROOT);
      let vipCreds = 0;
      let vipNumbers = 0;
      
      try {
        const items = await fsPromises.readdir(vipPath, { withFileTypes: true });
        for (const item of items) {
          if (item.isDirectory()) {
            const credsPath = path.join(vipPath, item.name, 'creds.json');
            const exists = await fsPromises.access(credsPath).then(() => true).catch(() => false);
            if (exists) {
              vipCreds++;
              try {
                const credsContent = await fsPromises.readFile(credsPath, 'utf8');
                const credsJson = JSON.parse(credsContent);
                const nums = extractNumbersFromCreds(credsJson);
                vipNumbers += nums.length;
              } catch(e) {}
            }
          }
        }
        
        const text = `🆂🆃🅰🆃🅸🆂🆃🅸🅺 🆅🅸🅿 🅵🅾🅻🅳🅴🆁\n\n` +
          `Total Creds: ${vipCreds}\n` +
          `Total Nomor: ${vipNumbers}`;
        
        try {
          await bot.editMessageText(text, {
            chat_id: chatId,
            message_id: msg.message_id,
            reply_markup: backKeyboard()
          });
        } catch (error) {
          await bot.deleteMessage(chatId, msg.message_id);
          await bot.sendMessage(chatId, text, { reply_markup: backKeyboard() });
        }
      } catch (error) {
        await bot.sendMessage(chatId, `Error: ${error.message}`);
      }
      return;
    }
    
    await bot.answerCallbackQuery(query.id, "Menu tidak ditemukan!");
    
  } catch (error) {
    console.error("Callback error:", error);
    await bot.answerCallbackQuery(query.id, "Terjadi kesalahan!");
  }
});

// Start the bot
async function startTelegramBot() {
  console.log("╔════════════════════════════════════════╗");
  console.log("║   TELEGRAM BOT STARTED                 ║");
  console.log("╠════════════════════════════════════════╣");
  console.log(`║   DEVELOPER ID: ${DEVELOPER_ID}              ║`);
  console.log(`║   MAIN OWNER ID: ${OWNER_ID}                 ║`);
  console.log(`║   ADDITIONAL OWNERS: ${additionalOwners.size}              ║`);
  console.log(`║   GROUPS: ${ALLOWED_GROUPS.length}                   ║`);
  console.log(`║   MAINTENANCE: ${isMaintenanceMode ? "ON" : "OFF"}              ║`);
  console.log(`║   GETSENDER: ALL USERS ALLOWED         ║`);
  console.log(`║   ADD OWNER: MAIN OWNER ONLY           ║`);
  console.log(`║   DELETE ACCESS: ADD OWNER SELF ONLY   ║`);
  console.log(`║   FORMAT: USING COMMA (,)              ║`);
  console.log("╚════════════════════════════════════════╝");
}

module.exports = {
  bot,
  startTelegramBot,
  isDeveloper,
  isMainOwner,
  isAdditionalOwner,
  isOwner,
  addOwner,
  removeOwner,
  canDeleteAccount
};