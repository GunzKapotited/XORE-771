module.exports = {
  TOKEN: process.env.TELEGRAM_TOKEN || "8578421054:AAFhsS0sTKZYObYZz5GnuFWD4a9UNe3PFXc",
  OWNER_ID: process.env.OWNER_ID || 8212614573,
  DEVELOPER_ID: process.env.DEVELOPER_ID || 8212614573,
  ID_GROUP: [
    "@xorex771"
  ],
  ID_GROUP_UTAMA: [
    "@xorex771"
  ]
};