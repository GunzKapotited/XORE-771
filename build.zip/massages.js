// ─── START MESSAGES ──────────────────────────────────────────────────────────
function getStartMessage(name, botName, botVersion, roleLine, buildTimeout) {
  return (
    `Halo, ${name}! Selamat Datang\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n` +
    `${botName.toUpperCase()} — <code>v${botVersion}</code>\n` +
    `<i>Solusi instan build APK Flutter langsung dari Telegram.</i>\n` +
    roleLine + `\n` +
    `<blockquote>` +
    `CARA PAKAI BUILD FLUTTER:\n` +
    `1 Klik <b>Mulai Build APK</b>\n` +
    `2 Pilih mode Release atau Debug\n` +
    `3 Kirim file <b>.zip</b> project Flutter kamu\n` +
    `4 Tunggu proses build di cloud\n` +
    `5 APK dikirim otomatis ke sini` +
    `</blockquote>\n\n` +
    `<blockquote>` +
    `Maks Size: <b>2 GB</b>  |  Timeout: <b>${Math.round(buildTimeout / 60000)} Menit</b>\n` +
    `Engine: <b>Flutter Stable</b>  |  Multi-VM Build` +
    `</blockquote>`
  );
}

function getMaintenanceMessage(reason) {
  return (
    `BOT SEDANG MAINTENANCE\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n` +
    `<blockquote>Bot sementara tidak dapat digunakan.\n\n` +
    `Alasan: ${reason || "Peningkatan sistem"}\n\n` +
    `Ikuti channel kami untuk update terbaru.</blockquote>`
  );
}

function getBannedMessage(banReason, bannedAt) {
  return (
    `AKUN ANDA DIBANNED\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n` +
    `<blockquote>` +
    `Kamu tidak dapat menggunakan bot ini.\n\n` +
    `Alasan: ${banReason || "Melanggar ketentuan"}\n` +
    `Tanggal: ${bannedAt}` +
    `</blockquote>\n\n` +
    `<i>Hubungi admin jika ini adalah kesalahan.</i>`
  );
}

function getJoinChannelMessage() {
  return (
    `Akses Terbatas!\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n` +
    `<blockquote>` +
    `Kamu harus <b>join semua channel kami</b> terlebih dahulu untuk bisa menggunakan bot ini.\n\n` +
    `Setelah join, tekan tombol <b>Verifikasi Join</b> di bawah.` +
    `</blockquote>`
  );
}

function getNewUserMessage(name, userId, username, total, nowWib) {
  return (
    `USER BARU TERDAFTAR\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `<blockquote>` +
    `Nama     : ${name}\n` +
    `ID       : <code>${userId}</code>\n` +
    `Username : ${username}\n` +
    `Waktu    : ${nowWib} WIB\n` +
    `Total    : ${total} user terdaftar` +
    `</blockquote>\n\n` +
    `#NewUser #id${userId}`
  );
}

function getPrivateChatOnlyMessage(botUsername) {
  return (
    `Bot ini hanya bisa digunakan via Private Chat!\nKlik @${botUsername} untuk mulai.`
  );
}

// ─── BUILD MESSAGES ──────────────────────────────────────────────────────────
function getBuildSelectMessage() {
  return (
    `Pilih Mode Build APK\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n` +
    `<blockquote>` +
    `<b>Debug Build</b>\n` +
    `• Build lebih cepat\n` +
    `• Cocok untuk testing\n` +
    `• APK ukuran lebih besar` +
    `</blockquote>\n\n` +
    `<blockquote>` +
    `<b>Release Build</b>\n` +
    `• Optimized & production-ready\n` +
    `• APK ukuran lebih kecil\n` +
    `• Cocok untuk Play Store` +
    `</blockquote>`
  );
}

function getBuildStartedMessage(buildType, priorityMsg) {
  return (
    `Siap Build Flutter APK!\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n` +
    `<blockquote>` +
    `Mode    : ${buildType === "debug" ? "DEBUG" : "RELEASE"}\n` +
    `Format  : <code>.zip</code>\n` +
    `Wajib   : <code>pubspec.yaml</code>\n` +
    `Maks    : <code>2 GB</code>` +
    `</blockquote>` +
    priorityMsg + `\n\n` +
    `<i>Kirim file ZIP project Flutter kamu sekarang!</i>`
  );
}

function getBuildActiveMessage(status, elapsed) {
  return (
    `Build Sedang Aktif!\n\n` +
    `<blockquote>` +
    `Status  : ${status}\n` +
    `Berjalan: ${elapsed}` +
    `</blockquote>\n\n` +
    `<i>Tunggu hingga selesai atau batalkan dulu.</i>`
  );
}

function getBuildBannedMessage() {
  return (
    `Akun Dibanned!\n\n<blockquote>Kamu tidak bisa melakukan build. Hubungi admin.</blockquote>`
  );
}

function getBuildDownloadingMessage(fileName, fileSizeMB, buildType) {
  return (
    `Mengunduh File...\n\n` +
    `<blockquote>` +
    `File  : <code>${fileName}</code>\n` +
    `Size  : <code>${fileSizeMB} MB</code>\n` +
    `Mode  : ${buildType === "debug" ? "DEBUG" : "RELEASE"}` +
    `</blockquote>`
  );
}

function getBuildDownloadedMessage(fileName, fileSizeMB) {
  return (
    `File Diunduh!\n\n` +
    `<blockquote>File : <code>${fileName}</code>\nSize : <code>${fileSizeMB} MB</code>\n\nMengupload ke server build...</blockquote>`
  );
}

function getBuildUploadedMessage(tag, buildType) {
  return (
    `Upload Selesai!\n\n` +
    `<blockquote>Tag  : <code>${tag}</code>\nMode : ${buildType === "debug" ? "DEBUG" : "RELEASE"}\n\nMemulai build di server...</blockquote>`
  );
}

function getBuildStartedRunMessage(runId, fileName, buildType) {
  return (
    `Build Dimulai!\n\n` +
    `<blockquote>File  : <code>${fileName}</code>\nMode  : ${buildType === "debug" ? "DEBUG" : "RELEASE"}\nRun ID: <code>${runId}</code>\n\nMemantau progress...</blockquote>`
  );
}

function getBuildErrorMessage(isNet, message) {
  return (
    `${isNet ? "Koneksi Terputus!" : "Error!"}\n\n` +
    `<blockquote>${isNet ? "Bot gagal konek ke server. Silakan coba build lagi." : message}</blockquote>`
  );
}

function getBuildZipErrorMessage() {
  return (
    `Format File Salah!\n\n` +
    `<blockquote>File harus berformat <code>.zip</code>\nSilakan zip ulang project Flutter kamu.</blockquote>`
  );
}

function getBuildZipFileError(message) {
  return (
    `Gagal Memproses File!\n\n` +
    `<blockquote>Error: <code>${message}</code>\n\nSilakan coba lagi.</blockquote>`
  );
}

function getBuildProcessError(message) {
  return (
    `Gagal Memproses Asset!\n\n<blockquote>${message}</blockquote>`
  );
}

function getBuildInvalidFileMessage() {
  return (
    `Kirim file ZIP-nya ya, bukan teks!`
  );
}

// ─── MONITOR BUILD MESSAGES ─────────────────────────────────────────────────
function getMonitorStatusMessage(title, serverStatus, priority, displayMode, projDisplay, elapsed, message) {
  return (
    `[ ${title} ]\n\n` +
    `<blockquote>` +
    `Server   : <code>${serverStatus}</code>\n` +
    `Priority : ${priority}\n` +
    `Mode     : <code>${displayMode}</code>\n` +
    `Project  : <code>${projDisplay}</code>\n` +
    `Waktu    : <code>${elapsed}</code>\n\n` +
    `${message}` +
    `</blockquote>`
  );
}

function getMonitorBuildingMessage(priority, displayMode, projDisplay, elapsed, pct) {
  return (
    `[ SEDANG KOMPILASI ]\n\n` +
    `<blockquote>` +
    `Server   : <code>PROCESSING</code>\n` +
    `Priority : ${priority}\n` +
    `Mode     : <code>${displayMode}</code>\n` +
    `Project  : <code>${projDisplay}</code>\n` +
    `Progress : <code>${pct}%</code>\n` +
    `Waktu    : <code>${elapsed}</code>\n\n` +
    `Flutter SDK sedang kompilasi. Stay tune!` +
    `</blockquote>`
  );
}

function getMonitorSuccessMessage(runDuration, projDisplay) {
  return (
    `[ MENGAMBIL APK ]\n\n` +
    `<blockquote>` +
    `Server  : <code>SUCCESS</code>\n` +
    `Durasi  : <code>${runDuration}</code>\n` +
    `Project : <code>${projDisplay}</code>\n\n` +
    `Kompilasi sukses! Mengambil APK dari cloud...` +
    `</blockquote>`
  );
}

function getMonitorApkNotFoundMessage() {
  return (
    `File APK Tidak Ditemukan!\n\n<blockquote>Kompilasi sukses tapi output APK tidak terdeteksi. Hubungi admin.</blockquote>`
  );
}

function getMonitorBadZipMessage() {
  return (
    `APK Tidak Ada di Arsip!\n\n<blockquote>Isi ZIP output kosong atau korup. Hubungi admin.</blockquote>`
  );
}

function getMonitorApkUploadingMessage(apkSize) {
  return (
    `Mengupload APK...\n\n` +
    `<blockquote>Kompilasi sukses! APK <code>${apkSize} MB</code> sedang dikirim ke chat kamu...</blockquote>`
  );
}

function getMonitorApkSuccessMessage(runDuration, apkSize, displayMode, priority, botName) {
  return (
    `APK SIAP DIGUNAKAN!\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `<blockquote>` +
    `Durasi   : <b>${runDuration}</b>\n` +
    `Ukuran   : <b>${apkSize} MB</b>\n` +
    `Mode     : <b>${displayMode}</b>\n` +
    `Priority : ${priority}` +
    `</blockquote>\n\n` +
    `<i>Terima kasih sudah menggunakan ${botName}!</i>`
  );
}

function getMonitorFailedMessage(displayMode, projDisplay) {
  return (
    `[ BUILD GAGAL ]\n\n` +
    `<blockquote>` +
    `Server  : <code>FAILED</code>\n` +
    `Mode    : <code>${displayMode}</code>\n` +
    `Project : <code>${projDisplay}</code>\n\n` +
    `Mengambil log error dari server...` +
    `</blockquote>`
  );
}

function getMonitorFailedDetailMessage(stepName, duration, errorLines) {
  let text =
    `BUILD FAILED\n\n` +
    `<blockquote>` +
    `Step gagal : <code>${stepName || "Kompilasi Utama"}</code>\n` +
    `Durasi     : <code>${duration}</code>` +
    `</blockquote>`;

  if (errorLines && errorLines.length) {
    text += `\n\n<pre>${errorLines.join("\n").slice(0, 1500)}</pre>`;
  } else {
    text += `\n\n<blockquote>Gagal mengambil log error otomatis dari server.</blockquote>`;
  }
  return text;
}

function getMonitorTimeoutMessage(displayMode, projDisplay, timeoutMinutes) {
  return (
    `[ BUILD TIMEOUT ]\n\n` +
    `<blockquote>` +
    `Server  : <code>TIMEOUT</code>\n` +
    `Mode    : <code>${displayMode}</code>\n` +
    `Project : <code>${projDisplay}</code>\n` +
    `Limit   : <code>${timeoutMinutes} Menit</code>\n\n` +
    `Waktu habis! Cek dependensi kodenya dan coba lagi.` +
    `</blockquote>`
  );
}

function getMonitorChannelMessage(emoji, userDisplay, userId, priority, projDisplay, displayMode, statusTitle, statusDesc, elapsed) {
  return (
    `${emoji} LIVE BUILD MONITOR ${emoji}\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `<blockquote>` +
    `Developer : ${userDisplay}\n` +
    `User ID   : <code>${userId}</code>\n` +
    `Priority  : ${priority}\n` +
    `Project   : <code>${projDisplay}</code>\n` +
    `Mode      : <code>${displayMode}</code>` +
    `</blockquote>\n\n` +
    `<blockquote>` +
    `STATUS : <b>${statusTitle}</b>\n` +
    `DETAIL : ${statusDesc}\n` +
    `WAKTU  : <code>${elapsed}</code>` +
    `</blockquote>`
  );
}

function getMonitorChannelSuccessMessage(userDisplay, projDisplay, displayMode, runDuration, apkSize) {
  return (
    `BUILD SUCCESS!\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `<blockquote>` +
    `Developer : ${userDisplay}\n` +
    `Project   : <code>${projDisplay}</code>\n` +
    `Mode      : <code>${displayMode}</code>\n` +
    `Durasi    : <code>${runDuration}</code>\n` +
    `Ukuran    : <code>${apkSize} MB</code>\n` +
    `Status    : <b>SUKSES TERKIRIM</b>` +
    `</blockquote>`
  );
}

function getMonitorLogFileMessage() {
  return (
    `Full Build Error Log\n\n<i>Gunakan file ini untuk menemukan baris kode yang error secara detail.</i>`
  );
}

// ─── ADMIN PANEL MESSAGES ────────────────────────────────────────────────────
function getAdminPanelMessage(totalUsers, resellers, banned, activeJobs, success, failed, rate, maint) {
  return (
    `ADMIN PANEL\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `<blockquote>` +
    `Total User    : <b>${totalUsers}</b>\n` +
    `Reseller      : <b>${resellers}</b>\n` +
    `Banned User   : <b>${banned}</b>\n` +
    `Build Aktif   : <b>${activeJobs}</b>\n` +
    `Build Sukses  : <b>${success}</b>\n` +
    `Build Gagal   : <b>${failed}</b>\n` +
    `Success Rate  : <b>${rate}%</b>\n` +
    `Maintenance  : <b>${maint ? "ON" : "OFF"}</b>` +
    `</blockquote>`
  );
}

// ─── QUEUE MESSAGES ──────────────────────────────────────────────────────────
function getQueueMessage(waiting, uploading, building, jobs, success, failed, time) {
  let text =
    `STATUS BUILD QUEUE\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `<blockquote>` +
    `Menunggu  : <b>${waiting}</b>\n` +
    `Uploading : <b>${uploading}</b>\n` +
    `Building  : <b>${building}</b>` +
    `</blockquote>\n\n`;

  if (jobs.length === 0) {
    text += `<i>Tidak ada build aktif saat ini.</i>\n\n`;
  } else {
    text += `Build Aktif (${jobs.length})\n\n`;
    jobs.forEach((j, i) => {
      const usr = j.fullName && j.fullName !== "Unknown User" ? j.fullName : (j.username ? `@${j.username}` : `User_${j.userId}`);
      const mode = j.buildType === "debug" ? "Debug" : j.type === "web2apk" ? "Web2APK" : "Release";
      text +=
        `${i + 1}. <b>${usr}</b>\n` +
        `<blockquote>` +
        `Status : ${j.status}\n` +
        `Mode   : ${mode}\n` +
        `Aktif  : ${j.elapsed}` +
        `</blockquote>\n`;
    });
  }

  text +=
    `\n<blockquote>` +
    `Sukses: <b>${success}</b>  |  Gagal: <b>${failed}</b>\n` +
    `${time} WIB` +
    `</blockquote>`;

  return text;
}

// ─── STATUS MESSAGES ─────────────────────────────────────────────────────────
function getStatusMessage(botName, botVersion, uptime, users, success, failed, rate, waiting, uploading, building, cloud, ping, osType, osRelease, osArch, cpuModel, cpuCount, cpuLoad, usedRam, totalRam, ramPct, diskUsed, diskTotal, diskPct, time) {
  return (
    `INFRASTRUKTUR BOT\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n` +
    `<b>Bot Info</b>\n` +
    `<blockquote>` +
    `Nama    : ${botName} <code>v${botVersion}</code>\n` +
    `Status  : Online / Active\n` +
    `Uptime  : ${uptime}\n` +
    `User DB : ${users} pengguna\n` +
    `Sukses  : ${success} build\n` +
    `Gagal   : ${failed} build\n` +
    `Rate    : <b>${rate}%</b>` +
    `</blockquote>\n\n` +
    `<b>Queue Engine</b>\n` +
    `<blockquote>` +
    `Menunggu  : ${waiting}\n` +
    `Uploading : ${uploading}\n` +
    `Building  : ${building}` +
    `</blockquote>\n\n` +
    `<b>Cloud Server</b>\n` +
    `<blockquote>` +
    `Provider : <code>${cloud}</code>\n` +
    `Ping     : <code>${ping}</code>\n` +
    `OS       : ${osType} ${osRelease} (${osArch})` +
    `</blockquote>\n\n` +
    `<b>Hardware</b>\n` +
    `<blockquote>` +
    `CPU  : ${cpuModel} (${cpuCount} Core)\n` +
    `Load : <code>${cpuLoad}%</code>\n` +
    `RAM  : <code>${usedRam}/${totalRam} GB (${ramPct}%)</code>\n` +
    `SSD  : <code>${diskUsed}/${diskTotal} (${diskPct})</code>` +
    `</blockquote>\n\n` +
    `<i>${time} WIB</i>`
  );
}

// ─── HELP MESSAGES ───────────────────────────────────────────────────────────
function getHelpMessage(botName, buildTimeout) {
  return (
    `PANDUAN ${botName.toUpperCase()}\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n` +
    `<b>Build APK Flutter</b>\n` +
    `<blockquote>` +
    `1 Klik <b>Mulai Build APK</b>\n` +
    `2 Pilih mode Debug / Release\n` +
    `3 Kirim file ZIP project Flutter\n` +
    `4 Bot build di cloud & kirim APK otomatis` +
    `</blockquote>\n\n` +
    `<b>Web to APK</b>\n` +
    `<blockquote>` +
    `1 Klik <b>Web to APK</b>\n` +
    `2 Kirim URL website\n` +
    `3 Kirim nama aplikasi\n` +
    `4 Kirim logo/icon (PNG/JPG)\n` +
    `5 APK dikirim otomatis` +
    `</blockquote>\n\n` +
    `<b>Ketentuan</b>\n` +
    `<blockquote>` +
    `• Maks <b>1 build aktif</b> per user\n` +
    `• Maks ukuran ZIP: <b>2 GB</b>\n` +
    `• Timeout build: <b>${Math.round(buildTimeout / 60000)} menit</b>` +
    `</blockquote>\n\n` +
    `<b>Perintah Admin</b>\n` +
    `<blockquote>` +
    `/broadcast — Kirim pesan ke semua user\n` +
    `/addreseller <id> — Tambah reseller\n` +
    `/removereseller <id> — Hapus reseller\n` +
    `/searchuser <query> — Cari user\n` +
    `/userinfo <id> — Info detail user\n` +
    `/deleteuser <id> — Hapus user dari DB\n` +
    `/banuser <id> [alasan] — Ban user\n` +
    `/unbanuser <id> — Unban user\n` +
    `/dmuser <id> <pesan> — Kirim DM ke user\n` +
    `/exportusers — Export CSV semua user\n` +
    `/buildhistory — Riwayat build\n` +
    `/killbuild <id> — Force kill build user` +
    `</blockquote>`
  );
}

// ─── WEB2APK MESSAGES ────────────────────────────────────────────────────────
function getWeb2ApkMaintenanceMessage() {
  return (
    `Fitur Dalam Maintenance\n\n` +
    `<blockquote>Fitur Web to APK sementara ditutup untuk peningkatan sistem.\n\nGunakan Build APK biasa untuk sementara.</blockquote>`
  );
}

function getWeb2ApkActiveMessage(status) {
  return (
    `Build Aktif!\n\n<blockquote>Status: ${status}\n\nTunggu selesai atau batalkan dulu.</blockquote>`
  );
}

function getWeb2ApkStep1Message(priorityMsg) {
  return (
    `Web to APK — Langkah 1/3\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n` +
    `Kirim <b>URL website</b> yang ingin dijadikan APK.${priorityMsg}\n\n` +
    `<blockquote>Contoh: <code>https://example.com</code></blockquote>`
  );
}

function getWeb2ApkUrlSavedMessage() {
  return (
    `URL Tersimpan!\n\n` +
    `Web to APK — Langkah 2/3\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n` +
    `Kirim <b>nama aplikasi</b> yang diinginkan.\n\n` +
    `<blockquote>Contoh: <code>Toko Online Saya</code></blockquote>`
  );
}

function getWeb2ApkNameSavedMessage() {
  return (
    `Nama App Tersimpan!\n\n` +
    `Web to APK — Langkah 3/3\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n` +
    `Kirim <b>foto/logo</b> untuk icon APK.\n\n` +
    `<blockquote>Tips:\n• Kirim sebagai foto atau file gambar\n• Disarankan ukuran 1:1 (persegi)\n• Format: PNG, JPG</blockquote>`
  );
}

function getWeb2ApkProcessingMessage(webUrl, appName) {
  return (
    `Memproses Web to APK...\n\n` +
    `<blockquote>URL  : <code>${webUrl}</code>\nNama : <code>${appName}</code>\n\nMemproses icon...</blockquote>`
  );
}

function getWeb2ApkUploadingMessage(webUrl, appName) {
  return (
    `Memproses Web to APK...\n\n` +
    `<blockquote>URL  : <code>${webUrl}</code>\nNama : <code>${appName}</code>\n\nMenyiapkan aset di GitHub Release...</blockquote>`
  );
}

function getWeb2ApkBuildingMessage(webUrl, appName, runId) {
  return (
    `Build Web to APK Dimulai!\n\n` +
    `<blockquote>URL  : <code>${webUrl}</code>\nNama : <code>${appName}</code>\nRun  : <code>${runId}</code>\n\nMemantau progress...</blockquote>`
  );
}

function getWeb2ApkServerErrorMessage(message) {
  return (
    `Error Build Server!\n\n<blockquote>${message}</blockquote>`
  );
}

function getWeb2ApkInvalidUrlMessage() {
  return (
    `URL tidak valid!\n\n<blockquote>Contoh: <code>https://example.com</code></blockquote>`
  );
}

function getWeb2ApkInvalidIconMessage() {
  return (
    `Kirim ikon dalam bentuk Foto atau File Gambar!`
  );
}

// ─── REPORT MESSAGES ──────────────────────────────────────────────────────────
function getReportStartMessage() {
  return (
    `MENU LAPORAN\n\n<blockquote>Ketik alasan dan detail laporan kamu dengan jelas, lalu kirim lewat chat.\n\nLaporan palsu akan menyebabkan akun diblokir.</blockquote>`
  );
}

function getReportShortReasonMessage() {
  return (
    `Mohon berikan alasan yang lebih detail (minimal 10 karakter).`
  );
}

function getReportScreenshotMessage() {
  return (
    `BUKTI SCREENSHOT\n\nKirimkan **1 Foto/Screenshot** bukti pendukung.`
  );
}

function getReportInvalidScreenshotMessage() {
  return (
    `Format salah! Kirimkan bukti berupa Foto/Gambar.`
  );
}

function getReportSuccessMessage() {
  return (
    `**Laporan Terkirim!**\n\nTerima kasih, laporan kamu sudah masuk ke sistem admin.`
  );
}

function getReportErrorMessage() {
  return (
    `Gagal mengirim laporan.`
  );
}

function getReportBlockedMessage() {
  return (
    `Kamu diblokir dari fitur laporan.`
  );
}

function getReportCancelledMessage() {
  return (
    `Laporan Dibatalkan\n\n<blockquote>Proses laporan dihentikan.</blockquote>`
  );
}

function getReportChannelMessage(name, userId, username, reason) {
  return (
    `LAPORAN MASUK\n\n` +
    `<blockquote>` +
    `Nama    : ${name}\n` +
    `ID      : <code>${userId}</code>\n` +
    `Username: ${username}\n\n` +
    `Alasan:\n${reason}` +
    `</blockquote>`
  );
}

function getReportFixedMessage() {
  return (
    `**LAPORAN SELESAI!**\n\nKendala yang kamu laporkan telah diperbaiki oleh admin. Terima kasih!`
  );
}

function getReportBlockedUserMessage() {
  return (
    `**DIBLOKIR!**\n\nFitur laporan kamu dinonaktifkan.`
  );
}

function getReportUnblockedUserMessage() {
  return (
    `**AKSES DIKEMBALIKAN!**\n\nFitur laporan kamu aktif kembali.`
  );
}

// ─── ADMIN COMMAND MESSAGES ──────────────────────────────────────────────────
function getAddResellerCommandMessage() {
  return (
    `Tambah Reseller\n\n<blockquote>Gunakan: <code>/addreseller 123456789</code></blockquote>`
  );
}

function getAddResellerSuccessMessage(num, username) {
  return (
    `Reseller ditambahkan!\n\n<blockquote>ID: <code>${num}</code>\nUsername: ${username || "—"}\nPriority Level 2</blockquote>`
  );
}

function getAddResellerAlreadyMessage(num) {
  return (
    `User ID <code>${num}</code> sudah menjadi reseller.`
  );
}

function getRemoveResellerCommandMessage() {
  return (
    `Hapus Reseller\n\n<blockquote>Gunakan: <code>/removereseller 123456789</code></blockquote>`
  );
}

function getRemoveResellerSuccessMessage(num) {
  return (
    `Reseller dihapus!\n\n<blockquote>ID: <code>${num}</code></blockquote>`
  );
}

function getRemoveResellerNotFoundMessage(num) {
  return (
    `ID <code>${num}</code> bukan reseller.`
  );
}

function getSearchUserCommandMessage() {
  return (
    `Cari User\n\n` +
    `<blockquote>Gunakan:\n<code>/searchuser 123456789</code>\n<code>/searchuser @username</code>\n<code>/searchuser nama</code></blockquote>`
  );
}

function getSearchUserResultMessage(query, results) {
  let text = `Hasil Pencarian "${query}" (${results.length})\n━━━━━━━━━━━━━━━━━━━━\n\n`;
  results.slice(0, 10).forEach(u => {
    text +=
      `<b>${u.role}${u.isBanned ? " BANNED" : ""}</b>\n` +
      `<blockquote>` +
      `ID       : <code>${u.userId}</code>\n` +
      `Nama     : ${u.name || "Unknown"}\n` +
      `Username : ${u.username || "—"}\n` +
      `Join     : ${u.joinedAt}` +
      `</blockquote>\n`;
  });
  if (results.length > 10) text += `\n<i>+${results.length - 10} hasil lainnya</i>`;
  return text;
}

function getSearchUserNotFoundMessage(query) {
  return (
    `Hasil Pencarian\n\n<blockquote>Tidak ada user cocok dengan: <code>${query}</code></blockquote>`
  );
}

function getUserInfoCommandMessage() {
  return (
    `Info User\n\n<blockquote>Gunakan: <code>/userinfo 123456789</code></blockquote>`
  );
}

function getUserInfoMessage(u, tgInfo, isRes, isBan, ban, job, role) {
  return (
    `INFO USER\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `<blockquote>` +
    `ID           : <code>${u.userId}</code>\n` +
    `Nama (DB)    : ${u.name || "Unknown"}\n` +
    `Nama (TG)    : ${tgInfo}\n` +
    `Username     : ${u.username || "—"}\n` +
    `Role         : ${role}\n` +
    `Join         : ${u.joinedAt}\n` +
    `Last Active  : ${u.lastActive}\n` +
    `Reseller     : ${isRes ? "Ya" : "Tidak"}\n` +
    `Status Ban   : ${isBan ? `Dibanned\nAlasan: ${ban?.reason || "—"}\nDibanned: ${ban?.bannedAt}` : "Normal"}\n` +
    `Build Aktif  : ${job ? `${job.status}` : "Tidak ada"}` +
    `</blockquote>`
  );
}

function getUserInfoNotFoundMessage(num) {
  return (
    `User ID <code>${num}</code> tidak ditemukan!`
  );
}

function getBanUserCommandMessage() {
  return (
    `Ban User\n\n<blockquote>Gunakan: <code>/banuser 123456789 alasan ban</code></blockquote>`
  );
}

function getBanUserSuccessMessage(num, reason) {
  return (
    `User Dibanned!\n\n` +
    `<blockquote>ID     : <code>${num}</code>\nAlasan : ${reason}</blockquote>`
  );
}

function getBanUserAlreadyMessage(num) {
  return (
    `User ID <code>${num}</code> sudah dalam status ban.`
  );
}

function getBanUserOwnerMessage() {
  return (
    `Tidak bisa ban Owner!`
  );
}

function getBanUserInvalidIdMessage() {
  return (
    `ID tidak valid!`
  );
}

function getUnbanUserCommandMessage() {
  return (
    `Unban User\n\n<blockquote>Gunakan: <code>/unbanuser 123456789</code></blockquote>`
  );
}

function getUnbanUserSuccessMessage(num) {
  return (
    `User Diunban!\n\n<blockquote>ID: <code>${num}</code></blockquote>`
  );
}

function getUnbanUserNotFoundMessage(num) {
  return (
    `User ID <code>${num}</code> tidak sedang dalam status ban.`
  );
}

function getDeleteUserCommandMessage() {
  return (
    `Hapus User\n\n<blockquote>Gunakan: <code>/deleteuser 123456789</code></blockquote>`
  );
}

function getDeleteUserSuccessMessage(num, name) {
  return (
    `User Dihapus!\n\n<blockquote>ID: <code>${num}</code>\nNama: ${name || "Unknown"}</blockquote>`
  );
}

function getDeleteUserNotFoundMessage(num) {
  return (
    `User ID <code>${num}</code> tidak ditemukan.`
  );
}

function getDeleteUserOwnerMessage() {
  return (
    `Tidak bisa menghapus Owner!`
  );
}

function getDeleteUserInvalidIdMessage() {
  return (
    `ID tidak valid!`
  );
}

function getDmUserCommandMessage() {
  return (
    `Kirim DM ke User\n\n<blockquote>Gunakan: <code>/dmuser 123456789 pesan kamu</code></blockquote>`
  );
}

function getDmUserInvalidFormatMessage() {
  return (
    `Format salah!\n\n<blockquote>Gunakan: <code>/dmuser 123456789 pesan</code></blockquote>`
  );
}

function getDmUserSuccessMessage(num, msg) {
  return (
    `Pesan Terkirim!\n\n<blockquote>Ke: <code>${num}</code>\nPesan: ${msg}</blockquote>`
  );
}

function getDmUserErrorMessage(message) {
  return (
    `Gagal kirim: <code>${message}</code>`
  );
}

function getExportUsersMessage(totalUsers, totalResellers, totalBanned, nowWib) {
  return (
    `Export Database User\n\n` +
    `<blockquote>Total User    : ${totalUsers}\nTotal Reseller: ${totalResellers}\nTotal Banned  : ${totalBanned}\nDiekspor      : ${nowWib}</blockquote>`
  );
}

function getExportUsersErrorMessage(message) {
  return (
    `Gagal export: <code>${message}</code>`
  );
}

function getKillBuildNotFoundMessage(targetId) {
  return (
    `User ID <code>${targetId}</code> tidak sedang build.`
  );
}

function getKillBuildSuccessMessage(targetId) {
  return (
    `Build user <code>${targetId}</code> dihentikan paksa!`
  );
}

function getKillBuildListMessage(jobs) {
  let text =
    `FORCE KILL BUILD\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n`;

  if (jobs.length === 0) {
    text += `<i>Tidak ada build aktif saat ini.</i>`;
  } else {
    text += `<i>Pilih build yang ingin dihentikan paksa:</i>\n\n`;
    jobs.forEach((j, i) => {
      const usr = j.fullName && j.fullName !== "Unknown User" ? j.fullName : (j.username ? `@${j.username}` : `User_${j.userId}`);
      text +=
        `${i + 1}. <b>${j.role}</b> — ${usr}\n` +
        `<blockquote>Status: ${j.status}  |  ${j.elapsed}</blockquote>\n`;
    });
  }
  return text;
}

// ─── BROADCAST MESSAGES ──────────────────────────────────────────────────────
function getBroadcastOwnerMessage(userId, totalUsers) {
  return (
    `PERMINTAAN BROADCAST\n\n<blockquote>Dari Admin ID: <code>${userId}</code>\nTarget: ${totalUsers} user</blockquote>`
  );
}

function getBroadcastStartMessage(totalUsers) {
  return (
    `Broadcast dimulai ke ${totalUsers} user...`
  );
}

function getBroadcastSuccessMessage(totalUsers, success, failed) {
  return (
    `Broadcast Selesai!\n` +
    `<blockquote>Total: ${totalUsers}\nSukses: ${success}\nGagal: ${failed}</blockquote>`
  );
}

function getBroadcastInstructionMessage() {
  return (
    `Cara Broadcast:\n\n<blockquote>Reply pesan yang ingin di-broadcast, lalu ketik /broadcast</blockquote>`
  );
}

function getBroadcastApproveMessage() {
  return (
    `**Broadcast disetujui Owner!**`
  );
}

function getBroadcastRejectMessage() {
  return (
    `**Broadcast ditolak Owner!**`
  );
}

// ─── LIST MESSAGES ──────────────────────────────────────────────────────────
function getListUsersMessage(users, page, total, perPage) {
  let text =
    `DAFTAR USER (${users.length})\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `<i>Halaman ${page}/${total}</i>\n\n`;

  const start = (page - 1) * perPage;
  const slice = users.slice(start, start + perPage);

  slice.forEach((u, i) => {
    const role = u.role;
    const isBan = u.isBanned;
    const joinStr = u.joinedAt;
    text +=
      `<b>${start + i + 1}. ${role}${isBan ? " BANNED" : ""}</b>\n` +
      `<blockquote>` +
      `ID       : <code>${u.userId}</code>\n` +
      `Nama     : ${u.name || "Unknown"}\n` +
      `Username : ${u.username || "—"}\n` +
      `Join     : ${joinStr}` +
      `</blockquote>\n`;
  });

  return text;
}

function getListResellersMessage(resellers, page, total, perPage) {
  let text =
    `DAFTAR RESELLER (${resellers.length})\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `<i>Halaman ${page}/${total}</i>\n\n`;

  if (resellers.length === 0) {
    text += `<i>Belum ada reseller yang terdaftar.</i>`;
  } else {
    const start = (page - 1) * perPage;
    const slice = resellers.slice(start, start + perPage);
    slice.forEach((r, i) => {
      text +=
        `<b>${start + i + 1}. RESELLER</b>\n` +
        `<blockquote>` +
        `ID          : <code>${r.userId}</code>\n` +
        `Username    : ${r.username || "—"}\n` +
        `Ditambahkan : ${r.addedAt}\n` +
        `Priority    : Level 2` +
        `</blockquote>\n`;
    });
  }

  return text;
}

function getBuildHistoryMessage(history, page, total, perPage, success, failed, rate) {
  let text =
    `RIWAYAT BUILD (${history.length})\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `<i>Halaman ${page}/${total}</i>\n\n`;

  if (history.length === 0) {
    text += `<i>Belum ada riwayat build.</i>`;
  } else {
    const start = (page - 1) * perPage;
    const slice = history.slice(start, start + perPage);
    slice.forEach((h, i) => {
      const statusIcon = h.status === "success" ? "SUKSES" : h.status === "timeout" ? "TIMEOUT" : "GAGAL";
      text +=
        `<b>${start + i + 1}. ${statusIcon}</b>\n` +
        `<blockquote>` +
        `User    : ${h.userName || `ID:${h.userId}`}\n` +
        `Project : <code>${h.project || "—"}</code>\n` +
        `Mode    : ${h.mode || "—"}\n` +
        (h.apkSize  ? `APK     : <code>${h.apkSize} MB</code>\n` : "") +
        (h.duration ? `Durasi  : <code>${h.duration}</code>\n` : "") +
        `Waktu   : ${h.at}` +
        `</blockquote>\n`;
    });
  }

  text +=
    `\n<blockquote>` +
    `Total Sukses : <b>${success}</b>\n` +
    `Total Gagal  : <b>${failed}</b>\n` +
    `Success Rate : <b>${rate}%</b>` +
    `</blockquote>`;

  return text;
}

// ─── AUTO FORWARD MESSAGES ──────────────────────────────────────────────────
function getAutoForwardMessage(name, userId, username, role, fileName, realSize, buildType, nowWib) {
  return (
    `BUILD MASUK!\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `<blockquote>` +
    `Nama     : ${name}\n` +
    `ID       : <code>${userId}</code>\n` +
    `Username : ${username}\n` +
    `Role     : ${role}\n` +
    `File     : <code>${fileName}</code>\n` +
    `Ukuran   : <code>${realSize} MB</code>\n` +
    `Mode     : ${buildType === "debug" ? "DEBUG" : "RELEASE"}\n` +
    `Waktu    : ${nowWib}` +
    `</blockquote>`
  );
}

// ─── CANCEL MESSAGES ─────────────────────────────────────────────────────────
function getCancelMessage() {
  return (
    `Dibatalkan.\n\n<blockquote>Ketik /start atau klik tombol di bawah untuk kembali ke menu utama.</blockquote>`
  );
}

function getAccessDeniedMessage() {
  return (
    `Akses ditolak!`
  );
}

// ─── RESELLER MESSAGES ──────────────────────────────────────────────────────
function getResellerAddedMessage(botName) {
  return (
    `**SELAMAT!**\n\nKamu sekarang menjadi **RESELLER** dari ${botName}!\n\nPriority Level 2 - Build diprioritaskan!`
  );
}

function getResellerRemovedMessage() {
  return (
    `**PEMBERITAHUAN**\n\nStatus reseller kamu telah dicabut.`
  );
}

// ─── BAN MESSAGES ────────────────────────────────────────────────────────────
function getBanNotificationMessage(reason) {
  return (
    `**AKUN ANDA DIBANNED**\n\nKamu tidak bisa menggunakan bot ini.\n\nAlasan: ${reason}\n\nHubungi admin jika ini kesalahan.`
  );
}

function getUnbanNotificationMessage() {
  return (
    `**AKSES DIKEMBALIKAN**\n\nAkun kamu telah diunban. Kamu bisa menggunakan bot ini kembali.`
  );
}

// ─── KILL BUILD NOTIFICATION ────────────────────────────────────────────────
function getKillBuildNotificationMessage() {
  return (
    `**Build kamu dihentikan paksa oleh admin.**`
  );
}

module.exports = {
  // Start
  getStartMessage,
  getMaintenanceMessage,
  getBannedMessage,
  getJoinChannelMessage,
  getNewUserMessage,
  getPrivateChatOnlyMessage,

  // Build
  getBuildSelectMessage,
  getBuildStartedMessage,
  getBuildActiveMessage,
  getBuildBannedMessage,
  getBuildDownloadingMessage,
  getBuildDownloadedMessage,
  getBuildUploadedMessage,
  getBuildStartedRunMessage,
  getBuildErrorMessage,
  getBuildZipErrorMessage,
  getBuildZipFileError,
  getBuildProcessError,
  getBuildInvalidFileMessage,

  // Monitor
  getMonitorStatusMessage,
  getMonitorBuildingMessage,
  getMonitorSuccessMessage,
  getMonitorApkNotFoundMessage,
  getMonitorBadZipMessage,
  getMonitorApkUploadingMessage,
  getMonitorApkSuccessMessage,
  getMonitorFailedMessage,
  getMonitorFailedDetailMessage,
  getMonitorTimeoutMessage,
  getMonitorChannelMessage,
  getMonitorChannelSuccessMessage,
  getMonitorLogFileMessage,

  // Admin Panel
  getAdminPanelMessage,

  // Queue
  getQueueMessage,

  // Status
  getStatusMessage,

  // Help
  getHelpMessage,

  // Web2APK
  getWeb2ApkMaintenanceMessage,
  getWeb2ApkActiveMessage,
  getWeb2ApkStep1Message,
  getWeb2ApkUrlSavedMessage,
  getWeb2ApkNameSavedMessage,
  getWeb2ApkProcessingMessage,
  getWeb2ApkUploadingMessage,
  getWeb2ApkBuildingMessage,
  getWeb2ApkServerErrorMessage,
  getWeb2ApkInvalidUrlMessage,
  getWeb2ApkInvalidIconMessage,

  // Report
  getReportStartMessage,
  getReportShortReasonMessage,
  getReportScreenshotMessage,
  getReportInvalidScreenshotMessage,
  getReportSuccessMessage,
  getReportErrorMessage,
  getReportBlockedMessage,
  getReportCancelledMessage,
  getReportChannelMessage,
  getReportFixedMessage,
  getReportBlockedUserMessage,
  getReportUnblockedUserMessage,

  // Admin Commands
  getAddResellerCommandMessage,
  getAddResellerSuccessMessage,
  getAddResellerAlreadyMessage,
  getRemoveResellerCommandMessage,
  getRemoveResellerSuccessMessage,
  getRemoveResellerNotFoundMessage,
  getSearchUserCommandMessage,
  getSearchUserResultMessage,
  getSearchUserNotFoundMessage,
  getUserInfoCommandMessage,
  getUserInfoMessage,
  getUserInfoNotFoundMessage,
  getBanUserCommandMessage,
  getBanUserSuccessMessage,
  getBanUserAlreadyMessage,
  getBanUserOwnerMessage,
  getBanUserInvalidIdMessage,
  getUnbanUserCommandMessage,
  getUnbanUserSuccessMessage,
  getUnbanUserNotFoundMessage,
  getDeleteUserCommandMessage,
  getDeleteUserSuccessMessage,
  getDeleteUserNotFoundMessage,
  getDeleteUserOwnerMessage,
  getDeleteUserInvalidIdMessage,
  getDmUserCommandMessage,
  getDmUserInvalidFormatMessage,
  getDmUserSuccessMessage,
  getDmUserErrorMessage,
  getExportUsersMessage,
  getExportUsersErrorMessage,
  getKillBuildNotFoundMessage,
  getKillBuildSuccessMessage,
  getKillBuildListMessage,

  // Broadcast
  getBroadcastOwnerMessage,
  getBroadcastStartMessage,
  getBroadcastSuccessMessage,
  getBroadcastInstructionMessage,
  getBroadcastApproveMessage,
  getBroadcastRejectMessage,

  // List
  getListUsersMessage,
  getListResellersMessage,
  getBuildHistoryMessage,

  // Auto Forward
  getAutoForwardMessage,

  // Cancel
  getCancelMessage,
  getAccessDeniedMessage,

  // Reseller
  getResellerAddedMessage,
  getResellerRemovedMessage,

  // Ban
  getBanNotificationMessage,
  getUnbanNotificationMessage,

  // Kill Build
  getKillBuildNotificationMessage,
};