const { Button } = require("telegram/tl/custom/button");

// ─── BUILD BUTTONS ────────────────────────────────────────────────────────────
function buildButtons(rows) {
  return rows.map(row =>
    row.map(btn => btn.url ? Button.url(btn.text, btn.url) : Button.inline(btn.text, Buffer.from(btn.data)))
  );
}

// ─── START MENU ───────────────────────────────────────────────────────────────
function getStartMenu(isPrivileged, isOwner) {
  const btns = [
    [{ text: "𝐁𝐮𝐢𝐥𝐝 𝐟𝐥𝐮𝐭𝐭𝐞𝐫", data: "build" }, { text: "𝐖𝐞𝐛 𝐭𝐨 𝐀𝐏𝐊", data: "web2apk" }],
    [{ text: "𝐀𝐧𝐭𝐫𝐢𝐚𝐧 𝐁𝐮𝐢𝐥𝐝", data: "queue" }, { text: "𝐒𝐭𝐚𝐭𝐮𝐬 𝐁𝐨𝐭", data: "status" }],
    [{ text: "𝐏𝐚𝐧𝐝𝐮𝐚𝐧", data: "help" }, { text: "𝐑𝐞𝐩𝐨𝐫𝐭 𝐁𝐮𝐠", data: "user_start_lapor" }],
  ];
  if (isPrivileged) btns.push([{ text: "𝐀𝐝𝐦𝐢𝐧 𝐏𝐚𝐧𝐞𝐥", data: "admin_panel" }]);
  if (isOwner) btns.push([{ text: "𝐎𝐰𝐧𝐞𝐫 𝐏𝐚𝐧𝐞𝐥", data: "admin_panel" }]);
  return btns;
}

// ─── BUILD MENU ───────────────────────────────────────────────────────────────
function getBuildMenu() {
  return [
    [{ text: "𝐃𝐞𝐛𝐮𝐠 𝐁𝐮𝐢𝐥𝐝", data: "build_debug" }, { text: "𝐑𝐞𝐥𝐞𝐚𝐬𝐞 𝐁𝐮𝐢𝐥𝐝", data: "build_release" }],
    [{ text: "𝐊𝐞𝐦𝐛𝐚𝐥𝐢", data: "start" }],
  ];
}

// ─── ADMIN PANEL ──────────────────────────────────────────────────────────────
function getAdminPanel(maint, isOwner) {
  const btns = [
    [{ text: "𝐀𝐝𝐝 𝐑𝐞𝐬𝐬", data: "admin_add_reseller" }, { text: "𝐑𝐞𝐦𝐨𝐯𝐞 𝐑𝐞𝐬𝐞𝐥𝐥𝐞𝐫", data: "admin_remove_reseller" }],
    [{ text: "𝐋𝐢𝐬𝐭 𝐔𝐬𝐞𝐫", data: "listusers_page_1" }, { text: "𝐋𝐢𝐬𝐭 𝐑𝐞𝐬𝐞𝐥𝐥𝐞𝐫", data: "listresellers_page_1" }],
    [{ text: "𝐂𝐚𝐫𝐢 𝐔𝐬𝐞𝐫", data: "admin_search_user" }, { text: "𝐈𝐧𝐟𝐨 𝐔𝐬𝐞𝐫", data: "admin_userinfo" }],
    [{ text: "𝐁𝐚𝐧 𝐔𝐬𝐞𝐫", data: "admin_ban_user" }, { text: "𝐔𝐧𝐛𝐚𝐧 𝐔𝐬𝐞𝐫", data: "admin_unban_user" }],
    [{ text: "𝐊𝐢𝐥𝐥 𝐁𝐮𝐢𝐥𝐝", data: "admin_list_builds" }, { text: "𝐁𝐮𝐢𝐥𝐝 𝐇𝐢𝐬𝐭𝐨𝐫𝐲", data: "buildhistory_page_1" }],
    [{ text: "𝐄𝐱𝐩𝐨𝐫𝐭 𝐔𝐬𝐞𝐫𝐬", data: "admin_export_users" }, { text: "𝐃𝐌 𝐤𝐞 𝐔𝐬𝐞𝐫", data: "admin_dm_user" }],
    [{ text: `𝐌𝐚𝐢𝐧𝐭𝐞𝐧𝐚𝐧𝐜𝐞 ${maint ? "𝐎𝐅𝐅" : "𝐎𝐍"}`, data: "admin_toggle_maint" }],
    [{ text: "𝐊𝐞𝐦𝐛𝐚𝐥𝐢 𝐤𝐞 𝐌𝐞𝐧𝐮", data: "start" }],
  ];
  if (isOwner) btns.splice(btns.length - 1, 0, [{ text: "𝐑𝐞𝐬𝐞𝐭 𝐒𝐭𝐚𝐭𝐬", data: "admin_reset_stats" }]);
  return btns;
}

// ─── QUEUE MENU ───────────────────────────────────────────────────────────────
function getQueueMenu() {
  return [[{ text: "𝐑𝐞𝐟𝐫𝐞𝐬𝐡", data: "queue" }, { text: "𝐌𝐞𝐧𝐮 𝐔𝐭𝐚𝐦𝐚", data: "start" }]];
}

// ─── STATUS MENU ──────────────────────────────────────────────────────────────
function getStatusMenu() {
  return [[{ text: "𝐑𝐞𝐟𝐫𝐞𝐬𝐡", data: "status" }, { text: "𝐌𝐞𝐧𝐮 𝐔𝐭𝐚𝐦𝐚", data: "start" }]];
}

// ─── HELP MENU ────────────────────────────────────────────────────────────────
function getHelpMenu() {
  return [
    [{ text: "𝐌𝐮𝐥𝐚𝐢 𝐁𝐮𝐢𝐥𝐝 𝐀𝐏𝐊", data: "build" }, { text: "𝐖𝐞𝐛 𝐭𝐨 𝐀𝐏𝐊", data: "web2apk" }],
    [{ text: "𝐌𝐞𝐧𝐮 𝐔𝐭𝐚𝐦𝐚", data: "start" }],
  ];
}

// ─── JOIN CHANNEL MENU ────────────────────────────────────────────────────────
function getJoinChannelMenu(channels) {
  return [
    [
      { text: "𝐉𝐎𝐈𝐍 𝟏", url: `https://t.me/${channels[0].replace("@", "")}` },
      { text: "𝐉𝐎𝐈𝐍 𝟐", url: `https://t.me/${channels[1].replace("@", "")}` },
      { text: "𝐉𝐎𝐈𝐍 𝟑", url: `https://t.me/${channels[2].replace("@", "")}` }
    ],
    [
      { text: "𝐉𝐎𝐈𝐍 𝟒", url: `https://t.me/${channels[3].replace("@", "")}` },
      { text: "𝐉𝐎𝐈𝐍 𝟓", url: `https://t.me/${channels[4].replace("@", "")}` },
      { text: "𝐉𝐎𝐈𝐍 𝟔", url: `https://t.me/${channels[5].replace("@", "")}` }
    ],
    [
      { text: "𝐕𝐞𝐫𝐢𝐟𝐢𝐤𝐚𝐬𝐢 𝐉𝐨𝐢𝐧", data: "check_join" }
    ]
  ];
}

// ─── MAINTENANCE MENU ─────────────────────────────────────────────────────────
function getMaintenanceMenu(channelUsername) {
  return [[{ text: "𝐂𝐡𝐚𝐧𝐧𝐞𝐥 𝐊𝐚𝐦𝐢", url: `https://t.me/${channelUsername.replace("@", "")}` }]];
}

// ─── CANCEL MENU ──────────────────────────────────────────────────────────────
function getCancelMenu() {
  return [[{ text: "𝐁𝐚𝐭𝐚𝐥𝐤𝐚𝐧", data: "cancel" }]];
}

// ─── CANCEL REPORT MENU ──────────────────────────────────────────────────────
function getCancelReportMenu() {
  return [[{ text: "𝐁𝐚𝐭𝐚𝐥𝐤𝐚𝐧 𝐋𝐚𝐩𝐨𝐫𝐚𝐧", data: "user_cancel_lapor" }]];
}

// ─── WEB2APK MENU ─────────────────────────────────────────────────────────────
function getWeb2ApkMenu() {
  return [[{ text: "𝐁𝐚𝐭𝐚𝐥𝐤𝐚𝐧", data: "cancel" }]];
}

// ─── SEARCH USER MENU ────────────────────────────────────────────────────────
function getSearchUserMenu() {
  return [[{ text: "𝐀𝐝𝐦𝐢𝐧 𝐏𝐚𝐧𝐞𝐥", data: "admin_panel" }]];
}

// ─── USER INFO MENU ──────────────────────────────────────────────────────────
function getUserInfoMenu(isRes, isBan, num) {
  const btns = [
    isRes
      ? [{ text: "𝐑𝐞𝐦𝐨𝐯𝐞 𝐑𝐞𝐬𝐞𝐥𝐥𝐞𝐫", data: `adm_rm_reseller_${num}` }]
      : [{ text: "𝐀𝐝𝐝 𝐑𝐞𝐬𝐞𝐥𝐥𝐞𝐫", data: `adm_add_reseller_${num}` }],
    isBan
      ? [{ text: "𝐔𝐧𝐛𝐚𝐧 𝐔𝐬𝐞𝐫", data: `adm_unban_${num}` }]
      : [{ text: "𝐁𝐚𝐧 𝐔𝐬𝐞𝐫", data: `adm_ban_${num}` }],
    [{ text: "𝐀𝐝𝐦𝐢𝐧 𝐏𝐚𝐧𝐞𝐥", data: "admin_panel" }],
  ];
  return btns;
}

// ─── ADMIN RESULT MENU ────────────────────────────────────────────────────────
function getAdminResultMenu() {
  return [[{ text: "𝐀𝐝𝐦𝐢𝐧 𝐏𝐚𝐧𝐞𝐥", data: "admin_panel" }]];
}

// ─── KILL BUILD MENU ──────────────────────────────────────────────────────────
function getKillBuildMenu(jobs) {
  const btns = [
    ...jobs.map(j => {
      const usr = j.fullName && j.fullName !== "Unknown User" ? j.fullName.split(" ")[0] : (j.username || `U${j.userId}`);
      return [{ text: `𝐊𝐢𝐥𝐥: ${usr}`, data: `kill_build_${j.userId}` }];
    }),
    [{ text: "𝐀𝐝𝐦𝐢𝐧 𝐏𝐚𝐧𝐞𝐥", data: "admin_panel" }],
  ];
  return btns;
}

// ─── KILL BUILD EMPTY MENU ────────────────────────────────────────────────────
function getKillBuildEmptyMenu() {
  return [[{ text: "𝐀𝐝𝐦𝐢𝐧 𝐏𝐚𝐧𝐞𝐥", data: "admin_panel" }]];
}

// ─── BROADCAST APPROVE MENU ──────────────────────────────────────────────────
function getBroadcastApproveMenu(userId) {
  return [[
    { text: "𝐈𝐳𝐢𝐧𝐤𝐚𝐧", data: `broadcast_approve_${userId}` },
    { text: "𝐓𝐨𝐥𝐚𝐤", data: `broadcast_reject_${userId}` }
  ]];
}

// ─── LIST USERS MENU ──────────────────────────────────────────────────────────
function getListUsersMenu(page, total) {
  const nav = [];
  if (page > 1) nav.push({ text: "𝐏𝐫𝐞𝐯", data: `listusers_page_${page - 1}` });
  nav.push({ text: `${page}/${total}`, data: "noop" });
  if (page < total) nav.push({ text: "𝐍𝐞𝐱𝐭", data: `listusers_page_${page + 1}` });

  return [
    nav,
    [{ text: "𝐂𝐚𝐫𝐢 𝐔𝐬𝐞𝐫", data: "admin_search_user" }, { text: "𝐄𝐱𝐩𝐨𝐫𝐭", data: "admin_export_users" }],
    [{ text: "𝐀𝐝𝐦𝐢𝐧 𝐏𝐚𝐧𝐞𝐥", data: "admin_panel" }],
  ];
}

// ─── LIST RESELLERS MENU ──────────────────────────────────────────────────────
function getListResellersMenu(page, total) {
  const nav = [];
  if (page > 1) nav.push({ text: "𝐏𝐫𝐞𝐯", data: `listresellers_page_${page - 1}` });
  nav.push({ text: `${page}/${total}`, data: "noop" });
  if (page < total) nav.push({ text: "𝐍𝐞𝐱𝐭", data: `listresellers_page_${page + 1}` });

  return [
    nav,
    [{ text: "𝐀𝐝𝐦𝐢𝐧 𝐏𝐚𝐧𝐞𝐥", data: "admin_panel" }],
  ];
}

// ─── BUILD HISTORY MENU ──────────────────────────────────────────────────────
function getBuildHistoryMenu(page, total) {
  const nav = [];
  if (page > 1) nav.push({ text: "𝐏𝐫𝐞𝐯", data: `buildhistory_page_${page - 1}` });
  nav.push({ text: `${page}/${total}`, data: "noop" });
  if (page < total) nav.push({ text: "𝐍𝐞𝐱𝐭", data: `buildhistory_page_${page + 1}` });

  return [
    nav,
    [{ text: "𝐀𝐝𝐦𝐢𝐧 𝐏𝐚𝐧𝐞𝐥", data: "admin_panel" }],
  ];
}

// ─── REPORT ADMIN MENU ────────────────────────────────────────────────────────
function getReportAdminMenu(tid, action) {
  if (action === "fix") {
    return [[{ text: "𝐁𝐥𝐨𝐤", data: `adm_blk_${tid}` }]];
  } else if (action === "block") {
    return [[{ text: "𝐔𝐧𝐛𝐥𝐨𝐤", data: `adm_unblk_${tid}` }]];
  } else if (action === "unblock") {
    return [[{ text: "𝐒𝐞𝐥𝐞𝐬𝐚𝐢", data: `adm_fix_${tid}` }, { text: "𝐁𝐥𝐨𝐤𝐢𝐫", data: `adm_blk_${tid}` }]];
  }
  return [];
}

// ─── WEB2APK CHANNEL MENU ────────────────────────────────────────────────────
function getWeb2ApkChannelMenu(botUsername) {
  return [[{ text: "𝐌𝐚𝐮 𝐁𝐮𝐢𝐥𝐝? 𝐆𝐚𝐬𝐬!!!", url: `https://t.me/${botUsername}?start` }]];
}

module.exports = {
  buildButtons,
  getStartMenu,
  getBuildMenu,
  getAdminPanel,
  getQueueMenu,
  getStatusMenu,
  getHelpMenu,
  getJoinChannelMenu,
  getMaintenanceMenu,
  getCancelMenu,
  getCancelReportMenu,
  getWeb2ApkMenu,
  getSearchUserMenu,
  getUserInfoMenu,
  getAdminResultMenu,
  getKillBuildMenu,
  getKillBuildEmptyMenu,
  getBroadcastApproveMenu,
  getListUsersMenu,
  getListResellersMenu,
  getBuildHistoryMenu,
  getReportAdminMenu,
  getWeb2ApkChannelMenu,
};