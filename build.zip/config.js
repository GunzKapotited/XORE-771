module.exports = {
  BOT_NAME: "𝐁𝐎𝐓 𝐁𝐔𝐈𝐋𝐃 𝐁𝐘 𝐆𝐔𝐍𝐙",
  BOT_VERSION: "𝟏.𝟏.𝟎",
  BOT_TOKEN: process.env.BOT_TOKEN || "8653894425:AAH1SlbM5v_SzikKHuiFrN12Eamt-d1BwEE",
  ADMIN_IDS: (process.env.ADMIN_IDS || "8212614573").split(",").map(Number).filter(Boolean),

  
  CHANNEL_USERNAME: process.env.CHANNEL_USERNAME || "@infobotbuildgunz",
CHANNEL_USERNAME2: process.env.CHANNEL_USERNAME2 || "@gballpublic",
CHANNEL_USERNAME3: process.env.CHANNEL_USERNAME3 || "@gballpublic",
CHANNEL_USERNAME4: process.env.CHANNEL_USERNAME4 || "@gballpublic",
CHANNEL_USERNAME5: process.env.CHANNEL_USERNAME5 || "@gballpublic",
CHANNEL_USERNAME6: process.env.CHANNEL_USERNAME6 || "@gballpublic",
  
  OWNER_ID: parseInt(process.env.OWNER_ID || "8212614573"),

  WELCOME_PHOTO: process.env.WELCOME_PHOTO || "https://iili.io/Cxo7r8B.png",
  NEW_USER: process.env.NEW_USER || "https://iili.io/Cxo7r8B.png",
  TMP_DIR: "./tmp",

  BUILD_TIMEOUT_MS: 30 * 60 * 1000,
  POLL_INTERVAL_MS: 7000,       
  WEB2APK_MAINTENANCE: false,
};
