const express = require('express');
const multer = require('multer');
const AdmZip = require('adm-zip');
const fs = require('fs-extra');
const { exec } = require('child_process');
const path = require('path');
const app = express();

app.use(express.static('public'));
app.use(express.json());

const upload = multer({ dest: 'uploads/' });

// Build status storage dengan history
let buildStatus = {
  isBuilding: false,
  progress: 0,
  message: '',
  apkPath: null,
  error: null,
  timestamp: null,
  buildId: null
};

// Simpan history build untuk auto refresh
let buildHistory = [];

app.post('/build', upload.single('flutterProject'), async (req, res) => {
  if (buildStatus.isBuilding) {
    return res.status(400).json({ error: 'Build sedang berjalan' });
  }

  if (!req.file) {
    return res.status(400).json({ error: 'File ZIP tidak ditemukan' });
  }

  const buildId = Date.now();
  
  buildStatus = {
    isBuilding: true,
    progress: 0,
    message: 'Memulai proses build...',
    apkPath: null,
    error: null,
    timestamp: buildId,
    buildId: buildId
  };

  // Simpan ke history
  buildHistory.unshift({ ...buildStatus });
  if (buildHistory.length > 10) buildHistory.pop();

  const buildDir = path.join(__dirname, 'builds', `build_${buildId}`);
  const extractDir = path.join(buildDir, 'source');

  // Jalankan build async
  runBuild(buildId, req.file.path, buildDir, extractDir);
  
  res.json({ success: true, buildId: buildId });
});

async function runBuild(buildId, zipPath, buildDir, extractDir) {
  try {
    await fs.ensureDir(extractDir);
    
    // Update status function
    const updateStatus = (progress, message, apkPath = null, error = null) => {
      buildStatus.progress = progress;
      buildStatus.message = message;
      if (apkPath) buildStatus.apkPath = apkPath;
      if (error) buildStatus.error = error;
      
      // Update history
      const historyIndex = buildHistory.findIndex(h => h.buildId === buildId);
      if (historyIndex !== -1) {
        buildHistory[historyIndex] = { ...buildStatus };
      }
    };
    
    // Extract ZIP
    updateStatus(10, '📦 Mengekstrak file ZIP...');
    const zip = new AdmZip(zipPath);
    zip.extractAllTo(extractDir, true);
    
    // Find flutter project
    updateStatus(20, '🔍 Mencari project Flutter...');
    let projectRoot = await findFlutterProject(extractDir);
    if (!projectRoot) {
      throw new Error('pubspec.yaml tidak ditemukan dalam ZIP');
    }
    
    // Flutter clean
    updateStatus(30, '🧹 Membersihkan project...');
    await runCommand('flutter clean', projectRoot);
    
    // Flutter pub get
    updateStatus(40, '📦 Menginstall dependencies...');
    await runCommand('flutter pub get', projectRoot);
    
    // Build APK
    updateStatus(60, '🔨 Membuild APK (mengabaikan error)...');
    try {
      await runCommand('flutter build apk --release', projectRoot, true);
      updateStatus(80, '✅ Build berhasil, mencari file APK...');
    } catch (buildError) {
      updateStatus(80, `⚠️ Build selesai dengan peringatan: ${buildError.message.substring(0, 100)}`);
    }
    
    // Find APK
    const apkPath = await findApk(projectRoot);
    
    if (!apkPath) {
      throw new Error('File APK tidak ditemukan setelah build');
    }
    
    // Copy APK
    updateStatus(90, '💾 Menyimpan file APK...');
    const publicApkDir = path.join(__dirname, 'public', 'downloads');
    await fs.ensureDir(publicApkDir);
    const apkFileName = `app_${buildId}.apk`;
    const apkDestPath = path.join(publicApkDir, apkFileName);
    await fs.copy(apkPath, apkDestPath);
    
    // Selesai
    updateStatus(100, '✨ Build selesai! APK siap didownload.', `/downloads/${apkFileName}`);
    buildStatus.isBuilding = false;
    
    // Cleanup
    setTimeout(() => {
      fs.remove(buildDir).catch(console.error);
      fs.unlink(zipPath).catch(console.error);
    }, 60000);
    
  } catch (error) {
    buildStatus.isBuilding = false;
    buildStatus.error = error.message;
    buildStatus.message = `❌ Error: ${error.message}`;
    
    const historyIndex = buildHistory.findIndex(h => h.buildId === buildId);
    if (historyIndex !== -1) {
      buildHistory[historyIndex] = { ...buildStatus };
    }
  }
}

app.get('/status', (req, res) => {
  res.json(buildStatus);
});

app.get('/status/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  
  let lastStatus = JSON.stringify(buildStatus);
  
  const interval = setInterval(() => {
    const currentStatus = JSON.stringify(buildStatus);
    if (currentStatus !== lastStatus) {
      lastStatus = currentStatus;
      res.write(`data: ${currentStatus}\n\n`);
    }
  }, 500);
  
  req.on('close', () => {
    clearInterval(interval);
    res.end();
  });
});

app.get('/history', (req, res) => {
  res.json(buildHistory);
});

app.listen(4500, () => {
  console.log('🚀 Server running on http://localhost:3000');
  console.log('📱 Flutter APK Builder siap digunakan!');
});

// Helper functions (sama seperti sebelumnya)
async function findFlutterProject(dir) {
  const files = await fs.readdir(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    const stat = await fs.stat(fullPath);
    if (stat.isDirectory()) {
      const pubspecPath = path.join(fullPath, 'pubspec.yaml');
      if (await fs.pathExists(pubspecPath)) {
        return fullPath;
      }
      const subResult = await findFlutterProject(fullPath);
      if (subResult) return subResult;
    }
  }
  return null;
}

async function findApk(projectRoot) {
  const apkPaths = [
    path.join(projectRoot, 'build', 'app', 'outputs', 'flutter-apk', 'app-release.apk'),
    path.join(projectRoot, 'build', 'app', 'outputs', 'apk', 'release', 'app-release.apk'),
    path.join(projectRoot, 'build', 'app', 'outputs', 'apk', 'release', 'app.apk')
  ];
  
  for (const apkPath of apkPaths) {
    if (await fs.pathExists(apkPath)) {
      return apkPath;
    }
  }
  
  const buildDir = path.join(projectRoot, 'build');
  if (await fs.pathExists(buildDir)) {
    const apkFiles = await findFiles(buildDir, '.apk');
    if (apkFiles.length > 0) return apkFiles[0];
  }
  
  return null;
}

async function findFiles(dir, extension) {
  const results = [];
  const files = await fs.readdir(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    const stat = await fs.stat(fullPath);
    if (stat.isDirectory()) {
      results.push(...await findFiles(fullPath, extension));
    } else if (file.endsWith(extension)) {
      results.push(fullPath);
    }
  }
  return results;
}

function runCommand(command, cwd, ignoreErrors = false) {
  return new Promise((resolve, reject) => {
    exec(command, { cwd, maxBuffer: 50 * 1024 * 1024 }, (error, stdout, stderr) => {
      if (error && !ignoreErrors) {
        reject(new Error(stderr || stdout || error.message));
      } else {
        resolve({ stdout, stderr });
      }
    });
  });
}