const express = require('express');
const multer = require('multer');
const AdmZip = require('adm-zip');
const fs = require('fs-extra');
const { exec } = require('child_process');
const path = require('path');
const app = express();

app.use(express.static('public'));
app.use(express.json());

const upload = multer({ dest: 'uploads/' });

let buildStatus = {
  isBuilding: false,
  progress: 0,
  message: 'Menunggu upload...',
  apkPath: null,
  error: null,
  timestamp: null
};

// SSE clients
let clients = [];

// Endpoint SSE untuk auto refresh
app.get('/status/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('Access-Control-Allow-Origin', '*');

  const clientId = Date.now();
  const newClient = { id: clientId, res };
  clients.push(newClient);

  // Kirim status awal
  res.write(`data: ${JSON.stringify(buildStatus)}\n\n`);

  req.on('close', () => {
    clients = clients.filter(client => client.id !== clientId);
  });
});

// Broadcast status ke semua client
function broadcastStatus() {
  const data = JSON.stringify(buildStatus);
  clients.forEach(client => {
    client.res.write(`data: ${data}\n\n`);
  });
}

// Upload endpoint
app.post('/build', upload.single('flutterProject'), async (req, res) => {
  if (buildStatus.isBuilding) {
    return res.status(400).json({ error: 'Build sedang berjalan' });
  }

  if (!req.file) {
    return res.status(400).json({ error: 'File ZIP tidak ditemukan' });
  }

  buildStatus = {
    isBuilding: true,
    progress: 0,
    message: 'Memulai proses build...',
    apkPath: null,
    error: null,
    timestamp: Date.now()
  };
  broadcastStatus();

  const buildId = Date.now();
  const buildDir = path.join(__dirname, 'builds', `build_${buildId}`);
  const extractDir = path.join(buildDir, 'source');

  // Jalankan build async
  runBuild(buildId, req.file.path, buildDir, extractDir);

  res.json({ success: true, buildId: buildId });
});

async function runBuild(buildId, zipPath, buildDir, extractDir) {
  const updateStatus = (progress, message, apkPath = null, error = null) => {
    buildStatus.progress = progress;
    buildStatus.message = message;
    if (apkPath) buildStatus.apkPath = apkPath;
    if (error) buildStatus.error = error;
    broadcastStatus();
    console.log(`[${progress}%] ${message}`);
  };

  try {
    // 1. UNZIP
    updateStatus(5, '📦 Mengekstrak file ZIP...');
    await fs.ensureDir(extractDir);
    const zip = new AdmZip(zipPath);
    zip.extractAllTo(extractDir, true);
    console.log(`✅ ZIP extracted to: ${extractDir}`);

    // 2. CARI PUBSPEC.YAML DI MANA PUN
    updateStatus(10, '🔍 Mencari pubspec.yaml...');
    let projectRoot = null;

    async function cariPubspec(dir) {
      try {
        const files = await fs.readdir(dir);
        for (const file of files) {
          const fullPath = path.join(dir, file);
          const stat = await fs.stat(fullPath);
          if (file === 'pubspec.yaml') {
            console.log(`✅ Ketemu pubspec.yaml di: ${fullPath}`);
            return dir;
          }
          if (stat.isDirectory()) {
            const result = await cariPubspec(fullPath);
            if (result) return result;
          }
        }
      } catch (e) { }
      return null;
    }

    projectRoot = await cariPubspec(extractDir);

    if (!projectRoot) {
      updateStatus(15, '⚠️ pubspec.yaml tidak ketemu, tetap lanjut...');
      projectRoot = extractDir;
    } else {
      updateStatus(15, `✅ Project ditemukan: ${path.basename(projectRoot)}`);
    }

    // 3. FLUTTER CLEAN - IGNORE ERROR
    updateStatus(25, '🧹 Flutter clean...');
    try {
      await runCommand('flutter clean', projectRoot, true);
    } catch (e) { console.log('Clean error ignored:', e.message); }

    // 4. FLUTTER PUB GET - IGNORE ERROR
    updateStatus(35, '📦 Install dependencies (flutter pub get)...');
    try {
      await runCommand('flutter pub get', projectRoot, true);
    } catch (e) { console.log('Pub get error ignored:', e.message); }

    // 5. BUILD APK - FORCE, IGNORE ALL ERRORS
    updateStatus(50, '🔨 Building APK (ignore semua error)...');
    try {
      await runCommand('flutter build apk --release', projectRoot, true);
      updateStatus(70, '✅ Build process selesai, mencari APK...');
    } catch (e) {
      console.log('Build error ignored, tetap lanjut:', e.message);
      updateStatus(70, '⚠️ Build selesai dengan warning, tetap cari APK...');
    }

    // 6. CARI APK DI MANA PUN
    updateStatus(80, '🔍 Mencari file APK...');
    let apkPath = null;

    async function cariApk(dir) {
      try {
        const files = await fs.readdir(dir);
        for (const file of files) {
          const fullPath = path.join(dir, file);
          const stat = await fs.stat(fullPath);
          if (file.endsWith('.apk')) {
            console.log(`✅ Ketemu APK di: ${fullPath}`);
            return fullPath;
          }
          if (stat.isDirectory()) {
            const result = await cariApk(fullPath);
            if (result) return result;
          }
        }
      } catch (e) { }
      return null;
    }

    const buildFolder = path.join(projectRoot, 'build');
    if (await fs.pathExists(buildFolder)) {
      apkPath = await cariApk(buildFolder);
    }

    // 7. KALO APK GAK KETEMU, COBA PAKSA DENGAN FLUTTER BUILD LAGI TANPA --RELEASE
    if (!apkPath) {
      updateStatus(85, '⚠️ APK belum ketemu, coba build ulang tanpa --release...');
      try {
        await runCommand('flutter build apk', projectRoot, true);
        apkPath = await cariApk(buildFolder);
      } catch (e) { }
    }

    // 8. SIMPAN APK
    if (apkPath && await fs.pathExists(apkPath)) {
      updateStatus(90, '💾 Menyimpan APK...');
      const publicApkDir = path.join(__dirname, 'public', 'downloads');
      await fs.ensureDir(publicApkDir);
      const apkFileName = `app_${buildId}.apk`;
      const apkDestPath = path.join(publicApkDir, apkFileName);
      await fs.copy(apkPath, apkDestPath);

      buildStatus.apkPath = `/downloads/${apkFileName}`;
      updateStatus(100, '✅ SUKSES! APK siap download', buildStatus.apkPath);
    } else {
      updateStatus(100, '⚠️ Build selesai tapi APK tidak ditemukan. Cek folder build manually.');
      buildStatus.error = 'APK tidak ditemukan, tapi proses build sudah selesai';
    }

    buildStatus.isBuilding = false;
    broadcastStatus();

  } catch (error) {
    console.error('Error:', error.message);
    buildStatus.isBuilding = false;
    buildStatus.error = error.message;
    buildStatus.message = `⚠️ Build selesai dengan error: ${error.message}`;
    buildStatus.progress = 100;
    broadcastStatus();
  } finally {
    // Bersihin file temporary setelah 2 menit
    setTimeout(() => {
      try {
        fs.remove(buildDir).catch(() => { });
        fs.unlink(zipPath).catch(() => { });
      } catch (e) { }
    }, 120000);
  }
}

function runCommand(command, cwd, ignoreErrors = true) {
  return new Promise((resolve) => {
    exec(command, { cwd, maxBuffer: 50 * 1024 * 1024 }, (error, stdout, stderr) => {
      if (error && !ignoreErrors) {
        resolve({ error: true, message: error.message });
      } else {
        resolve({ success: true, stdout, stderr });
      }
    });
  });
}

// Status endpoint biasa (fallback)
app.get('/status', (req, res) => {
  res.json(buildStatus);
});

// Clean endpoint
app.post('/clean', async (req, res) => {
  try {
    await fs.emptyDir(path.join(__dirname, 'public', 'downloads'));
    res.json({ success: true, message: 'Download folder cleaned' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

const PORT = process.env.PORT || 4500;
app.listen(PORT, () => {
  console.log(`
╔══════════════════════════════════════════════════════╗
║     🚀 FLUTTER APK BUILDER SERVER RUNNING            ║
╠══════════════════════════════════════════════════════╣
║  📱 URL: http://localhost:${PORT}                      ║
║  🔄 Auto Refresh: ENABLED (SSE)                      ║
║  ⚡ Ignore Errors: YES                               ║
║  📁 Upload folder: uploads/                          ║
║  📦 Build folder: builds/                            ║
║  📥 Download folder: public/downloads/               ║
╚══════════════════════════════════════════════════════╝
  `);
});