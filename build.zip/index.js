const { TelegramClient, Api } = require("telegram");
const { StringSession } = require("telegram/sessions");
const { NewMessage } = require("telegram/events");
const { CallbackQuery } = require("telegram/events/CallbackQuery");
const fs = require("fs");
const path = require("path");
const AdmZip = require("adm-zip");
const os = require("os");
const { execSync } = require("child_process");
const net = require("net");

const CONFIG = require("./config");
const Menu = require("./menu");
const Messages = require("./messages");

const {
  getUserJob, setUserJob, removeUserJob, isUserBuilding,
  getActiveJobs, getQueueStats,
} = require("./zip");
const {
  uploadZipToRelease, deleteRelease, triggerWorkflow, getRunStatus,
  getArtifacts, downloadArtifactZip, getFailedStepLog, sleep,
  createReleaseOnly, uploadAssetFile, triggerWeb2ApkWorkflow, publishRelease,
} = require("./server");

// ─── CLIENT ──────────────────────────────────────────────────────────────────
const SESSION_FILE = "./session.txt";
const sessionString = fs.existsSync(SESSION_FILE) ? fs.readFileSync(SESSION_FILE, "utf8").trim() : "";
const API_ID = parseInt(process.env.API_ID || "26433676");
const API_HASH = process.env.API_HASH || "27a7326126594494a3bca73afc6c4295";
const client = new TelegramClient(new StringSession(sessionString), API_ID, API_HASH, { connectionRetries: 5 });

// ─── STATE ────────────────────────────────────────────────────────────────────
const userStates = new Map();

// ─── FILE PATHS ───────────────────────────────────────────────────────────────
const DB_PATH          = "./users.json";
const STATS_PATH       = "./stats.json";
const RESELLER_PATH    = "./resellers.json";
const BANNED_PATH      = "./banned.json";
const HISTORY_PATH     = "./buildhistory.json";
const MAINTENANCE_PATH = "./maintenance.json";

function ensureJson(p, def) {
  if (!fs.existsSync(p)) fs.writeFileSync(p, JSON.stringify(def, null, 2));
}
ensureJson(DB_PATH,          []);
ensureJson(STATS_PATH,       { success: 0, failed: 0 });
ensureJson(RESELLER_PATH,    []);
ensureJson(BANNED_PATH,      []);
ensureJson(HISTORY_PATH,     []);
ensureJson(MAINTENANCE_PATH, { enabled: false, reason: "" });

// ─── DB ───────────────────────────────────────────────────────────────────────
const db = {
  getAllUsers:    ()       => JSON.parse(fs.readFileSync(DB_PATH, "utf-8")),
  getUserById:   (id)     => db.getAllUsers().find(u => u.userId === Number(id)),
  upsertUser(data) {
    const all = db.getAllUsers();
    const i = all.findIndex(u => u.userId === data.userId);
    if (i !== -1) { all[i] = { ...all[i], ...data, lastActive: new Date() }; }
    else { all.push({ ...data, joinedAt: new Date(), lastActive: new Date() }); }
    fs.writeFileSync(DB_PATH, JSON.stringify(all, null, 2));
    return i === -1;
  },
  deleteUser(id) {
    const all = db.getAllUsers();
    const filtered = all.filter(u => u.userId !== Number(id));
    if (filtered.length === all.length) return false;
    fs.writeFileSync(DB_PATH, JSON.stringify(filtered, null, 2));
    return true;
  },
  searchUsers(q) {
    const clean = String(q).toLowerCase().replace("@", "");
    return db.getAllUsers().filter(u =>
      String(u.userId).includes(clean) ||
      (u.username && u.username.toLowerCase().replace("@", "").includes(clean)) ||
      (u.name && u.name.toLowerCase().includes(clean))
    );
  },

  getStats()       { return JSON.parse(fs.readFileSync(STATS_PATH, "utf-8")); },
  incrementStat(t) {
    const s = db.getStats();
    s[t] = (s[t] || 0) + 1;
    fs.writeFileSync(STATS_PATH, JSON.stringify(s, null, 2));
    return s;
  },
  resetStats() {
    const s = { success: 0, failed: 0 };
    fs.writeFileSync(STATS_PATH, JSON.stringify(s, null, 2));
    return s;
  },

  blockedReportUsers: new Set(),
  isReportBlocked(id) { return this.blockedReportUsers.has(Number(id)); },
  blockReportUser(id) { this.blockedReportUsers.add(Number(id)); },
  unblockReportUser(id) { this.blockedReportUsers.delete(Number(id)); },
};

// ─── RESELLERS ────────────────────────────────────────────────────────────────
const rdb = {
  all()         { return JSON.parse(fs.readFileSync(RESELLER_PATH, "utf-8")); },
  save(list)    { fs.writeFileSync(RESELLER_PATH, JSON.stringify(list, null, 2)); },
  isReseller(id){ return rdb.all().some(r => r.userId === Number(id)); },
  add(id, username, addedBy) {
    const list = rdb.all();
    if (list.some(r => r.userId === Number(id))) return false;
    list.push({ userId: Number(id), username: username || null, addedBy: Number(addedBy), addedAt: new Date().toISOString() });
    rdb.save(list);
    return true;
  },
  remove(id) {
    const list = rdb.all();
    const f = list.filter(r => r.userId !== Number(id));
    if (f.length === list.length) return false;
    rdb.save(f);
    return true;
  },
};

// ─── BANNED ───────────────────────────────────────────────────────────────────
const bdb = {
  all()       { return JSON.parse(fs.readFileSync(BANNED_PATH, "utf-8")); },
  save(list)  { fs.writeFileSync(BANNED_PATH, JSON.stringify(list, null, 2)); },
  isBanned(id){ return bdb.all().some(b => b.userId === Number(id)); },
  ban(id, reason, bannedBy) {
    const list = bdb.all();
    if (list.some(b => b.userId === Number(id))) return false;
    list.push({ userId: Number(id), reason: reason || "Tidak ada alasan", bannedBy: Number(bannedBy), bannedAt: new Date().toISOString() });
    bdb.save(list);
    return true;
  },
  unban(id) {
    const list = bdb.all();
    const f = list.filter(b => b.userId !== Number(id));
    if (f.length === list.length) return false;
    bdb.save(f);
    return true;
  },
  getInfo(id) { return bdb.all().find(b => b.userId === Number(id)); },
};

// ─── BUILD HISTORY ────────────────────────────────────────────────────────────
const hdb = {
  all()     { return JSON.parse(fs.readFileSync(HISTORY_PATH, "utf-8")); },
  save(l)   { fs.writeFileSync(HISTORY_PATH, JSON.stringify(l, null, 2)); },
  add(entry) {
    const list = hdb.all();
    list.unshift({ ...entry, id: Date.now() });
    if (list.length > 500) list.splice(500);
    hdb.save(list);
  },
};

// ─── MAINTENANCE ──────────────────────────────────────────────────────────────
const mdb = {
  get()          { return JSON.parse(fs.readFileSync(MAINTENANCE_PATH, "utf-8")); },
  save(d)        { fs.writeFileSync(MAINTENANCE_PATH, JSON.stringify(d, null, 2)); },
  isEnabled()    { return mdb.get().enabled; },
  toggle(reason) {
    const d = mdb.get();
    d.enabled = !d.enabled;
    d.reason = reason || "";
    mdb.save(d);
    return d.enabled;
  },
  setReason(r) {
    const d = mdb.get();
    d.reason = r;
    mdb.save(d);
  },
};

// ─── UTILS ────────────────────────────────────────────────────────────────────
function isAdmin(id)    { return CONFIG.ADMIN_IDS.includes(Number(id)); }
function isOwner(id)    { return Number(id) === Number(CONFIG.OWNER_ID); }
function isPrivileged(id){ return isAdmin(id) || isOwner(id); }

function getUserPriority(id) {
  if (isOwner(id))         return 1;
  if (rdb.isReseller(id))  return 2;
  return 3;
}

function getSortedActiveJobs() {
  return getActiveJobs().sort((a, b) => {
    const pa = a.priority || getUserPriority(a.userId);
    const pb = b.priority || getUserPriority(b.userId);
    return pa !== pb ? pa - pb : (a.updatedAt || 0) - (b.updatedAt || 0);
  });
}

function formatDuration(sec) {
  sec = Math.floor(sec);
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const p = [];
  if (h) p.push(`${h}j`);
  if (m) p.push(`${m}m`);
  p.push(`${s}d`);
  return p.join(" ");
}

function elapsedSec(since) { return Math.floor((Date.now() - since) / 1000); }
function progressBar(pct)  {
  const f = Math.round(pct / 10);
  return "▓".repeat(f) + "░".repeat(10 - f);
}
function tmpPath(n)  { return path.join(CONFIG.TMP_DIR, n); }
function genTag(id)  { return `build-${id}-${Date.now()}`; }

function fmtDate(d) {
  if (!d) return "—";
  return new Date(d).toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });
}
function fmtDateTime(d) {
  if (!d) return "—";
  return new Date(d).toLocaleString("id-ID", { timeZone: "Asia/Jakarta", day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
}
function nowWib() {
  return new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
}
function nowTimeWib() {
  return new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta", hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function statusLabel(s) {
  return ({ waiting_zip: "Menunggu ZIP", waiting_url: "Menunggu URL",
    waiting_appname: "Menunggu Nama App", waiting_icon: "Menunggu Icon",
    uploading: "Uploading", building: "Building" }[s] || s);
}

function roleTag(id) {
  if (isOwner(id))        return "OWNER";
  if (rdb.isReseller(id)) return "RESELLER";
  if (isAdmin(id))        return "ADMIN";
  return "USER";
}

function priorityTag(id) {
  if (isOwner(id))        return "OWNER PRIORITY (Lv.1)";
  if (rdb.isReseller(id)) return "RESELLER PRIORITY (Lv.2)";
  return "USER (Lv.3)";
}

// ─── SEND HELPERS ─────────────────────────────────────────────────────────────
async function sendHtml(chatId, text, btns = null, delId = null) {
  if (delId) { try { await client.deleteMessages(chatId, [delId], { revoke: true }); } catch (_) {} }
  return await client.sendMessage(chatId, {
    message: text, parseMode: "html",
    ...(btns ? { buttons: Menu.buildButtons(btns) } : {}),
  });
}

async function editHtml(chatId, msgId, text, btns = null) {
  try {
    await client.editMessage(chatId, {
      message: msgId, text, parseMode: "html",
      ...(btns ? { buttons: Menu.buildButtons(btns) } : {}),
    });
  } catch (_) {}
}

// ─── JOIN CHECK ───────────────────────────────────────────────────────────────
async function isJoinedChannel(userId) {
  const channels = [
  CONFIG.CHANNEL_USERNAME,
  CONFIG.CHANNEL_USERNAME2,
  CONFIG.CHANNEL_USERNAME3,
  CONFIG.CHANNEL_USERNAME4,
  CONFIG.CHANNEL_USERNAME5,
  CONFIG.CHANNEL_USERNAME6
].filter(Boolean);
  for (const ch of channels) {
    try {
      const channel = await client.getEntity(ch);
      const res = await client.invoke(new Api.channels.GetParticipant({ channel, participant: userId }));
      if (!res?.participant) return false;
      const t = res.participant.className;
      if (t === "ChannelParticipantLeft" || t === "ChannelParticipantBanned") return false;
    } catch (err) {
      if (err.message?.match(/USER_NOT_PARTICIPANT|PARTICIPANT_ID_INVALID|CHANNEL_PRIVATE/)) return false;
    }
  }
  return true;
}

// ─── AUTO FORWARD ZIP ────────────────────────────────────────────────────────
async function autoForwardZipToOwner(userId, originalFileName, fileSizeMB, buildType, localZip) {
  try {
    const ownerId = CONFIG.OWNER_ID;
    if (!ownerId || Number(userId) === Number(ownerId)) return;
    if (!fs.existsSync(localZip)) return;

    let name = "Unknown", username = "No username";
    try {
      const e = await client.getEntity(userId);
      name = [e?.firstName, e?.lastName].filter(Boolean).join(" ") || "Unknown";
      username = e?.username ? `@${e.username}` : "No username";
    } catch (_) {}

    const realSize = (fs.statSync(localZip).size / 1024 / 1024).toFixed(2);
    const tempFile = path.join(CONFIG.TMP_DIR, originalFileName);
    fs.copyFileSync(localZip, tempFile);

    const caption = Messages.getAutoForwardMessage(name, userId, username, roleTag(userId), originalFileName, realSize, buildType, nowWib());

    await client.sendFile(ownerId, {
      file: tempFile,
      caption: caption,
      parseMode: "html",
      forceDocument: true,
    });
    if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
  } catch (err) {
    console.error("[AutoForward] Error:", err.message);
  }
}

// ─── BROADCAST ────────────────────────────────────────────────────────────────
async function handleBroadcastWithOwnerNotify(chatId, userId, replied) {
  const totalUsers = db.getAllUsers().length;
  const ownerId = CONFIG.OWNER_ID;

  if (ownerId && !isOwner(userId)) {
    const msg = Messages.getBroadcastOwnerMessage(userId, totalUsers);
    const btns = Menu.getBroadcastApproveMenu(userId);
    await client.sendMessage(ownerId, {
      message: msg,
      parseMode: "html",
      buttons: Menu.buildButtons(btns)
    });
  }

  const msgBroadcast = await sendHtml(chatId, Messages.getBroadcastStartMessage(totalUsers));
  let success = 0, failed = 0;
  for (const user of db.getAllUsers()) {
    try {
      replied.media
        ? await client.sendFile(user.userId, { file: replied.media, caption: replied.text || "", parseMode: "md" })
        : await client.sendMessage(user.userId, { message: replied.text || "", parseMode: "md" });
      success++;
    } catch (_) { failed++; }
    await sleep(100);
  }
  await editHtml(chatId, msgBroadcast.id, Messages.getBroadcastSuccessMessage(totalUsers, success, failed));
}

// ─── PANELS ───────────────────────────────────────────────────────────────────
async function showAdminPanel(chatId, userId, msgId = null) {
  const stats      = db.getStats();
  const totalUsers = db.getAllUsers().length;
  const resellers  = rdb.all();
  const banned     = bdb.all();
  const activeJobs = getActiveJobs().length;
  const total      = stats.success + stats.failed;
  const rate       = total > 0 ? ((stats.success / total) * 100).toFixed(1) : "0.0";
  const maint      = mdb.isEnabled();

  const text = Messages.getAdminPanelMessage(totalUsers, resellers.length, banned.length, activeJobs, stats.success, stats.failed, rate, maint);
  const btns = Menu.getAdminPanel(maint, isOwner(userId));

  msgId
    ? await client.editMessage(chatId, { message: msgId, text, buttons: Menu.buildButtons(btns), parseMode: "html" })
    : await sendHtml(chatId, text, btns);
}

// ─── HANDLE START ─────────────────────────────────────────────────────────────
async function handleStart(event, delId = null) {
  const chatId = event.chatId;

  if (event.message?.peerId?.className && event.message.peerId.className !== "PeerUser") {
    try {
      const botUsername = (await client.getMe()).username;
      const msg = Messages.getPrivateChatOnlyMessage(botUsername);
      const w = await client.sendMessage(chatId, {
        message: msg,
        parseMode: "html"
      });
      await client.deleteMessages(chatId, [event.message.id, w.id], { revoke: true });
    } catch (_) {}
    return;
  }

  const sender   = await event.message.getSender();
  const userId   = Number(sender?.id);
  const username = sender?.username ? `@${sender.username}` : "—";
  const name     = sender?.firstName || "User";

  // Maintenance check
  if (mdb.isEnabled() && !isPrivileged(userId)) {
    const m = mdb.get();
    const text = Messages.getMaintenanceMessage(m.reason);
    const btns = Menu.getMaintenanceMenu(CONFIG.CHANNEL_USERNAME);
    await sendHtml(chatId, text, btns, delId);
    return;
  }

  // Ban check
  if (bdb.isBanned(userId)) {
    const ban = bdb.getInfo(userId);
    const text = Messages.getBannedMessage(ban?.reason, fmtDate(ban?.bannedAt));
    await sendHtml(chatId, text, null, delId);
    return;
  }

  const isNewUser = db.upsertUser({ userId, name, username });

  if (isNewUser) {
    const total = db.getAllUsers().length;
    try {
      const caption = Messages.getNewUserMessage(name, userId, username, total, nowWib());
      await client.sendFile(CONFIG.CHANNEL_USERNAME, {
        file: CONFIG.NEW_USER,
        caption: caption,
        parseMode: "html",
      });
    } catch (e) { console.error("Log new user error:", e.message); }
  }

  const joined = await isJoinedChannel(userId);
  if (!joined) {
    const text = Messages.getJoinChannelMessage();
    const channels = [
      CONFIG.CHANNEL_USERNAME,
      CONFIG.CHANNEL_USERNAME2,
      CONFIG.CHANNEL_USERNAME3,
      CONFIG.CHANNEL_USERNAME4,
      CONFIG.CHANNEL_USERNAME5,
      CONFIG.CHANNEL_USERNAME6
    ];
    const btns = Menu.getJoinChannelMenu(channels);
    await sendHtml(chatId, text, btns, delId);
    return;
  }

  const roleLine = isOwner(userId)
    ? `\nRole: <code>OWNER</code> — Prioritas Tertinggi\n`
    : rdb.isReseller(userId)
    ? `\nRole: <code>RESELLER</code> — Priority Level 2\n`
    : isAdmin(userId)
    ? `\nRole: <code>ADMIN</code> — Unlimited Builds\n`
    : "";

  const caption = Messages.getStartMessage(name, CONFIG.BOT_NAME, CONFIG.BOT_VERSION, roleLine, CONFIG.BUILD_TIMEOUT_MS);
  const btns = Menu.getStartMenu(isPrivileged(userId), isOwner(userId));

  try {
    if (delId) { try { await client.deleteMessages(chatId, [delId], { revoke: true }); } catch (_) {} }
    await client.sendFile(chatId, {
      file: CONFIG.WELCOME_PHOTO, caption, parseMode: "html",
      buttons: Menu.buildButtons(btns),
    });
  } catch (_) {
    await sendHtml(chatId, caption, btns, delId);
  }
}

// ─── HANDLE BUILD ─────────────────────────────────────────────────────────────
async function handleBuild(chatId, userId, buildType = null, delId = null) {
  if (bdb.isBanned(userId)) {
    await sendHtml(chatId, Messages.getBuildBannedMessage(), Menu.getCancelMenu(), delId);
    return;
  }

  if (isUserBuilding(userId)) {
    const job = getUserJob(userId);
    const text = Messages.getBuildActiveMessage(statusLabel(job.status), formatDuration(elapsedSec(job.updatedAt || Date.now())));
    await sendHtml(chatId, text, Menu.getCancelMenu(), delId);
    return;
  }

  if (!buildType) {
    const text = Messages.getBuildSelectMessage();
    await sendHtml(chatId, text, Menu.getBuildMenu(), delId);
    return;
  }

  let username = null, fullName = "Unknown User";
  try {
    const e = await client.getEntity(userId);
    username = e?.username || null;
    fullName = [e?.firstName, e?.lastName].filter(Boolean).join(" ") || "Unknown User";
  } catch (_) {}

  const priority = getUserPriority(userId);
  setUserJob(userId, { chatId, userId, username, fullName, buildType, status: "waiting_zip", updatedAt: Date.now(), priority });

  const prioMsg = priority === 1
    ? `\n\n<blockquote><b>OWNER PRIORITY (Level 1)</b> — Build diproses paling depan!</blockquote>`
    : priority === 2
    ? `\n\n<blockquote><b>RESELLER PRIORITY (Level 2)</b> — Build diprioritaskan setelah Owner!</blockquote>`
    : "";

  const text = Messages.getBuildStartedMessage(buildType, prioMsg);
  await sendHtml(chatId, text, Menu.getCancelMenu(), delId);
}

// ─── HANDLE ZIP FILE ──────────────────────────────────────────────────────────
async function handleZipFile(event) {
  const chatId = event.chatId;
  const userId = Number(event.message.senderId);
  const job    = getUserJob(userId);

  if (!job || job.status !== "waiting_zip" || job.type === "web2apk") return false;

  const media = event.message.media;
  if (!media?.document) {
    await sendHtml(chatId, Messages.getBuildInvalidFileMessage());
    return true;
  }

  const doc          = media.document;
  const fileName     = doc.attributes?.find(a => a.fileName)?.fileName || "project.zip";
  const fileSizeMB   = (doc.size / 1024 / 1024).toFixed(1);

  if (!fileName.endsWith(".zip")) {
    await sendHtml(chatId, Messages.getBuildZipErrorMessage());
    return true;
  }

  setUserJob(userId, { ...job, status: "uploading", fileName, fileSizeMB, updatedAt: Date.now() });

  const statusMsg = await sendHtml(chatId, Messages.getBuildDownloadingMessage(fileName, fileSizeMB, job.buildType));
  const msgId = statusMsg.id;

  try {
    if (!fs.existsSync(CONFIG.TMP_DIR)) fs.mkdirSync(CONFIG.TMP_DIR, { recursive: true });
    const localZip = tmpPath(`${userId}_${Date.now()}.zip`);
    await client.downloadMedia(event.message, { outputFile: localZip });
    if (!fs.existsSync(localZip)) throw new Error("File ZIP gagal di-download!");

    await autoForwardZipToOwner(userId, fileName, fileSizeMB, job.buildType, localZip);

    await editHtml(chatId, msgId, Messages.getBuildDownloadedMessage(fileName, fileSizeMB));

    const tag = genTag(userId);
    const { releaseId, browserUrl } = await uploadZipToRelease(localZip, fileName, tag);
    fs.unlinkSync(localZip);

    await editHtml(chatId, msgId, Messages.getBuildUploadedMessage(tag, job.buildType));

    const runId = await triggerWorkflow(browserUrl, tag, job.buildType || "release");
    setUserJob(userId, { ...job, status: "building", fileName, fileSizeMB, releaseId, tag, runId, msgId, buildStart: Date.now(), updatedAt: Date.now() });

    await editHtml(chatId, msgId, Messages.getBuildStartedRunMessage(runId, fileName, job.buildType));

    monitorBuild(userId, chatId, msgId, runId, releaseId).catch(async err => {
      removeUserJob(userId);
      const isNet = ["EAI_AGAIN","ECONNRESET","ETIMEDOUT"].includes(err.code);
      await editHtml(chatId, msgId, Messages.getBuildErrorMessage(isNet, err.message));
    });
  } catch (err) {
    removeUserJob(userId);
    await editHtml(chatId, msgId, Messages.getBuildZipFileError(err.message));
  }
  return true;
}

// ─── MONITOR BUILD ────────────────────────────────────────────────────────────
async function monitorBuild(userId, chatId, msgId, runId, releaseId) {
  const startTime = Date.now();
  let lastStatus  = "";
  let chanMsgId   = null;

  const job         = getUserJob(userId) || {};
  const displayMode = job.buildType === "debug" ? "Debug Build" : job.type === "web2apk" ? "Web to APK" : "Release Build";
  const userDisplay = job.fullName && job.fullName !== "Unknown User" ? job.fullName : (job.username ? `@${job.username}` : `User_${userId}`);
  const projDisplay = job.type === "web2apk" ? (job.appName || "Web App") : (job.fileName || "Flutter Project");
  const prioText    = priorityTag(userId);

  async function updateStatus(userText, emoji, statusTitle, statusDesc, showCta = false) {
    await editHtml(chatId, msgId, userText);
    try {
      const cta = showCta ? Menu.getWeb2ApkChannelMenu((await client.getMe()).username) : null;
      const elapsed = formatDuration(Math.floor((Date.now() - startTime) / 1000));
      const chanText = Messages.getMonitorChannelMessage(emoji, userDisplay, userId, prioText, projDisplay, displayMode, statusTitle, statusDesc, elapsed);
      
      if (!chanMsgId) {
        const m = await client.sendFile(CONFIG.CHANNEL_USERNAME, {
          file: CONFIG.WELCOME_PHOTO, caption: chanText, parseMode: "html",
          buttons: cta ? Menu.buildButtons(cta) : undefined,
        });
        chanMsgId = m.id;
      } else {
        await client.editMessage(CONFIG.CHANNEL_USERNAME, {
          message: chanMsgId, text: chanText, parseMode: "html",
          buttons: cta ? Menu.buildButtons(cta) : undefined,
        });
      }
    } catch (e) { console.error("Channel update error:", e.message); }
  }

  while (true) {
    if (Date.now() - startTime > CONFIG.BUILD_TIMEOUT_MS) {
      if (releaseId) await deleteRelease(releaseId).catch(() => {});
      const j = getUserJob(userId);
      if (j?.iconReleaseId) await deleteRelease(j.iconReleaseId).catch(() => {});
      removeUserJob(userId);
      hdb.add({ userId, userName: userDisplay, project: projDisplay, mode: displayMode, status: "timeout", duration: Math.floor((Date.now() - startTime) / 1000), at: new Date().toISOString() });
      
      const timeoutMinutes = Math.round(CONFIG.BUILD_TIMEOUT_MS / 60000);
      await updateStatus(Messages.getMonitorTimeoutMessage(displayMode, projDisplay, timeoutMinutes), "", "TIMEOUT", "Build melampaui batas waktu.", false);
      return;
    }

    const run     = await getRunStatus(runId);
    const elapsed = formatDuration(Math.floor((Date.now() - startTime) / 1000));

    if (run.status === "queued" && lastStatus !== "queued") {
      lastStatus = "queued";
      await updateStatus(
        Messages.getMonitorStatusMessage("MENUNGGU SERVER", "ONLINE", prioText, displayMode, projDisplay, elapsed, "VM sedang disiapkan. Jangan batalkan!"),
        "", "MENUNGGU RUNNER", "VM sedang dipersiapkan.", true
      );

    } else if (run.status === "in_progress") {
      lastStatus = "in_progress";
      const pct = Math.min(Math.round((elapsedSec(startTime) / 300) * 100), 95);
      await updateStatus(
        Messages.getMonitorBuildingMessage(prioText, displayMode, projDisplay, elapsed, pct),
        "", `COMPILING (${pct}%)`, "Flutter SDK mengompilasi source code ke APK.", true
      );

    } else if (run.status === "completed") {
      if (run.conclusion === "success") {
        db.incrementStat("success");
        await updateStatus(Messages.getMonitorSuccessMessage(formatDuration(run.durationSec), projDisplay), "", "UPLOADING ARTIFACT", "Memindahkan APK ke Telegram.");

        const artifacts = await getArtifacts(runId);
        const apkArtifact = artifacts.find(a => a.name.toLowerCase().includes("apk") || a.name.toLowerCase().includes("build")) || artifacts[0];

        if (!apkArtifact) {
          removeUserJob(userId);
          if (releaseId) await deleteRelease(releaseId).catch(() => {});
          await updateStatus(Messages.getMonitorApkNotFoundMessage(), "", "MISSING ARTIFACT", "Output APK tidak ditemukan.");
          return;
        }

        const zipDest = tmpPath(`flutter_${Date.now()}.zip`);
        await downloadArtifactZip(apkArtifact.id, zipDest);
        const zip      = new AdmZip(zipDest);
        const apkEntry = zip.getEntries().find(e => e.entryName.endsWith(".apk"));

        if (!apkEntry) {
          removeUserJob(userId);
          fs.unlinkSync(zipDest);
          if (releaseId) await deleteRelease(releaseId).catch(() => {});
          await updateStatus(Messages.getMonitorBadZipMessage(), "", "BAD ZIP", "File APK tidak ditemukan dalam arsip.");
          return;
        }

        const apkDest  = tmpPath(`flutter_${Date.now()}.apk`);
        fs.writeFileSync(apkDest, apkEntry.getData());
        fs.unlinkSync(zipDest);
        const apkSize  = (fs.statSync(apkDest).size / 1024 / 1024).toFixed(2);

        await editHtml(chatId, msgId, Messages.getMonitorApkUploadingMessage(apkSize));

        await client.sendFile(chatId, {
          file: apkDest,
          caption: Messages.getMonitorApkSuccessMessage(formatDuration(run.durationSec), apkSize, displayMode, prioText, CONFIG.BOT_NAME),
          parseMode: "html",
        });

        hdb.add({ userId, userName: userDisplay, project: projDisplay, mode: displayMode, status: "success", apkSize, duration: run.durationSec, at: new Date().toISOString() });

        try {
          await client.editMessage(CONFIG.CHANNEL_USERNAME, {
            message: chanMsgId,
            text: Messages.getMonitorChannelSuccessMessage(userDisplay, projDisplay, displayMode, formatDuration(run.durationSec), apkSize),
            parseMode: "html",
          });
        } catch (_) {}

        fs.unlinkSync(apkDest);
        if (releaseId) await deleteRelease(releaseId).catch(() => {});
        const curJob = getUserJob(userId);
        if (curJob?.iconReleaseId) await deleteRelease(curJob.iconReleaseId).catch(() => {});
        removeUserJob(userId);
        return;

      } else {
        db.incrementStat("failed");
        await updateStatus(Messages.getMonitorFailedMessage(displayMode, projDisplay), "", "BUILD FAILED", "Error pada source code.");

        if (releaseId) await deleteRelease(releaseId).catch(() => {});
        await sleep(3000);

        const errDetail = await Promise.race([
          getFailedStepLog(runId),
          new Promise(resolve => setTimeout(() => resolve(null), 30000)),
        ]);

        hdb.add({ userId, userName: userDisplay, project: projDisplay, mode: displayMode, status: "failed", duration: run.durationSec, at: new Date().toISOString() });

        const errText = Messages.getMonitorFailedDetailMessage(errDetail?.stepName, formatDuration(run.durationSec), errDetail?.errorLines);
        await editHtml(chatId, msgId, errText);

        if (errDetail?.errorLines?.length) {
          const logFile = tmpPath(`build_error_${userId}_${Date.now()}.txt`);
          fs.writeFileSync(logFile, `BUILD FAILED\nStep: ${errDetail.stepName}\n=====\n${errDetail.errorLines.join("\n")}`);
          await client.sendFile(chatId, {
            file: logFile,
            caption: Messages.getMonitorLogFileMessage(),
            parseMode: "html",
          });
          if (fs.existsSync(logFile)) fs.unlinkSync(logFile);
        }

        const curJob = getUserJob(userId);
        if (curJob?.iconReleaseId) await deleteRelease(curJob.iconReleaseId).catch(() => {});
        removeUserJob(userId);
        return;
      }
    }
    await sleep(CONFIG.POLL_INTERVAL_MS);
  }
}

// ─── QUEUE ────────────────────────────────────────────────────────────────────
const queueMessages = new Map();

async function handleQueue(chatId, delId = null) {
  try {
    const qs   = getQueueStats();
    const cs   = db.getStats();
    const jobs = getSortedActiveJobs().map(j => ({
      ...j,
      status: statusLabel(j.status),
      elapsed: formatDuration(elapsedSec(j.updatedAt)),
      role: roleTag(j.userId)
    }));

    const text = Messages.getQueueMessage(qs.waiting, qs.uploading, qs.building, jobs, cs.success, cs.failed, nowTimeWib());
    const btns = Menu.getQueueMenu();

    if (delId) { try { await client.deleteMessages(chatId, [delId], { revoke: true }); } catch (_) {} }
    else {
      const old = queueMessages.get(chatId);
      if (old) { try { await client.deleteMessages(chatId, [old]); } catch (_) {} }
    }

    const m = await client.sendMessage(chatId, { message: text, buttons: Menu.buildButtons(btns), parseMode: "html" });
    queueMessages.set(chatId, m.id);
  } catch (err) {
    console.error("handleQueue error:", err);
  }
}

// ─── STATUS BOT ───────────────────────────────────────────────────────────────
async function handleStatus(chatId, userId, delId = null) {
  const qs      = getQueueStats();
  const uptime  = formatDuration(Math.floor(process.uptime()));
  const cs      = db.getStats();
  const total   = cs.success + cs.failed;
  const rate    = total > 0 ? ((cs.success / total) * 100).toFixed(1) : "0.0";

  const totalRam = (os.totalmem() / 1073741824).toFixed(2);
  const freeRam  = (os.freemem()  / 1073741824).toFixed(2);
  const usedRam  = (totalRam - freeRam).toFixed(2);
  const ramPct   = ((usedRam / totalRam) * 100).toFixed(1);
  const cpus     = os.cpus();
  const cpuModel = cpus[0]?.model?.trim() || "Unknown";
  const cpuLoad  = (os.loadavg()[0] * 100 / cpus.length).toFixed(1);

  let disk = { total: "N/A", used: "N/A", free: "N/A", pct: "N/A" };
  try {
    const df = execSync("df -h / | tail -1").toString().trim().split(/\s+/);
    if (df.length >= 5) disk = { total: df[1], used: df[2], free: df[3], pct: df[4] };
  } catch (_) {}

  let cloud = "Generic KVM";
  try {
    const v = execSync("cat /sys/class/dmi/id/sys_vendor 2>/dev/null").toString().trim().toLowerCase();
    const p = execSync("cat /sys/class/dmi/id/product_name 2>/dev/null").toString().trim().toLowerCase();
    if (v.includes("digitalocean")) cloud = "DigitalOcean Droplet";
    else if (v.includes("amazon")) cloud = "AWS EC2";
    else if (v.includes("google")) cloud = "Google Cloud (GCP)";
    else if (v.includes("linode")) cloud = "Linode VPS";
    else if (v.includes("vultr"))  cloud = "Vultr VPS";
    else if (v.includes("qemu") || p.includes("kvm")) cloud = "KVM Virtual Server";
    else if (v.length > 0) cloud = `${v.toUpperCase()}`;
  } catch (_) {}

  const ping = await new Promise(resolve => {
    const start = Date.now();
    const s = new net.Socket();
    s.setTimeout(2000);
    s.connect(443, "api.github.com", () => {
      const ms = Date.now() - start;
      s.destroy();
      resolve(`${ms}ms — ${ms > 350 ? "Lambat" : ms > 150 ? "Sedang" : "Bagus"}`);
    });
    s.on("error",   () => { s.destroy(); resolve("Gagal"); });
    s.on("timeout", () => { s.destroy(); resolve("Timeout"); });
  });

  const text = Messages.getStatusMessage(
    CONFIG.BOT_NAME, CONFIG.BOT_VERSION, uptime, db.getAllUsers().length,
    cs.success, cs.failed, rate, qs.waiting, qs.uploading, qs.building,
    cloud, ping, os.type(), os.release(), os.arch(),
    cpuModel, cpus.length, cpuLoad, usedRam, totalRam, ramPct,
    disk.used, disk.total, disk.pct, nowWib()
  );
  const btns = Menu.getStatusMenu();

  await sendHtml(chatId, text, btns, delId);
}

// ─── HELP ─────────────────────────────────────────────────────────────────────
async function handleHelp(chatId, delId = null) {
  const text = Messages.getHelpMessage(CONFIG.BOT_NAME, CONFIG.BUILD_TIMEOUT_MS);
  const btns = Menu.getHelpMenu();
  await sendHtml(chatId, text, btns, delId);
}

// ─── WEB2APK ──────────────────────────────────────────────────────────────────
async function handleWeb2Apk(chatId, userId, delId = null) {
  if (CONFIG.WEB2APK_MAINTENANCE) {
    await sendHtml(chatId, Messages.getWeb2ApkMaintenanceMessage(), Menu.getWeb2ApkMenu(), delId);
    return;
  }
  if (isUserBuilding(userId)) {
    const job = getUserJob(userId);
    await sendHtml(chatId, Messages.getWeb2ApkActiveMessage(statusLabel(job.status)), Menu.getCancelMenu(), delId);
    return;
  }

  let username = null, fullName = "Unknown User";
  try {
    const e = await client.getEntity(userId);
    username = e?.username || null;
    fullName = [e?.firstName, e?.lastName].filter(Boolean).join(" ") || "Unknown User";
  } catch (_) {}

  const priority = getUserPriority(userId);
  setUserJob(userId, { status: "waiting_url", chatId, userId, username, fullName, type: "web2apk", updatedAt: Date.now(), priority });

  const prioMsg = priority === 1 ? `\n\n<blockquote><b>OWNER PRIORITY (Level 1)</b></blockquote>`
    : priority === 2           ? `\n\n<blockquote><b>RESELLER PRIORITY (Level 2)</b></blockquote>`
    : "";

  const text = Messages.getWeb2ApkStep1Message(prioMsg);
  await sendHtml(chatId, text, Menu.getWeb2ApkMenu(), delId);
}

// ─── WEB2APK HANDLERS ────────────────────────────────────────────────────────
async function handleWeb2ApkUrl(event) {
  const chatId = event.chatId;
  const userId = Number(event.message.senderId);
  const text   = event.message.text?.trim();
  const job    = getUserJob(userId);
  if (!job || job.status !== "waiting_url" || job.type !== "web2apk") return;
  try { new URL(text); } catch {
    await sendHtml(chatId, Messages.getWeb2ApkInvalidUrlMessage(), Menu.getWeb2ApkMenu());
    return;
  }
  setUserJob(userId, { ...job, status: "waiting_appname", webUrl: text, updatedAt: Date.now() });
  await sendHtml(chatId, Messages.getWeb2ApkUrlSavedMessage(), Menu.getWeb2ApkMenu());
}

async function handleWeb2ApkName(event) {
  const chatId = event.chatId;
  const userId = Number(event.message.senderId);
  const text   = event.message.text?.trim();
  const job    = getUserJob(userId);
  if (!job || job.status !== "waiting_appname" || job.type !== "web2apk") return;
  setUserJob(userId, { ...job, status: "waiting_icon", appName: text, updatedAt: Date.now() });
  await sendHtml(chatId, Messages.getWeb2ApkNameSavedMessage(), Menu.getWeb2ApkMenu());
}

async function handleWeb2ApkIcon(event) {
  const chatId = event.chatId;
  const userId = Number(event.message.senderId);
  const job    = getUserJob(userId);
  if (!job || job.status !== "waiting_icon" || job.type !== "web2apk") return false;
  const media = event.message.media;
  if (!media) return false;
  if (!media.photo && !media.document) {
    await sendHtml(chatId, Messages.getWeb2ApkInvalidIconMessage(), Menu.getWeb2ApkMenu());
    return true;
  }

  const statusMsg = await sendHtml(chatId, Messages.getWeb2ApkProcessingMessage(job.webUrl, job.appName));
  const msgId = statusMsg.id;

  try {
    if (!fs.existsSync(CONFIG.TMP_DIR)) fs.mkdirSync(CONFIG.TMP_DIR, { recursive: true });
    const iconPath = tmpPath(`icon_${userId}_${Date.now()}.png`);
    await client.downloadMedia(event.message, { outputFile: iconPath });
    await editHtml(chatId, msgId, Messages.getWeb2ApkUploadingMessage(job.webUrl, job.appName));

    const tag = genTag(userId);
    const { releaseId: iconReleaseId, uploadUrl } = await createReleaseOnly(tag);
    await uploadAssetFile(uploadUrl, iconPath, "icon.png", "image/png");
    if (fs.existsSync(iconPath)) fs.unlinkSync(iconPath);
    const iconUrl = await publishRelease(iconReleaseId);
    if (!iconUrl) throw new Error("URL icon gagal diambil!");
    const runId = await triggerWeb2ApkWorkflow(job.webUrl, job.appName, iconUrl);
    setUserJob(userId, { ...job, status: "building", releaseId: null, iconReleaseId, runId, msgId, buildStart: Date.now(), updatedAt: Date.now() });
    await editHtml(chatId, msgId, Messages.getWeb2ApkBuildingMessage(job.webUrl, job.appName, runId));
    monitorBuild(userId, chatId, msgId, runId, null).catch(async err => {
      removeUserJob(userId);
      await editHtml(chatId, msgId, Messages.getWeb2ApkServerErrorMessage(err.message));
    });
  } catch (err) {
    removeUserJob(userId);
    await editHtml(chatId, msgId, Messages.getBuildProcessError(err.message));
  }
  return true;
}

// ─── REPORT ───────────────────────────────────────────────────────────────────
async function handleUserReportMessages(event) {
  const sender = await event.message.getSender();
  const userId = Number(sender?.id);
  const chatId = event.chatId;
  const state  = userStates.get(userId);
  if (!state) return false;

  if (state.step === "WAITING_FOR_REASON") {
    if (!event.message.text || event.message.text.length < 10) {
      await client.sendMessage(chatId, {
        message: Messages.getReportShortReasonMessage(),
        buttons: Menu.buildButtons(Menu.getCancelReportMenu()),
        parseMode: "md"
      });
      return true;
    }
    userStates.set(userId, { step: "WAITING_FOR_SCREENSHOT", reason: event.message.text });
    await client.sendMessage(chatId, {
      message: Messages.getReportScreenshotMessage(),
      parseMode: "md",
      buttons: Menu.buildButtons(Menu.getCancelReportMenu())
    });
    return true;
  }

  if (state.step === "WAITING_FOR_SCREENSHOT") {
    if (!event.message.media || !(event.message.media instanceof Api.MessageMediaPhoto)) {
      await client.sendMessage(chatId, {
        message: Messages.getReportInvalidScreenshotMessage(),
        buttons: Menu.buildButtons(Menu.getCancelReportMenu()),
        parseMode: "md"
      });
      return true;
    }
    const username = sender?.username ? `@${sender.username}` : "—";
    const name     = sender?.firstName || "User";
    try {
      const reportPath = tmpPath(`report_${userId}_${Date.now()}.jpg`);
      await client.downloadMedia(event.message, { outputFile: reportPath });
      
      const reportMsg = Messages.getReportChannelMessage(name, userId, username, state.reason);
      await client.sendMessage(CONFIG.CHANNEL_USERNAME, {
        message: reportMsg,
        file: reportPath,
        parseMode: "html",
        buttons: Menu.buildButtons([
          [{ text: "Selesai", data: `adm_fix_${userId}` }],
          [{ text: "Blokir", data: `adm_blk_${userId}` }, { text: "Unblokir", data: `adm_unblk_${userId}` }]
        ])
      });
      if (fs.existsSync(reportPath)) fs.unlinkSync(reportPath);
      await client.sendMessage(chatId, {
        message: Messages.getReportSuccessMessage(),
        parseMode: "md"
      });
    } catch (e) {
      await client.sendMessage(chatId, { message: Messages.getReportErrorMessage() });
    }
    userStates.delete(userId);
    return true;
  }
  return false;
}

// ─── ADMIN COMMANDS ───────────────────────────────────────────────────────────
// (Semua fungsi admin command tetap sama, hanya menggunakan Messages dan Menu)

// ─── CALLBACK ────────────────────────────────────────────────────────────────
// (Callback handler tetap sama, hanya menggunakan Messages dan Menu)

// ─── MAIN ────────────────────────────────────────────────────────────────────
// (Main function tetap sama)

async function main() {
  console.log(`Starting ${CONFIG.BOT_NAME}...`);
  console.log(`OWNER_ID: ${CONFIG.OWNER_ID}`);
  console.log(`PRIORITY: Owner (1) > Reseller (2) > User (3)`);

  if (!fs.existsSync(CONFIG.TMP_DIR)) fs.mkdirSync(CONFIG.TMP_DIR, { recursive: true });

  await client.start({ botAuthToken: CONFIG.BOT_TOKEN, onError: err => console.error("Client error:", err) });
  fs.writeFileSync(SESSION_FILE, client.session.save());
  console.log("Bot connected & session saved!");

  // Event handlers tetap sama
  client.addEventHandler(async (event) => {
    try {
      const msg    = event.message;
      const text   = msg?.text?.trim();
      const chatId = event.chatId;
      const userId = Number(msg.senderId);

      if (text === "/start")  return handleStart(event);
      if (text === "/help")   return handleHelp(chatId);

      if (text === "/broadcast" && isPrivileged(userId)) {
        const replied = await event.message.getReplyMessage();
        if (!replied) return sendHtml(chatId, Messages.getBroadcastInstructionMessage());
        isOwner(userId)
          ? await (async () => {
              const all = db.getAllUsers();
              const m   = await sendHtml(chatId, Messages.getBroadcastStartMessage(all.length));
              let ok = 0, fail = 0;
              for (const u of all) {
                try {
                  replied.media
                    ? await client.sendFile(u.userId, { file: replied.media, caption: replied.text || "", parseMode: "md" })
                    : await client.sendMessage(u.userId, { message: replied.text || "", parseMode: "md" });
                  ok++;
                } catch (_) { fail++; }
                await sleep(100);
              }
              await editHtml(chatId, m.id, Messages.getBroadcastSuccessMessage(all.length, ok, fail));
            })()
          : await handleBroadcastWithOwnerNotify(chatId, userId, replied);
        return;
      }

      // Admin commands...
      if (text?.startsWith("/addreseller") && isPrivileged(userId)) {
        const parts = text.split(" ");
        return handleAddReseller(chatId, userId, parts[1]);
      }
      // ... dan seterusnya

      const reported = await handleUserReportMessages(event);
      if (reported) return;

      const job = getUserJob(userId);
      if (job?.type === "web2apk") {
        if (job.status === "waiting_url"     && text?.startsWith("http")) return handleWeb2ApkUrl(event);
        if (job.status === "waiting_appname" && text)                     return handleWeb2ApkName(event);
        if (job.status === "waiting_icon"    && msg.media)                return handleWeb2ApkIcon(event);
      }

      if (msg.media) await handleZipFile(event);
    } catch (err) { console.error("Handler error:", err); }
  }, new NewMessage({}));

  client.addEventHandler(async (event) => {
    try { await handleCallback(event); }
    catch (err) { console.error("Callback error:", err); }
  }, new CallbackQuery({}));

  console.log(`${CONFIG.BOT_NAME} v${CONFIG.BOT_VERSION} aktif!`);
  await new Promise(() => {});
}

main();