const express = require('express');
const si = require('systeminformation');
const os = require('os');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const cors = require('cors');

const app = express();
const PORT = 4000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));
app.use('/files', express.static(path.join(__dirname, 'storage')));

// Konfigurasi multer untuk upload file
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadPath = path.join(__dirname, 'storage');
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + '-' + file.originalname);
    }
});

const upload = multer({ storage: storage });

// Folder penyimpanan file
const STORAGE_DIR = path.join(__dirname, 'storage');

// API: Get semua statistik server
app.get('/api/stats', async (req, res) => {
    try {
        // Network interfaces (IP)
        const network = await si.networkInterfaces();
        const ipAddresses = network
            .filter(iface => iface.ip4 && !iface.internal)
            .map(iface => iface.ip4);

        // CPU Info
        const cpu = await si.cpu();
        const cpuLoad = await si.currentLoad();
        
        // Memory Info
        const memory = await si.mem();
        
        // Disk Info
        const disk = await si.fsSize();
        
        // OS Info
        const osInfo = await si.osInfo();
        
        // System uptime
        const uptime = os.uptime();
        
        res.json({
            success: true,
            data: {
                ip: ipAddresses,
                hostname: os.hostname(),
                os: {
                    platform: osInfo.platform,
                    distro: osInfo.distro,
                    release: osInfo.release,
                    arch: osInfo.arch
                },
                cpu: {
                    model: cpu.manufacturer + ' ' + cpu.brand,
                    cores: cpu.cores,
                    speed: cpu.speed + 'GHz',
                    load: cpuLoad.currentLoad.toFixed(2) + '%'
                },
                memory: {
                    total: (memory.total / 1024 / 1024 / 1024).toFixed(2) + ' GB',
                    used: (memory.active / 1024 / 1024 / 1024).toFixed(2) + ' GB',
                    free: (memory.free / 1024 / 1024 / 1024).toFixed(2) + ' GB',
                    usage: ((memory.active / memory.total) * 100).toFixed(2) + '%'
                },
                disk: disk.map(d => ({
                    mounted: d.mount,
                    total: (d.size / 1024 / 1024 / 1024).toFixed(2) + ' GB',
                    used: (d.used / 1024 / 1024 / 1024).toFixed(2) + ' GB',
                    free: (d.available / 1024 / 1024 / 1024).toFixed(2) + ' GB',
                    usage: d.use + '%'
                })),
                uptime: formatUptime(uptime)
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// API: Get daftar file yang disimpan
app.get('/api/files', (req, res) => {
    try {
        if (!fs.existsSync(STORAGE_DIR)) {
            return res.json({ success: true, files: [] });
        }
        
        const files = fs.readdirSync(STORAGE_DIR).map(filename => {
            const filePath = path.join(STORAGE_DIR, filename);
            const stats = fs.statSync(filePath);
            return {
                name: filename,
                size: (stats.size / 1024).toFixed(2) + ' KB',
                sizeBytes: stats.size,
                modified: stats.mtime,
                created: stats.birthtime,
                path: filePath
            };
        });
        
        // Total storage used by files
        const totalFileSize = files.reduce((sum, file) => sum + parseFloat(file.sizeBytes), 0);
        const totalFileSizeFormatted = (totalFileSize / 1024 / 1024).toFixed(2) + ' MB';
        
        res.json({
            success: true,
            files: files,
            totalSize: totalFileSizeFormatted,
            fileCount: files.length
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// API: Upload file
app.post('/api/upload', upload.single('file'), (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ success: false, error: 'No file uploaded' });
        }
        
        res.json({
            success: true,
            message: 'File uploaded successfully',
            file: {
                name: req.file.filename,
                originalName: req.file.originalname,
                size: (req.file.size / 1024).toFixed(2) + ' KB'
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// API: Delete file
app.delete('/api/files/:filename', (req, res) => {
    try {
        const filename = req.params.filename;
        const filePath = path.join(STORAGE_DIR, filename);
        
        // Security: prevent path traversal
        if (!filePath.startsWith(STORAGE_DIR)) {
            return res.status(403).json({ success: false, error: 'Invalid file path' });
        }
        
        if (!fs.existsSync(filePath)) {
            return res.status(404).json({ success: false, error: 'File not found' });
        }
        
        fs.unlinkSync(filePath);
        res.json({ success: true, message: 'File deleted successfully' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// API: Rename file
app.put('/api/files/:filename', (req, res) => {
    try {
        const oldFilename = req.params.filename;
        const { newName } = req.body;
        
        if (!newName) {
            return res.status(400).json({ success: false, error: 'New name required' });
        }
        
        const oldPath = path.join(STORAGE_DIR, oldFilename);
        const newPath = path.join(STORAGE_DIR, newName);
        
        if (!fs.existsSync(oldPath)) {
            return res.status(404).json({ success: false, error: 'File not found' });
        }
        
        fs.renameSync(oldPath, newPath);
        res.json({ success: true, message: 'File renamed successfully' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// API: Get file content (text files only)
app.get('/api/files/:filename/content', (req, res) => {
    try {
        const filename = req.params.filename;
        const filePath = path.join(STORAGE_DIR, filename);
        
        if (!fs.existsSync(filePath)) {
            return res.status(404).json({ success: false, error: 'File not found' });
        }
        
        const ext = path.extname(filename).toLowerCase();
        const textExtensions = ['.txt', '.js', '.json', '.html', '.css', '.md', '.csv', '.xml'];
        
        if (textExtensions.includes(ext)) {
            const content = fs.readFileSync(filePath, 'utf8');
            res.json({ success: true, content: content, isText: true });
        } else {
            res.json({ success: true, isText: false, message: 'Binary file cannot be edited' });
        }
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// API: Update file content
app.put('/api/files/:filename/content', (req, res) => {
    try {
        const filename = req.params.filename;
        const { content } = req.body;
        const filePath = path.join(STORAGE_DIR, filename);
        
        if (!fs.existsSync(filePath)) {
            return res.status(404).json({ success: false, error: 'File not found' });
        }
        
        fs.writeFileSync(filePath, content, 'utf8');
        res.json({ success: true, message: 'File content updated successfully' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

function formatUptime(seconds) {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${days}d ${hours}h ${minutes}m ${secs}s`;
}

// Buat folder storage jika belum ada
if (!fs.existsSync(STORAGE_DIR)) {
    fs.mkdirSync(STORAGE_DIR, { recursive: true });
}

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log(`Storage directory: ${STORAGE_DIR}`);
});