const express = require('express');
const si = require('systeminformation');
const os = require('os');
const cors = require('cors');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

app.get('/api/stats', async (req, res) => {
    try {
        const network = await si.networkInterfaces();
        const ipAddresses = network
            .filter(iface => iface.ip4 && !iface.internal)
            .map(iface => iface.ip4);

        const networkStats = await si.networkStats();
        const netStats = networkStats[0] || {};

        const cpu = await si.cpu();
        const cpuLoad = await si.currentLoad();
        const memory = await si.mem();
        const disk = await si.fsSize();
        const osInfo = await si.osInfo();
        const uptime = os.uptime();
        const processes = await si.processes();

        let temp = null;
        try {
            const tempData = await si.cpuTemperature();
            temp = tempData.main;
        } catch(e) {
            temp = null;
        }
        
        res.json({
            success: true,
            timestamp: Date.now(),
            data: {
                ip: ipAddresses,
                hostname: os.hostname(),
                serverName: 'vps | xore',
                networkSpeed: {
                    rx: (netStats.rx_sec / 1024).toFixed(2),
                    tx: (netStats.tx_sec / 1024).toFixed(2)
                },
                os: {
                    platform: osInfo.platform,
                    distro: osInfo.distro,
                    release: osInfo.release,
                    arch: osInfo.arch
                },
                cpu: {
                    model: cpu.manufacturer + ' ' + cpu.brand,
                    cores: cpu.cores,
                    speed: cpu.speed + 'GHz',
                    load: cpuLoad.currentLoad.toFixed(2) + '%',
                    loadRaw: cpuLoad.currentLoad
                },
                memory: {
                    total: (memory.total / 1024 / 1024 / 1024).toFixed(2),
                    used: (memory.active / 1024 / 1024 / 1024).toFixed(2),
                    free: (memory.free / 1024 / 1024 / 1024).toFixed(2),
                    usage: ((memory.active / memory.total) * 100).toFixed(2)
                },
                disk: disk.map(d => ({
                    mounted: d.mount,
                    total: (d.size / 1024 / 1024 / 1024).toFixed(2),
                    used: (d.used / 1024 / 1024 / 1024).toFixed(2),
                    free: (d.available / 1024 / 1024 / 1024).toFixed(2),
                    usage: d.use
                })),
                uptime: formatUptime(uptime),
                processes: processes.total,
                temperature: temp ? temp.toFixed(1) : 'N/A'
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

function formatUptime(seconds) {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${days}d ${hours}h ${minutes}m ${secs}s`;
}

app.listen(PORT, () => {
    console.log(`XORE-X771 Server running on http://localhost:${PORT}`);
});