const express = require('express');
const si = require('systeminformation');
const os = require('os');
const cors = require('cors');

const app = express();
const PORT = 4000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

app.get('/api/stats', async (req, res) => {
    try {
        console.log('Fetching server stats...');
        
        // Network interfaces (IP)
        const network = await si.networkInterfaces();
        const ipAddresses = network
            .filter(iface => iface.ip4 && !iface.internal)
            .map(iface => iface.ip4);
        
        // Network speed
        let rxSpeed = 0, txSpeed = 0;
        try {
            const networkStats = await si.networkStats();
            if (networkStats && networkStats.length > 0) {
                rxSpeed = (networkStats[0].rx_sec / 1024).toFixed(2);
                txSpeed = (networkStats[0].tx_sec / 1024).toFixed(2);
            }
        } catch(e) {
            console.log('Network stats error:', e.message);
        }

        // CPU Info
        const cpu = await si.cpu();
        const cpuLoad = await si.currentLoad();
        
        // Memory Info
        const memory = await si.mem();
        
        // Disk Info
        const disk = await si.fsSize();
        
        // OS Info
        const osInfo = await si.osInfo();
        
        // Uptime
        const uptime = os.uptime();
        
        // Processes
        let processCount = 0;
        try {
            const processes = await si.processes();
            processCount = processes.total || 0;
        } catch(e) {
            processCount = 0;
        }
        
        // Temperature
        let temperature = 'N/A';
        try {
            const tempData = await si.cpuTemperature();
            if (tempData && tempData.main) {
                temperature = tempData.main.toFixed(1) + '°C';
            }
        } catch(e) {
            temperature = 'N/A';
        }
        
        const responseData = {
            success: true,
            timestamp: Date.now(),
            data: {
                ip: ipAddresses.length > 0 ? ipAddresses : ['000.0.0.0'],
                hostname: os.hostname(),
                serverName: 'XORE-X771',
                networkSpeed: {
                    rx: rxSpeed,
                    tx: txSpeed
                },
                os: {
                    platform: osInfo.platform || 'Unknown',
                    distro: osInfo.distro || osInfo.platform || 'Unknown',
                    release: osInfo.release || 'Unknown',
                    arch: osInfo.arch || 'Unknown'
                },
                cpu: {
                    model: cpu.manufacturer + ' ' + cpu.brand || cpu.brand || 'Unknown CPU',
                    cores: cpu.cores || 1,
                    speed: cpu.speed ? cpu.speed + 'GHz' : 'Unknown',
                    load: cpuLoad.currentLoad ? cpuLoad.currentLoad.toFixed(2) + '%' : '0%',
                    loadRaw: cpuLoad.currentLoad || 0
                },
                memory: {
                    total: memory.total ? (memory.total / 1024 / 1024 / 1024).toFixed(2) : '0',
                    used: memory.active ? (memory.active / 1024 / 1024 / 1024).toFixed(2) : '0',
                    free: memory.free ? (memory.free / 1024 / 1024 / 1024).toFixed(2) : '0',
                    usage: memory.total && memory.active ? ((memory.active / memory.total) * 100).toFixed(2) : '0'
                },
                disk: disk.map(d => ({
                    mounted: d.mount || '/',
                    total: d.size ? (d.size / 1024 / 1024 / 1024).toFixed(2) : '0',
                    used: d.used ? (d.used / 1024 / 1024 / 1024).toFixed(2) : '0',
                    free: d.available ? (d.available / 1024 / 1024 / 1024).toFixed(2) : '0',
                    usage: d.use ? d.use : '0'
                })),
                uptime: formatUptime(uptime),
                processes: processCount,
                temperature: temperature
            }
        };
        
        console.log('Stats sent successfully');
        res.json(responseData);
        
    } catch (error) {
        console.error('Error in /api/stats:', error);
        res.status(500).json({ 
            success: false, 
            error: error.message,
            data: getFallbackData()
        });
    }
});

function getFallbackData() {
    return {
        ip: ['127.0.0.1'],
        hostname: 'localpcapex',
        serverName: 'XORE-X771',
        networkSpeed: { rx: '0', tx: '0' },
        os: { platform: 'Unknown', distro: 'Unknown', release: 'Unknown', arch: 'Unknown' },
        cpu: { model: 'Unknown CPU', cores: '1', speed: 'Unknown', load: '0%', loadRaw: 0 },
        memory: { total: '0', used: '0', free: '0', usage: '0' },
        disk: [{ mounted: '/', total: '0', used: '0', free: '0', usage: '0' }],
        uptime: '0d 0h 0m 0s',
        processes: 0,
        temperature: 'N/A'
    };
}

function formatUptime(seconds) {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${days}d ${hours}h ${minutes}m ${secs}s`;
}

app.listen(PORT, () => {
    console.log('');
    console.log('========================================');
    console.log('XORE-X771 SERVER STATISTICS');
    console.log('========================================');
    console.log(`Server running at: http://localhost:${PORT}`);
    console.log('========================================');
    console.log('');
});